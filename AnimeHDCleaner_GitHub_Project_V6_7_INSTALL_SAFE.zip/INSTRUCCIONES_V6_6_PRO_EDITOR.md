# Instrucciones V6.6 PRO EDITOR

1. Borra el ZIP anterior del repositorio.
2. Sube este ZIP V6.6 PRO EDITOR.
3. Ejecuta Actions.
4. Descarga el APK desde Artifacts.
5. Prueba la nueva UI, la comparación y la exportación.
