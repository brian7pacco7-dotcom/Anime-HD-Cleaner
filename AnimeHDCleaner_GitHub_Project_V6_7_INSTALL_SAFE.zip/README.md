# Anime HD Cleaner V6.7 INSTALL SAFE

Versión segura para instalar.

## Qué se corrigió

La versión anterior podía quedarse cargando al instalar por el motor experimental de exportación.
Esta versión elimina temporalmente Media3 Transformer para que el APK instale más rápido y sin trabarse.

## Mantiene

- Interfaz tipo editor.
- Panel inferior profesional.
- Comparador Antes / Después.
- Botón Exportar.
- Barra de carga visual.
- Ajustes activos y guardados.

## Importante

Esta versión es para confirmar instalación y estabilidad.
La exportación guarda sin marca, pero el motor HD real pesado se agregará después de confirmar que esta versión instala bien.
