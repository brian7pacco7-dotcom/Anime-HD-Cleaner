# Instrucciones V6.5 Editor UI

1. Borra el ZIP V6.4 anterior del repositorio.
2. Sube este ZIP V6.5 Editor UI.
3. Ejecuta Actions.
4. Descarga el APK desde Artifacts.
5. Prueba:
   - interfaz editor
   - pestañas inferiores
   - barra de calidad superior
   - carga de exportación
