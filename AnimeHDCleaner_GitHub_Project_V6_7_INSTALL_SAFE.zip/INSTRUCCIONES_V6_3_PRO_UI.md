# Instrucciones V6.3 PRO UI

1. Borra el ZIP V6.2 anterior del repositorio.
2. Sube este ZIP V6.3 PRO UI.
3. Ejecuta Actions.
4. Descarga el APK desde Artifacts.
5. Instálalo y prueba:
   - preview más grande
   - deslizador Antes / Después
   - botón Pantalla completa
   - panel de cambios aplicados
