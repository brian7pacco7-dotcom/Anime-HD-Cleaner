# Instrucciones V6.1 FIXED

1. Borra el ZIP V6 anterior del repositorio.
2. Sube este ZIP V6.1 FIXED.
3. Ejecuta Actions.
4. Descarga el APK desde Artifacts.
5. Instala y prueba.

Esta versión corrige el error de compileSdk 36.
