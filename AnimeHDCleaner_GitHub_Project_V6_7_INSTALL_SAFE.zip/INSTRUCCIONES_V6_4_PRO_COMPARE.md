# Instrucciones V6.4 PRO COMPARE

1. Borra el ZIP V6.3 anterior del repositorio.
2. Sube este ZIP V6.4 PRO COMPARE.
3. Ejecuta Actions.
4. Descarga el APK desde Artifacts.
5. Prueba:
   - mover la regla sobre el video
   - deslizar la barra inferior
   - entrar a Pantalla completa
