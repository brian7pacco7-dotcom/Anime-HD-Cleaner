# Instrucciones V6.7 INSTALL SAFE

1. Borra el ZIP anterior del repositorio.
2. Sube este ZIP.
3. Ejecuta Actions.
4. Descarga el APK.
5. Instala.

Esta versión usa un applicationId diferente:
com.zeta.animehdcleaner.safe

Eso evita conflicto con instalaciones anteriores.
