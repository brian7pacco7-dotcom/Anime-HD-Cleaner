# Instrucciones V6

1. Borra el ZIP V5 del repositorio.
2. Sube este ZIP V6.
3. Ejecuta Actions.
4. Descarga el APK desde Artifacts.
5. Prueba:
   - Importar video.
   - Tocar Reparación IA / Ultra HD / Anime HD.
   - Elegir 1080p o 4K.
   - Exportar.

Si falla la compilación, manda captura del error rojo.
