package com.zeta.animehdcleaner;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

public class FullscreenCompareActivity extends Activity {

    private ExoPlayer player;
    private PlayerView playerView;
    private FrameLayout preview;
    private android.view.View afterOverlay;
    private android.view.View divider;
    private TextView handle;
    private int compareProgress = 50;
    private SeekBar compareSeek;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String title = getIntent().getStringExtra("title");
        String subtitle = getIntent().getStringExtra("subtitle");
        String uriText = getIntent().getStringExtra("video_uri");
        compareProgress = getIntent().getIntExtra("compare_progress", 50);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(18,18,20));
        root.setPadding(dp(12), dp(18), dp(12), dp(18));

        TextView back = new TextView(this);
        back.setText("‹  Volver");
        back.setTextColor(Color.WHITE);
        back.setTextSize(18);
        back.setPadding(0, 0, 0, dp(8));
        back.setOnClickListener(v -> finish());
        root.addView(back);

        TextView t = new TextView(this);
        t.setText(title == null ? "Pantalla completa" : title);
        t.setTextColor(Color.WHITE);
        t.setTextSize(24);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setGravity(Gravity.CENTER);
        root.addView(t);

        TextView s = new TextView(this);
        s.setText(subtitle == null ? "Antes / Después" : subtitle);
        s.setTextColor(Color.rgb(180,180,186));
        s.setTextSize(14);
        s.setGravity(Gravity.CENTER);
        s.setPadding(0, dp(6), 0, dp(12));
        root.addView(s);

        preview = new FrameLayout(this);
        preview.setBackgroundColor(Color.BLACK);
        root.addView(preview, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(650)));

        playerView = new PlayerView(this);
        playerView.setUseController(true);
        preview.addView(playerView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        afterOverlay = new android.view.View(this);
        afterOverlay.setBackgroundColor(Color.argb(46, 255, 255, 255));
        preview.addView(afterOverlay, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        divider = new android.view.View(this);
        divider.setBackgroundColor(Color.WHITE);
        preview.addView(divider, new FrameLayout.LayoutParams(dp(3), FrameLayout.LayoutParams.MATCH_PARENT));

        handle = new TextView(this);
        handle.setText("◀ ▶");
        handle.setGravity(Gravity.CENTER);
        handle.setTextColor(Color.DKGRAY);
        handle.setTypeface(Typeface.DEFAULT_BOLD);
        handle.setBackgroundColor(Color.argb(236, 255, 255, 255));
        preview.addView(handle, new FrameLayout.LayoutParams(dp(70), dp(70)));

        TextView before = new TextView(this);
        before.setText("Antes");
        before.setTextColor(Color.WHITE);
        before.setTextSize(20);
        before.setTypeface(Typeface.DEFAULT_BOLD);
        before.setShadowLayer(5, 0, 0, Color.BLACK);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.LEFT);
        bp.setMargins(dp(18), 0, 0, dp(18));
        preview.addView(before, bp);

        TextView after = new TextView(this);
        after.setText("Después");
        after.setTextColor(Color.WHITE);
        after.setTextSize(20);
        after.setTypeface(Typeface.DEFAULT_BOLD);
        after.setShadowLayer(5, 0, 0, Color.BLACK);
        FrameLayout.LayoutParams ap = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.RIGHT);
        ap.setMargins(0, 0, dp(18), dp(18));
        preview.addView(after, ap);

        TextView lbl = new TextView(this);
        lbl.setText("Comparación en vivo");
        lbl.setTextColor(Color.WHITE);
        lbl.setTextSize(12);
        lbl.setTypeface(Typeface.DEFAULT_BOLD);
        lbl.setBackgroundColor(Color.argb(160,0,0,0));
        lbl.setPadding(dp(10), dp(6), dp(10), dp(6));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.RIGHT);
        lp.setMargins(0, dp(10), dp(10), 0);
        preview.addView(lbl, lp);

        preview.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN ||
                event.getAction() == MotionEvent.ACTION_MOVE) {
                updateCompareFromTouch(event.getX());
                return true;
            }
            return false;
        });

        compareSeek = new SeekBar(this);
        compareSeek.setMax(100);
        compareSeek.setProgress(compareProgress);
        compareSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                compareProgress = progress;
                updateCompare();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        root.addView(compareSeek);

        TextView tip = new TextView(this);
        tip.setText("Mueve la regla o desliza sobre el video");
        tip.setTextColor(Color.rgb(180,180,186));
        tip.setGravity(Gravity.CENTER);
        tip.setPadding(0, dp(4), 0, 0);
        root.addView(tip);

        setContentView(root);

        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        player.setRepeatMode(Player.REPEAT_MODE_ONE);

        if (uriText != null) {
            Uri uri = Uri.parse(uriText);
            player.setMediaItem(MediaItem.fromUri(uri));
            player.prepare();
            player.play();
        }

        preview.post(this::updateCompare);
    }

    private void updateCompareFromTouch(float touchX) {
        if (preview == null || preview.getWidth() == 0) return;
        int w = preview.getWidth();
        int p = Math.max(0, Math.min(100, Math.round((touchX / w) * 100f)));
        compareProgress = p;
        compareSeek.setProgress(p);
        updateCompare();
    }

    private void updateCompare() {
        if (preview == null || preview.getWidth() == 0) return;
        int w = preview.getWidth();
        int h = preview.getHeight();
        int x = (int) (w * (compareProgress / 100f));

        FrameLayout.LayoutParams overlayP = (FrameLayout.LayoutParams) afterOverlay.getLayoutParams();
        overlayP.width = Math.max(0, w - x);
        overlayP.height = h;
        overlayP.gravity = Gravity.RIGHT;
        afterOverlay.setLayoutParams(overlayP);

        FrameLayout.LayoutParams divP = (FrameLayout.LayoutParams) divider.getLayoutParams();
        divP.width = dp(3);
        divP.height = h;
        divP.leftMargin = Math.max(0, x - dp(1));
        divider.setLayoutParams(divP);

        FrameLayout.LayoutParams handleP = (FrameLayout.LayoutParams) handle.getLayoutParams();
        handleP.width = dp(70);
        handleP.height = dp(70);
        handleP.leftMargin = Math.max(0, Math.min(w - dp(70), x - dp(35)));
        handleP.topMargin = Math.max(0, h / 2 - dp(35));
        handle.setLayoutParams(handleP);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (player != null) player.pause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (player != null) {
            player.release();
            player = null;
        }
    }
}
