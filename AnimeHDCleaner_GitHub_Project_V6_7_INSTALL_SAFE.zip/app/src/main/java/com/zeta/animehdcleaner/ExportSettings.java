package com.zeta.animehdcleaner;

public class ExportSettings {
    public String modeName = "Reparación IA";
    public String qualityName = "Ultra HD";
    public int width = 1080;
    public int height = 1920;
    public int fps = 30;
    public int bitrateMbps = 12;

    public int brightness = 4;
    public int shadows = 10;
    public int contrast = 3;
    public int saturation = 8;
    public int denoise = 7;
    public int sharpen = 5;
    public int grain = 4;

    public String summary() {
        return "Modo: " + modeName
                + "\nCalidad: " + qualityName + " (" + width + "x" + height + ")"
                + "\nExportación: " + fps + " FPS · " + bitrateMbps + " Mbps · MP4 H.264"
                + "\nAjustes: sombras " + shadows + ", denoise " + denoise + ", nitidez " + sharpen + ", color " + saturation;
    }
}
