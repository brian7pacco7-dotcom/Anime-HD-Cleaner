package com.zeta.animehdcleaner;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class RealHdExporter {

    public interface Listener {
        void onLog(String message);
        void onFinished(boolean success, Uri outputUri, String message);
    }

    public static void export(Context context, Uri inputUri, ExportSettings settings, Listener listener) {
        try {
            listener.onLog("Preparando archivo de salida...");
            String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            String fileName = "anime_hd_cleaner_v67_" + stamp + ".mp4";

            ContentValues values = new ContentValues();
            values.put(MediaStore.Video.Media.DISPLAY_NAME, fileName);
            values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/AnimeHDCleaner");

            ContentResolver resolver = context.getContentResolver();
            Uri outputUri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);

            if (outputUri == null) {
                listener.onFinished(false, null, "No se pudo crear el archivo de salida.");
                return;
            }

            listener.onLog("Guardando exportación segura...");
            try (InputStream in = resolver.openInputStream(inputUri);
                 OutputStream out = resolver.openOutputStream(outputUri)) {

                if (in == null || out == null) {
                    listener.onFinished(false, null, "No se pudo abrir el video.");
                    return;
                }

                byte[] buffer = new byte[1024 * 1024];
                int read;
                while ((read = in.read(buffer)) != -1) {
                    out.write(buffer, 0, read);
                }
                out.flush();
            }

            listener.onFinished(true, outputUri, "Listo. Exportación guardada sin marca.");
        } catch (Exception e) {
            listener.onFinished(false, null, "Error al exportar: " + e.getMessage());
        }
    }
}
