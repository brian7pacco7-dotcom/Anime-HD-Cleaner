package com.zeta.animehdcleaner;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

public class TimelineView extends View {

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float progress = 0.5f;

    public TimelineView(Context context) {
        super(context);
        setMinimumHeight(dp(105));
    }

    public void setProgress(float progress) {
        this.progress = Math.max(0f, Math.min(1f, progress));
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int w = getWidth();
        int h = getHeight();

        paint.setColor(Color.rgb(18, 24, 31));
        canvas.drawRoundRect(0, 0, w, h, dp(10), dp(10), paint);

        paint.setTextSize(dp(11));
        paint.setColor(Color.rgb(170, 175, 182));
        String[] marks = {"00:00", "00:02", "00:04", "00:06", "00:08", "00:10", "00:12", "00:14", "00:16"};
        for (int i = 0; i < marks.length; i++) {
            float x = dp(88) + i * ((w - dp(120)) / 8f);
            canvas.drawText(marks[i], x - dp(14), dp(22), paint);
        }

        int top = dp(34);
        int bottom = dp(75);
        int left = dp(88);
        int right = w - dp(70);
        int blocks = 10;
        int blockW = (right - left) / blocks;

        for (int i = 0; i < blocks; i++) {
            paint.setColor(i % 2 == 0 ? Color.rgb(50, 65, 90) : Color.rgb(63, 55, 88));
            canvas.drawRect(left + i * blockW, top, left + (i + 1) * blockW - dp(2), bottom, paint);
        }

        paint.setColor(Color.rgb(0, 160, 170));
        int waveTop = dp(80);
        int waveBottom = dp(98);
        for (int x = left; x < right; x += dp(4)) {
            int amp = (int)(Math.abs(Math.sin(x * 0.06)) * dp(15));
            canvas.drawLine(x, waveBottom, x, waveBottom - amp, paint);
        }

        float lineX = left + (right - left) * progress;
        paint.setColor(Color.WHITE);
        paint.setStrokeWidth(dp(2));
        canvas.drawLine(lineX, dp(24), lineX, h - dp(8), paint);

        paint.setTextSize(dp(12));
        paint.setColor(Color.WHITE);
        canvas.drawText("Silenciar", dp(14), dp(66), paint);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(2));
        paint.setColor(Color.WHITE);
        canvas.drawRoundRect(w - dp(54), dp(39), w - dp(14), dp(79), dp(7), dp(7), paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setTextSize(dp(26));
        canvas.drawText("+", w - dp(42), dp(68), paint);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
