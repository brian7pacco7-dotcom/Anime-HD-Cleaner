package com.zeta.animehdcleaner;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.ui.PlayerView;

public class EditorActivity extends Activity {

    private static final int REQ_PICK_VIDEO = 1001;

    private Uri selectedVideo;
    private VideoPlayerManager playerManager;
    private ExportSettings settings = new ExportSettings();

    private CompareView compareView;
    private TimelineView timelineView;
    private TextView qualityButton;
    private TextView playButton;
    private TextView activeText;
    private TextView fileText;
    private LinearLayout presetRow;

    private Dialog dialog;
    private ProgressBar progressBar;
    private TextView progressText;
    private TextView progressMessage;
    private Handler handler = new Handler(Looper.getMainLooper());
    private int fakeProgress = 0;
    private boolean processDone = false;

    private final int bg = 0xFF090D12;
    private final int panel = 0xFF12181F;
    private final int card = 0xFF1F2530;
    private final int cyan = 0xFF11D2FF;
    private final int white = 0xFFFFFFFF;
    private final int muted = 0xFFB0B5BC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String uriText = getIntent().getStringExtra("video_uri");
        if (uriText != null) selectedVideo = Uri.parse(uriText);

        buildUi();

        if (selectedVideo != null) {
            loadVideo(selectedVideo);
        }
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.setBackgroundColor(bg);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(12), dp(12), dp(18));
        scroll.addView(root);

        LinearLayout top = row();
        root.addView(top);

        top.addView(topIcon("X"));
        top.addView(topIcon("?"));
        top.addView(topIcon("HD"));

        View spacer = new View(this);
        top.addView(spacer, new LinearLayout.LayoutParams(0, 1, 1f));

        qualityButton = pill(settings.qualityName + " v", dp(112), dp(52));
        qualityButton.setOnClickListener(v -> chooseQuality());
        top.addView(qualityButton);

        Button exportButton = button("Exportar", cyan, 0xFF000000);
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(dp(126), dp(52));
        ep.leftMargin = dp(10);
        top.addView(exportButton, ep);
        exportButton.setOnClickListener(v -> openExport());

        Button importButton = button("+ Importar video", 0xFF1CC07D, 0xFF000000);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54));
        ip.topMargin = dp(10);
        root.addView(importButton, ip);
        importButton.setOnClickListener(v -> pickVideo());

        FrameLayout preview = new FrameLayout(this);
        preview.setBackgroundColor(0xFF000000);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(380));
        pp.topMargin = dp(10);
        root.addView(preview, pp);

        PlayerView playerView = new PlayerView(this);
        playerView.setUseController(false);
        preview.addView(playerView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        compareView = new CompareView(this);
        preview.addView(compareView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        playerManager = new VideoPlayerManager(this, playerView);

        SeekBar compareSlider = new SeekBar(this);
        compareSlider.setMax(100);
        compareSlider.setProgress(50);
        root.addView(compareSlider);
        compareSlider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                compareView.setProgress(progress / 100f);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        LinearLayout controls = row();
        controls.setPadding(0, dp(8), 0, dp(8));
        root.addView(controls);

        TextView time = smallBox("00:00 / 00:00");
        controls.addView(time, new LinearLayout.LayoutParams(dp(120), dp(48)));
        controls.addView(control("-5s", () -> {
            if (playerManager != null) playerManager.seekBy(-5000);
        }));
        playButton = controlText("Play", () -> togglePlay());
        controls.addView(playButton);
        controls.addView(control("+5s", () -> {
            if (playerManager != null) playerManager.seekBy(5000);
        }));
        controls.addView(control("Pantalla", () -> openFullscreen()));

        timelineView = new TimelineView(this);
        LinearLayout.LayoutParams tvp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(110));
        root.addView(timelineView, tvp);

        LinearLayout editor = panelBox();
        LinearLayout.LayoutParams edp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        edp.topMargin = dp(8);
        root.addView(editor, edp);

        LinearLayout tabs = row();
        editor.addView(tabs);
        tabs.addView(tab("Mejoras IA", true));
        tabs.addView(tab("Ajustar", false));
        tabs.addView(tab("Filtros", false));
        tabs.addView(tab("Calidad", false));

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        presetRow = new LinearLayout(this);
        presetRow.setOrientation(LinearLayout.HORIZONTAL);
        hsv.addView(presetRow);
        editor.addView(hsv);
        rebuildPresets();

        LinearLayout activeRow = row();
        activeRow.setPadding(0, dp(12), 0, 0);
        editor.addView(activeRow);

        activeText = text("Funcion activa: " + settings.modeName, 14, true, white);
        activeText.setBackgroundColor(card);
        activeText.setPadding(dp(12), dp(10), dp(12), dp(10));
        activeRow.addView(activeText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button tryNow = button("Probar ahora", cyan, 0xFF000000);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(dp(190), dp(54));
        tp.leftMargin = dp(10);
        activeRow.addView(tryNow, tp);
        tryNow.setOnClickListener(v -> previewProcess());

        LinearLayout adjust = panelBox();
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ap.topMargin = dp(8);
        root.addView(adjust, ap);

        HorizontalScrollView adjScroll = new HorizontalScrollView(this);
        adjScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout sliderRow = new LinearLayout(this);
        sliderRow.setOrientation(LinearLayout.HORIZONTAL);
        adjScroll.addView(sliderRow);
        adjust.addView(adjScroll);

        sliderRow.addView(compactSlider("Brillo", 0, 20, settings.brightness, v -> settings.brightness = v));
        sliderRow.addView(compactSlider("Contraste", 0, 20, settings.contrast, v -> settings.contrast = v));
        sliderRow.addView(compactSlider("Saturacion", 0, 20, settings.saturation, v -> settings.saturation = v));
        sliderRow.addView(compactSlider("Luminosidad", 0, 20, settings.luminosity, v -> settings.luminosity = v));
        sliderRow.addView(compactSlider("Enfocar", 0, 20, settings.sharpen, v -> settings.sharpen = v));
        sliderRow.addView(compactSlider("Ruido", 0, 20, settings.denoise, v -> settings.denoise = v));

        fileText = text("Video: no cargado", 13, false, muted);
        fileText.setPadding(0, dp(10), 0, 0);
        root.addView(fileText);

        setContentView(scroll);
    }

    private void rebuildPresets() {
        presetRow.removeAllViews();
        for (String preset : PresetManager.PRESETS) {
            presetRow.addView(presetButton(preset));
        }
    }

    private TextView presetButton(String preset) {
        TextView v = text(iconFor(preset) + "\n" + preset, 13, preset.equals(settings.modeName), preset.equals(settings.modeName) ? cyan : white);
        v.setGravity(Gravity.CENTER);
        v.setBackgroundColor(card);
        v.setPadding(dp(8), dp(10), dp(8), dp(10));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(128), dp(88));
        p.rightMargin = dp(10);
        v.setLayoutParams(p);
        v.setOnClickListener(view -> {
            PresetManager.apply(preset, settings);
            refreshUi();
            rebuildPresets();
            Toast.makeText(this, preset + " activo", Toast.LENGTH_SHORT).show();
        });
        return v;
    }

    private String iconFor(String preset) {
        if (preset.contains("Color")) return "CLR";
        if (preset.contains("ruido")) return "NR";
        if (preset.contains("4K")) return "4K+";
        if (preset.contains("Sombras")) return "SUN";
        return "AI";
    }

    private void refreshUi() {
        qualityButton.setText(settings.qualityName + " v");
        activeText.setText("Funcion activa: " + settings.modeName);
        if (fileText != null) fileText.setText(selectedVideo == null ? "Video: no cargado" : "Video cargado: " + getFileName(selectedVideo));
    }

    private interface SetInt { void set(int value); }

    private View compactSlider(String name, int min, int max, int current, SetInt setter) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(6), dp(6), dp(6), dp(6));
        box.setBackgroundColor(panel);

        TextView label = text(name, 12, false, white);
        label.setGravity(Gravity.CENTER);
        box.addView(label);

        TextView value = text(String.valueOf(current), 14, true, white);
        value.setGravity(Gravity.CENTER);
        box.addView(value);

        SeekBar seek = new SeekBar(this);
        seek.setMax(max - min);
        seek.setProgress(current - min);
        box.addView(seek, new LinearLayout.LayoutParams(dp(108), ViewGroup.LayoutParams.WRAP_CONTENT));

        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int real = min + progress;
                setter.set(real);
                value.setText(String.valueOf(real));
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                refreshUi();
            }
        });

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(116), ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.rightMargin = dp(4);
        box.setLayoutParams(lp);
        return box;
    }

    private void togglePlay() {
        if (selectedVideo == null) {
            Toast.makeText(this, "Primero importa un video", Toast.LENGTH_SHORT).show();
            return;
        }
        playerManager.toggle();
        playButton.setText(playerManager.isPlaying() ? "Pausa" : "Play");
    }

    private void previewProcess() {
        if (selectedVideo == null) {
            Toast.makeText(this, "Primero importa un video", Toast.LENGTH_SHORT).show();
            return;
        }
        showProgress("Aplicando mejoras");
        fakeProgress = 0;
        processDone = false;
        stepPreviewProgress();
    }

    private void stepPreviewProgress() {
        if (processDone) return;
        fakeProgress += 5;
        if (fakeProgress > 100) fakeProgress = 100;
        progressBar.setProgress(fakeProgress);
        progressText.setText(fakeProgress + "%");
        progressMessage.setText("Aplicando " + settings.modeName + "...\nPreparando Antes / Despues.");

        if (fakeProgress >= 100) {
            processDone = true;
            progressMessage.setText("Listo. Revisa Antes / Despues.");
            handler.postDelayed(() -> {
                if (dialog != null && dialog.isShowing()) dialog.dismiss();
                openFullscreen();
            }, 900);
            return;
        }
        handler.postDelayed(this::stepPreviewProgress, 240);
    }

    private void showProgress(String title) {
        dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(22), dp(22), dp(22), dp(22));
        box.setBackgroundColor(card);

        TextView titleView = text(title, 22, true, white);
        titleView.setGravity(Gravity.CENTER);
        box.addView(titleView);

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        pp.topMargin = dp(16);
        box.addView(progressBar, pp);

        progressText = text("0%", 20, true, white);
        progressText.setGravity(Gravity.CENTER);
        progressText.setPadding(0, dp(8), 0, dp(8));
        box.addView(progressText);

        progressMessage = text("Preparando...", 14, false, white);
        progressMessage.setGravity(Gravity.CENTER);
        box.addView(progressMessage);

        Button cancel = button("Cancelar", panel, white);
        cancel.setOnClickListener(v -> {
            processDone = true;
            if (dialog != null && dialog.isShowing()) dialog.dismiss();
        });
        box.addView(cancel);

        dialog.setContentView(box);
        dialog.setCancelable(false);
        dialog.show();
    }

    private void chooseQuality() {
        String[] options = {"720P", "1080P", "2K", "4K"};
        new AlertDialog.Builder(this)
                .setTitle("Elegir calidad")
                .setItems(options, (d, which) -> {
                    if (which == 0) setQuality("720P", 720, 1280, 30, 8);
                    if (which == 1) setQuality("1080P", 1080, 1920, 30, 12);
                    if (which == 2) setQuality("2K", 1440, 2560, 30, 20);
                    if (which == 3) setQuality("4K", 2160, 3840, 30, 35);
                    refreshUi();
                }).show();
    }

    private void setQuality(String name, int width, int height, int fps, int bitrate) {
        settings.qualityName = name;
        settings.width = width;
        settings.height = height;
        settings.fps = fps;
        settings.bitrateMbps = bitrate;
    }

    private void openExport() {
        if (selectedVideo == null) {
            Toast.makeText(this, "Primero importa un video", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(this, ExportActivity.class);
        i.putExtra("video_uri", selectedVideo.toString());
        i.putExtra("settings", settings);
        startActivity(i);
    }

    private void openFullscreen() {
        if (selectedVideo == null) {
            Toast.makeText(this, "Primero importa un video", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(this, FullscreenCompareActivity.class);
        i.putExtra("video_uri", selectedVideo.toString());
        i.putExtra("title", settings.modeName);
        i.putExtra("compare_progress", compareView.getProgress());
        startActivity(i);
    }

    private void pickVideo() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("video/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, REQ_PICK_VIDEO);
    }

    private void loadVideo(Uri uri) {
        selectedVideo = uri;
        playerManager.load(uri);
        playerManager.play();
        playButton.setText("Pausa");
        refreshUi();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PICK_VIDEO && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                try {
                    getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Exception ignored) {}
                loadVideo(uri);
            }
        }
    }

    private String getFileName(Uri uri) {
        String result = "video seleccionado";
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) result = cursor.getString(idx);
            }
        } catch (Exception ignored) {}
        return result;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        return r;
    }

    private LinearLayout panelBox() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(panel);
        box.setPadding(dp(12), dp(10), dp(12), dp(12));
        return box;
    }

    private TextView topIcon(String value) {
        TextView v = text(value, 20, true, white);
        v.setGravity(Gravity.CENTER);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(42), dp(52)));
        return v;
    }

    private TextView pill(String value, int width, int height) {
        TextView v = text(value, 16, true, white);
        v.setGravity(Gravity.CENTER);
        v.setBackgroundColor(card);
        v.setLayoutParams(new LinearLayout.LayoutParams(width, height));
        return v;
    }

    private TextView smallBox(String value) {
        TextView v = text(value, 13, false, white);
        v.setGravity(Gravity.CENTER);
        v.setBackgroundColor(card);
        return v;
    }

    private View control(String label, Runnable action) {
        Button b = button(label, card, white);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(48), 1f);
        p.leftMargin = dp(8);
        b.setLayoutParams(p);
        b.setOnClickListener(v -> action.run());
        return b;
    }

    private TextView controlText(String label, Runnable action) {
        TextView b = text(label, 14, false, white);
        b.setGravity(Gravity.CENTER);
        b.setBackgroundColor(card);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(48), 1f);
        p.leftMargin = dp(8);
        b.setLayoutParams(p);
        b.setOnClickListener(v -> action.run());
        return b;
    }

    private TextView tab(String label, boolean active) {
        TextView t = text(label, 14, true, active ? cyan : muted);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(6), dp(8), dp(6), dp(10));
        t.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return t;
    }

    private Button button(String label, int bg, int fg) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(fg);
        b.setBackgroundColor(bg);
        b.setAllCaps(false);
        return b;
    }

    private TextView text(String value, int size, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(color);
        t.setTextSize(size);
        if (bold) t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        return t;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (playerManager != null) playerManager.pause();
        if (playButton != null) playButton.setText("Play");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
        if (playerManager != null) playerManager.release();
    }
}
