# Anime HD Cleaner V10 UI STABLE

Version limpia para empezar bien.

## Objetivo
Primero interfaz estable. No IA online. No motor experimental.

## Incluye
- Pantalla principal.
- Editor visual tipo app de video.
- Importar video.
- Reproductor con ExoPlayer.
- Botones -5s, Play/Pausa, +5s.
- Timeline visual simulado.
- Panel Mejoras IA locales.
- Ajustes tipo CapCut.
- Antes / Despues con CompareView.
- ExportActivity con progreso.
- Exportacion sin marca de agua copiando el video a Movies/AnimeHDCleaner.
- GitHub Actions para APK.

## Nota
Esta V10 prioriza que compile, instale y sea estable. La mejora real avanzada se agrega despues.
