package com.zeta.animehdcleaner;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.VideoView;

import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final int REQ_PICK_VIDEO = 1001;

    private Uri selectedVideo;
    private TextView status;
    private VideoView preview;

    private int brillo = 3;
    private int sombras = 8;
    private int denoise = 6;
    private int nitidez = 4;
    private int grano = 3;
    private int bitrate = 12;
    private int fps = 30;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        setStatus("V2 estable: primero probamos que el APK compile, abra y exporte sin marca. Luego agregamos motor real de filtros.");
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(26, 28, 26, 28);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("Anime HD Cleaner");
        title.setTextSize(26);
        title.setGravity(Gravity.CENTER);
        title.setTextColor(0xFF111827);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("V2 estable: UI + selección de video + exportación sin marca. Sin FFmpeg roto.");
        subtitle.setTextSize(14);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setTextColor(0xFF4B5563);
        subtitle.setPadding(0, 6, 0, 20);
        root.addView(subtitle);

        Button pick = bigButton("Elegir video");
        pick.setOnClickListener(v -> pickVideo());
        root.addView(pick);

        preview = new VideoView(this);
        LinearLayout.LayoutParams videoParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                900
        );
        videoParams.setMargins(0, 16, 0, 16);
        preview.setLayoutParams(videoParams);
        preview.setBackgroundColor(0xFF111827);
        root.addView(preview);

        root.addView(section("Presets manuales"));
        Button animeDark = bigButton("Anime oscuro");
        animeDark.setOnClickListener(v -> {
            brillo = 4; sombras = 10; denoise = 7; nitidez = 4; grano = 4; bitrate = 12; fps = 30;
            setStatus("Preset Anime oscuro aplicado.");
        });
        root.addView(animeDark);

        Button clean = bigButton("Sombras limpias");
        clean.setOnClickListener(v -> {
            brillo = 5; sombras = 12; denoise = 8; nitidez = 3; grano = 5; bitrate = 12; fps = 30;
            setStatus("Preset Sombras limpias aplicado.");
        });
        root.addView(clean);

        Button sharp = bigButton("Más nitidez");
        sharp.setOnClickListener(v -> {
            brillo = 2; sombras = 5; denoise = 4; nitidez = 8; grano = 2; bitrate = 15; fps = 30;
            setStatus("Preset Más nitidez aplicado.");
        });
        root.addView(sharp);

        root.addView(section("Controles"));
        addSlider(root, "Brillo", 0, 20, brillo, v -> brillo = v);
        addSlider(root, "Sombras/Gamma", 0, 20, sombras, v -> sombras = v);
        addSlider(root, "Denoise/anti-manchas", 0, 10, denoise, v -> denoise = v);
        addSlider(root, "Nitidez", 0, 10, nitidez, v -> nitidez = v);
        addSlider(root, "Grano anti-banding", 0, 10, grano, v -> grano = v);
        addSlider(root, "Bitrate Mbps", 8, 15, bitrate, v -> bitrate = v);

        LinearLayout fpsRow = new LinearLayout(this);
        fpsRow.setOrientation(LinearLayout.HORIZONTAL);
        fpsRow.setGravity(Gravity.CENTER);
        Button fps30 = smallButton("30 FPS");
        fps30.setOnClickListener(v -> {
            fps = 30;
            setStatus("FPS 30 seleccionado. Recomendado.");
        });
        Button fps60 = smallButton("60 FPS");
        fps60.setOnClickListener(v -> {
            fps = 60;
            setStatus("FPS 60 seleccionado. Úsalo solo para mucho movimiento.");
        });
        fpsRow.addView(fps30);
        fpsRow.addView(fps60);
        root.addView(fpsRow);

        Button export = bigButton("Exportar prueba sin marca");
        export.setOnClickListener(v -> exportCopy());
        root.addView(export);

        status = new TextView(this);
        status.setTextSize(13);
        status.setTextColor(0xFF111827);
        status.setPadding(0, 18, 0, 50);
        root.addView(status);

        setContentView(scroll);
    }

    private TextView section(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(18);
        view.setTextColor(0xFF111827);
        view.setPadding(0, 16, 0, 6);
        return view;
    }

    private Button bigButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(16);
        b.setAllCaps(false);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        p.setMargins(0, 8, 0, 8);
        b.setLayoutParams(p);
        return b;
    }

    private Button smallButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(14);
        b.setAllCaps(false);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        p.setMargins(6, 8, 6, 8);
        b.setLayoutParams(p);
        return b;
    }

    private interface Change {
        void set(int value);
    }

    private void addSlider(LinearLayout root, String name, int min, int max, int value, Change change) {
        TextView label = new TextView(this);
        label.setText(name + ": " + value);
        label.setTextSize(14);
        label.setPadding(0, 12, 0, 0);
        root.addView(label);

        SeekBar bar = new SeekBar(this);
        bar.setMax(max - min);
        bar.setProgress(value - min);
        root.addView(bar);

        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int real = min + progress;
                label.setText(name + ": " + real);
                change.set(real);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                setStatus("Ajuste actualizado.");
            }
        });
    }

    private void pickVideo() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("video/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, REQ_PICK_VIDEO);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PICK_VIDEO && resultCode == RESULT_OK && data != null) {
            selectedVideo = data.getData();
            if (selectedVideo != null) {
                try {
                    getContentResolver().takePersistableUriPermission(
                            selectedVideo,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION
                    );
                } catch (Exception ignored) {}

                preview.setVideoURI(selectedVideo);
                preview.setOnPreparedListener(mp -> {
                    mp.setLooping(true);
                    preview.start();
                });
                setStatus("Video cargado. Esta V2 exporta copia de prueba sin marca.");
            }
        }
    }

    private void exportCopy() {
        if (selectedVideo == null) {
            setStatus("Primero elige un video.");
            return;
        }

        setStatus("Exportando prueba... no cierres la app.");

        try {
            String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            String fileName = "anime_hd_cleaner_v2_" + stamp + ".mp4";

            ContentValues values = new ContentValues();
            values.put(MediaStore.Video.Media.DISPLAY_NAME, fileName);
            values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/AnimeHDCleaner");

            ContentResolver resolver = getContentResolver();
            Uri outputUri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);

            if (outputUri == null) {
                setStatus("No se pudo crear el archivo de salida.");
                return;
            }

            try (InputStream in = resolver.openInputStream(selectedVideo);
                 OutputStream out = resolver.openOutputStream(outputUri)) {

                if (in == null || out == null) {
                    setStatus("No se pudo abrir el video.");
                    return;
                }

                byte[] buffer = new byte[1024 * 1024];
                int read;
                while ((read = in.read(buffer)) != -1) {
                    out.write(buffer, 0, read);
                }
                out.flush();
            }

            setStatus("Exportado sin marca en Galería > Movies > AnimeHDCleaner. En la V3 agregamos motor real de filtros.");
        } catch (Exception e) {
            setStatus("Error al exportar: " + e.getMessage());
        }
    }

    private void setStatus(String text) {
        if (status == null) return;
        status.setText(text + "\n\n" + resumen());
    }

    private String resumen() {
        return "Ajustes:\n"
                + "Brillo " + brillo
                + " | Sombras " + sombras
                + " | Denoise " + denoise
                + " | Nitidez " + nitidez
                + "\nGrano " + grano
                + " | " + fps + " FPS"
                + " | " + bitrate + " Mbps";
    }
}
