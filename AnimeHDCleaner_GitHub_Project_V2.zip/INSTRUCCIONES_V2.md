# Instrucciones V2

1. Borra el ZIP viejo del repositorio.
2. Sube este ZIP V2.
3. Deja el workflow actual.
4. Ejecuta Actions.
5. Descarga el APK desde Artifacts.

Si compila en verde, la app ya abre.
Después seguimos con V3 para filtros reales.
