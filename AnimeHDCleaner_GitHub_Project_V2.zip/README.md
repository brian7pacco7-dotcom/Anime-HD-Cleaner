# Anime HD Cleaner V2

Versión estable para compilar APK sin FFmpeg roto.

## Qué incluye

- App Android en Java.
- UI manual para video anime.
- Selección de video.
- Vista previa.
- Presets:
  - Anime oscuro
  - Sombras limpias
  - Más nitidez
- Controles:
  - Brillo
  - Sombras/Gamma
  - Denoise
  - Nitidez
  - Grano anti-banding
  - Bitrate
  - FPS
- Exportación de prueba sin marca de agua.

## Importante

Esta V2 está hecha para compilar e instalar primero.
La exportación de esta versión copia el video sin aplicar filtros reales.

La V3 debe agregar motor real de procesamiento:
- Media3 Transformer, o
- FFmpeg compilado/bundleado de forma segura.
