# Anime HD Cleaner V7.1 STABLE EDITOR

Correcciones:
- Regla Antes / Despues estable.
- Se quitó el cuadro duplicado de la regla.
- La regla se mueve con la barra inferior para evitar fallos tactiles.
- La interfaz ahora sí baja con scroll.
- Los ajustes estan visibles arriba y tambien todos juntos abajo.
- Mantiene motor HD real.
