package com.zeta.animehdcleaner;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

public class FullscreenCompareActivity extends Activity {

    private ExoPlayer player;
    private PlayerView playerView;
    private FrameLayout preview;
    private View afterOverlay;
    private View divider;
    private TextView beforeLabel;
    private TextView afterLabel;
    private SeekBar compareSeek;
    private int compareProgress = 50;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String title = getIntent().getStringExtra("title");
        String subtitle = getIntent().getStringExtra("subtitle");
        String uriText = getIntent().getStringExtra("video_uri");
        compareProgress = getIntent().getIntExtra("compare_progress", 50);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(18, 18, 20));
        root.setPadding(dp(12), dp(18), dp(12), dp(18));

        TextView back = text("Volver", 18, true);
        back.setOnClickListener(v -> finish());
        root.addView(back);

        TextView titleView = text(title == null ? "Comparacion" : title, 24, true);
        titleView.setGravity(Gravity.CENTER);
        titleView.setPadding(0, dp(8), 0, 0);
        root.addView(titleView);

        TextView sub = text(subtitle == null ? "Mueve la barra inferior" : subtitle, 14, false);
        sub.setGravity(Gravity.CENTER);
        sub.setTextColor(Color.rgb(180, 180, 186));
        sub.setPadding(0, dp(4), 0, dp(10));
        root.addView(sub);

        preview = new FrameLayout(this);
        preview.setBackgroundColor(Color.BLACK);
        root.addView(preview, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(600)));

        playerView = new PlayerView(this);
        playerView.setUseController(false);
        preview.addView(playerView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        afterOverlay = new View(this);
        afterOverlay.setBackgroundColor(Color.argb(42, 255, 255, 255));
        preview.addView(afterOverlay, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        divider = new View(this);
        divider.setBackgroundColor(Color.WHITE);
        preview.addView(divider, new FrameLayout.LayoutParams(dp(3), ViewGroup.LayoutParams.MATCH_PARENT));

        beforeLabel = label("Before", Gravity.BOTTOM | Gravity.LEFT);
        afterLabel = label("After", Gravity.BOTTOM | Gravity.RIGHT);
        preview.addView(beforeLabel);
        preview.addView(afterLabel);

        compareSeek = new SeekBar(this);
        compareSeek.setMax(100);
        compareSeek.setProgress(compareProgress);
        root.addView(compareSeek);
        compareSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                compareProgress = progress;
                updateCompare();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        TextView tip = text("La regla se mueve con esta barra. No se duplica.", 13, false);
        tip.setGravity(Gravity.CENTER);
        tip.setTextColor(Color.rgb(180, 180, 186));
        root.addView(tip);

        setContentView(root);

        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        player.setRepeatMode(Player.REPEAT_MODE_ONE);

        if (uriText != null) {
            Uri uri = Uri.parse(uriText);
            player.setMediaItem(MediaItem.fromUri(uri));
            player.prepare();
            player.play();
        }

        preview.post(this::updateCompare);
    }

    private void updateCompare() {
        if (preview == null || preview.getWidth() == 0) return;

        int w = preview.getWidth();
        int h = preview.getHeight();
        int x = (int)(w * (compareProgress / 100f));

        FrameLayout.LayoutParams overlay = (FrameLayout.LayoutParams) afterOverlay.getLayoutParams();
        overlay.width = Math.max(0, w - x);
        overlay.height = h;
        overlay.gravity = Gravity.RIGHT;
        afterOverlay.setLayoutParams(overlay);

        FrameLayout.LayoutParams line = (FrameLayout.LayoutParams) divider.getLayoutParams();
        line.width = dp(3);
        line.height = h;
        line.leftMargin = Math.max(0, x - dp(1));
        divider.setLayoutParams(line);

        divider.bringToFront();
        beforeLabel.bringToFront();
        afterLabel.bringToFront();
    }

    private TextView label(String text, int gravity) {
        TextView v = text(text, 18, true);
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, gravity);
        p.leftMargin = dp(14);
        p.rightMargin = dp(14);
        p.bottomMargin = dp(14);
        v.setLayoutParams(p);
        return v;
    }

    private TextView text(String value, int size, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextColor(Color.WHITE);
        v.setTextSize(size);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (player != null) player.pause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (player != null) {
            player.release();
            player = null;
        }
    }
}
