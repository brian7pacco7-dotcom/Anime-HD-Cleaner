package com.zeta.animehdcleaner;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

public class MainActivity extends Activity {

    private static final int REQ_PICK_VIDEO = 1001;

    private Uri selectedVideo;
    private ExoPlayer player;
    private PlayerView playerView;

    private final ExportSettings settings = new ExportSettings();

    private String activeMode = "Brillo";
    private String activeQuality = "1080P";
    private int compareProgress = 50;

    private FrameLayout previewFrame;
    private View afterOverlay;
    private View divider;
    private TextView beforeLabel;
    private TextView afterLabel;
    private SeekBar compareSeek;

    private TextView qualityButton;
    private TextView fileInfo;
    private TextView activeBox;
    private TextView quickTitle;
    private TextView quickValue;
    private SeekBar quickSeek;

    private LinearLayout toolRow;
    private LinearLayout allSliders;

    private Dialog exportDialog;
    private ProgressBar exportProgress;
    private TextView exportPercent;
    private TextView exportState;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private int fakeProgress = 0;
    private boolean exportDone = false;

    private final int dark = Color.rgb(13, 14, 18);
    private final int panel = Color.rgb(28, 30, 36);
    private final int card = Color.rgb(38, 40, 47);
    private final int white = Color.WHITE;
    private final int muted = Color.rgb(160, 164, 171);
    private final int cyan = Color.rgb(16, 210, 255);
    private final int green = Color.rgb(45, 210, 130);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initDefaults();
        buildUi();
        preparePlayer();
        refreshAll();
    }

    private void initDefaults() {
        settings.modeName = activeMode;
        settings.qualityName = activeQuality;
        settings.width = 1080;
        settings.height = 1920;
        settings.fps = 30;
        settings.bitrateMbps = 12;
        settings.brightness = 4;
        settings.contrast = 3;
        settings.saturation = 8;
        settings.shadows = 10;
        settings.denoise = 7;
        settings.sharpen = 5;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.setBackgroundColor(dark);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(12), dp(12), dp(18));
        scroll.addView(root);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(top);

        top.addView(topIcon("X"));
        TextView help = topIcon("?");
        ((LinearLayout.LayoutParams) help.getLayoutParams()).leftMargin = dp(10);
        top.addView(help);

        TextView hd = topIcon("HD");
        ((LinearLayout.LayoutParams) hd.getLayoutParams()).leftMargin = dp(12);
        top.addView(hd);

        View spacer = new View(this);
        top.addView(spacer, new LinearLayout.LayoutParams(0, 1, 1f));

        qualityButton = topPill(activeQuality + " v");
        qualityButton.setOnClickListener(v -> showQualitySelector());
        top.addView(qualityButton);

        Button exportTop = new Button(this);
        exportTop.setText("Exportar");
        exportTop.setAllCaps(false);
        exportTop.setTextSize(16);
        exportTop.setTypeface(Typeface.DEFAULT_BOLD);
        exportTop.setTextColor(Color.BLACK);
        exportTop.setBackgroundColor(cyan);
        LinearLayout.LayoutParams exp = new LinearLayout.LayoutParams(dp(126), dp(52));
        exp.leftMargin = dp(10);
        exportTop.setLayoutParams(exp);
        exportTop.setOnClickListener(v -> showExportConfirm());
        top.addView(exportTop);

        Button importButton = new Button(this);
        importButton.setText("+ Importar video");
        importButton.setAllCaps(false);
        importButton.setTextSize(18);
        importButton.setTypeface(Typeface.DEFAULT_BOLD);
        importButton.setTextColor(Color.BLACK);
        importButton.setBackgroundColor(green);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54));
        ip.topMargin = dp(10);
        root.addView(importButton, ip);
        importButton.setOnClickListener(v -> pickVideo());

        previewFrame = new FrameLayout(this);
        previewFrame.setBackgroundColor(Color.BLACK);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(410));
        pp.topMargin = dp(10);
        root.addView(previewFrame, pp);

        playerView = new PlayerView(this);
        playerView.setUseController(false);
        previewFrame.addView(playerView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        afterOverlay = new View(this);
        afterOverlay.setBackgroundColor(Color.argb(38, 255, 255, 255));
        previewFrame.addView(afterOverlay, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        divider = new View(this);
        divider.setBackgroundColor(Color.WHITE);
        previewFrame.addView(divider, new FrameLayout.LayoutParams(dp(3), ViewGroup.LayoutParams.MATCH_PARENT));

        beforeLabel = previewLabel("Before", Gravity.BOTTOM | Gravity.LEFT);
        afterLabel = previewLabel("After", Gravity.BOTTOM | Gravity.RIGHT);
        previewFrame.addView(beforeLabel);
        previewFrame.addView(afterLabel);
        previewFrame.addView(previewTag("Usa la barra de abajo"));

        compareSeek = new SeekBar(this);
        compareSeek.setMax(100);
        compareSeek.setProgress(compareProgress);
        compareSeek.setPadding(0, dp(4), 0, dp(2));
        root.addView(compareSeek);
        compareSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                compareProgress = progress;
                updateCompareViews();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        LinearLayout quick = panelBox();
        LinearLayout.LayoutParams qp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        qp.topMargin = dp(8);
        root.addView(quick, qp);

        quickTitle = infoBold("Ajuste rapido");
        quick.addView(quickTitle);

        quickValue = info("Valor aplicado ahora");
        quick.addView(quickValue);

        quickSeek = new SeekBar(this);
        quick.addView(quickSeek);
        quickSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                applyQuickValue(progress);
                refreshAll();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                Toast.makeText(MainActivity.this, "Cambio guardado", Toast.LENGTH_SHORT).show();
            }
        });

        activeBox = info("");
        quick.addView(activeBox);

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setPadding(0, dp(8), 0, 0);
        quick.addView(buttons);
        buttons.addView(actionButton("Pantalla completa", () -> openFullscreen()));
        buttons.addView(actionButton("Exportar ahora", () -> showExportConfirm()));

        LinearLayout toolsPanel = panelBox();
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tp.topMargin = dp(8);
        root.addView(toolsPanel, tp);

        fileInfo = info("");
        toolsPanel.addView(fileInfo);

        TextView sectionTitle = infoBold("Herramientas");
        sectionTitle.setPadding(0, dp(8), 0, dp(6));
        toolsPanel.addView(sectionTitle);

        HorizontalScrollView toolScroll = new HorizontalScrollView(this);
        toolScroll.setHorizontalScrollBarEnabled(false);
        toolRow = new LinearLayout(this);
        toolRow.setOrientation(LinearLayout.HORIZONTAL);
        toolScroll.addView(toolRow);
        toolsPanel.addView(toolScroll);
        rebuildTools();

        TextView slidersTitle = infoBold("Todos los ajustes visibles");
        slidersTitle.setPadding(0, dp(14), 0, dp(6));
        toolsPanel.addView(slidersTitle);

        allSliders = new LinearLayout(this);
        allSliders.setOrientation(LinearLayout.VERTICAL);
        toolsPanel.addView(allSliders);
        rebuildAllSliders();

        setContentView(scroll);
        previewFrame.post(this::updateCompareViews);
    }

    private void rebuildTools() {
        toolRow.removeAllViews();
        toolRow.addView(tool("Brillo", activeMode.equals("Brillo"), () -> setMode("Brillo")));
        toolRow.addView(tool("Contraste", activeMode.equals("Contraste"), () -> setMode("Contraste")));
        toolRow.addView(tool("Saturacion", activeMode.equals("Saturacion"), () -> setMode("Saturacion")));
        toolRow.addView(tool("Sombras", activeMode.equals("Sombras"), () -> setMode("Sombras")));
        toolRow.addView(tool("Nitidez", activeMode.equals("Nitidez"), () -> setMode("Nitidez")));
        toolRow.addView(tool("Ruido", activeMode.equals("Ruido"), () -> setMode("Ruido")));
        toolRow.addView(tool("Anime HD", activeMode.equals("Anime HD"), () -> {
            settings.sharpen = 7;
            settings.saturation = 9;
            setMode("Anime HD");
        }));
    }

    private void rebuildAllSliders() {
        allSliders.removeAllViews();
        allSliders.addView(sliderRow("Brillo", 0, 10, settings.brightness, v -> settings.brightness = v));
        allSliders.addView(sliderRow("Contraste", 0, 10, settings.contrast, v -> settings.contrast = v));
        allSliders.addView(sliderRow("Saturacion", 0, 15, settings.saturation, v -> settings.saturation = v));
        allSliders.addView(sliderRow("Sombras", 0, 20, settings.shadows, v -> settings.shadows = v));
        allSliders.addView(sliderRow("Nitidez", 0, 10, settings.sharpen, v -> settings.sharpen = v));
        allSliders.addView(sliderRow("Ruido", 0, 15, settings.denoise, v -> settings.denoise = v));
    }

    private interface SetInt { void set(int value); }

    private View sliderRow(String name, int min, int max, int current, SetInt setter) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(4), 0, dp(4));

        TextView label = info(name + ": " + current);
        box.addView(label);

        SeekBar seek = new SeekBar(this);
        seek.setMax(max - min);
        seek.setProgress(current - min);
        box.addView(seek);

        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int real = min + progress;
                setter.set(real);
                label.setText(name + ": " + real);
                refreshAll();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                Toast.makeText(MainActivity.this, "Guardado: " + name, Toast.LENGTH_SHORT).show();
            }
        });
        return box;
    }

    private void setMode(String mode) {
        activeMode = mode;
        settings.modeName = mode;
        rebuildTools();
        syncQuickSlider();
        refreshAll();
        Toast.makeText(this, mode + " seleccionado", Toast.LENGTH_SHORT).show();
    }

    private void syncQuickSlider() {
        quickTitle.setText("Ajuste rapido: " + activeMode);
        if (activeMode.equals("Brillo")) {
            quickSeek.setMax(10);
            quickSeek.setProgress(settings.brightness);
        } else if (activeMode.equals("Contraste")) {
            quickSeek.setMax(10);
            quickSeek.setProgress(settings.contrast);
        } else if (activeMode.equals("Saturacion")) {
            quickSeek.setMax(15);
            quickSeek.setProgress(settings.saturation);
        } else if (activeMode.equals("Sombras")) {
            quickSeek.setMax(20);
            quickSeek.setProgress(settings.shadows);
        } else if (activeMode.equals("Nitidez") || activeMode.equals("Anime HD")) {
            quickSeek.setMax(10);
            quickSeek.setProgress(settings.sharpen);
        } else {
            quickSeek.setMax(15);
            quickSeek.setProgress(settings.denoise);
        }
    }

    private void applyQuickValue(int progress) {
        if (activeMode.equals("Brillo")) settings.brightness = progress;
        else if (activeMode.equals("Contraste")) settings.contrast = progress;
        else if (activeMode.equals("Saturacion")) settings.saturation = progress;
        else if (activeMode.equals("Sombras")) settings.shadows = progress;
        else if (activeMode.equals("Nitidez") || activeMode.equals("Anime HD")) settings.sharpen = progress;
        else settings.denoise = progress;
    }

    private void refreshAll() {
        qualityButton.setText(activeQuality + " v");
        fileInfo.setText(selectedVideo == null ? "Video: todavia no cargado" : "Video cargado: " + getFileName(selectedVideo));
        quickTitle.setText("Ajuste rapido: " + activeMode);
        quickValue.setText("Valor aplicado ahora: " + getActiveValue() + " | guardado para exportar");

        activeBox.setText(
                "\nCambios activos:\n" +
                "Modo: " + activeMode + "\n" +
                "Calidad: " + activeQuality + "\n" +
                "Brillo " + settings.brightness + " | Contraste " + settings.contrast + " | Saturacion " + settings.saturation + "\n" +
                "Sombras " + settings.shadows + " | Nitidez " + settings.sharpen + " | Ruido " + settings.denoise + "\n" +
                "Cada slider queda guardado al instante.\n\n" +
                "Se exportara con:\n" +
                settings.width + "x" + settings.height + " | " + settings.fps + " FPS | " + settings.bitrateMbps + " Mbps\n" +
                "Motor HD real activado."
        );
    }

    private String getActiveValue() {
        if (activeMode.equals("Brillo")) return String.valueOf(settings.brightness);
        if (activeMode.equals("Contraste")) return String.valueOf(settings.contrast);
        if (activeMode.equals("Saturacion")) return String.valueOf(settings.saturation);
        if (activeMode.equals("Sombras")) return String.valueOf(settings.shadows);
        if (activeMode.equals("Nitidez") || activeMode.equals("Anime HD")) return String.valueOf(settings.sharpen);
        return String.valueOf(settings.denoise);
    }

    private void showQualitySelector() {
        String[] options = {"720P", "1080P", "UHD"};
        new AlertDialog.Builder(this)
                .setTitle("Elegir calidad")
                .setItems(options, (d, which) -> {
                    if (which == 0) setQuality("720P", 720, 1280, 30, 8);
                    if (which == 1) setQuality("1080P", 1080, 1920, 30, 12);
                    if (which == 2) setQuality("UHD", 2160, 3840, 30, 35);
                })
                .show();
    }

    private void setQuality(String name, int w, int h, int fps, int mbps) {
        activeQuality = name;
        settings.qualityName = name;
        settings.width = w;
        settings.height = h;
        settings.fps = fps;
        settings.bitrateMbps = mbps;
        refreshAll();
    }

    private void showExportConfirm() {
        if (selectedVideo == null) {
            Toast.makeText(this, "Primero importa un video", Toast.LENGTH_SHORT).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Exportacion HD")
                .setMessage("Se aplicara al archivo final:\n\n" + settings.summary())
                .setPositiveButton("Exportar", (d, w) -> exportHd())
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void exportHd() {
        showProgressDialog();
        fakeProgress = 0;
        exportDone = false;
        stepProgress();

        RealHdExporter.export(this, selectedVideo, settings, new RealHdExporter.Listener() {
            @Override public void onLog(String message) {
                runOnUiThread(() -> exportState.setText(message + "\nNo cierres la app."));
            }

            @Override public void onFinished(boolean success, Uri outputUri, String message) {
                runOnUiThread(() -> {
                    exportDone = true;
                    exportProgress.setProgress(100);
                    exportPercent.setText("100%");
                    exportState.setText(message + "\nCambios aplicados.");
                    handler.postDelayed(() -> {
                        if (exportDialog != null && exportDialog.isShowing()) exportDialog.dismiss();
                        Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
                    }, 1200);
                });
            }
        });
    }

    private void showProgressDialog() {
        exportDialog = new Dialog(this);
        exportDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(20), dp(20), dp(20));
        box.setBackgroundColor(card);

        TextView title = infoBold("Procesando exportacion HD");
        title.setTextSize(22);
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        box.addView(title);

        exportProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        exportProgress.setMax(100);
        exportProgress.setProgress(0);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        pp.topMargin = dp(16);
        box.addView(exportProgress, pp);

        exportPercent = infoBold("0%");
        exportPercent.setGravity(Gravity.CENTER_HORIZONTAL);
        exportPercent.setTextSize(20);
        exportPercent.setPadding(0, dp(8), 0, dp(8));
        box.addView(exportPercent);

        exportState = info("Preparando...");
        exportState.setGravity(Gravity.CENTER_HORIZONTAL);
        box.addView(exportState);

        exportDialog.setContentView(box);
        exportDialog.setCancelable(false);
        exportDialog.show();
    }

    private void stepProgress() {
        if (exportDone) return;
        fakeProgress += fakeProgress < 70 ? 8 : 2;
        if (fakeProgress > 95) fakeProgress = 95;
        exportProgress.setProgress(fakeProgress);
        exportPercent.setText(fakeProgress + "%");

        String msg;
        if (fakeProgress < 20) msg = "Analizando video...";
        else if (fakeProgress < 40) msg = "Aplicando ajustes...";
        else if (fakeProgress < 60) msg = "Procesando motor HD...";
        else if (fakeProgress < 80) msg = "Codificando salida...";
        else msg = "Guardando archivo final...";
        exportState.setText(msg + "\nNo cierres la app.");
        handler.postDelayed(this::stepProgress, 700);
    }

    private void pickVideo() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("video/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "video/mp4", "video/quicktime", "video/x-matroska", "video/webm",
                "video/x-msvideo", "video/3gpp", "video/x-ms-wmv", "video/*"
        });
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, REQ_PICK_VIDEO);
    }

    private void openFullscreen() {
        if (selectedVideo == null) {
            Toast.makeText(this, "Primero importa un video", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(this, FullscreenCompareActivity.class);
        i.putExtra("video_uri", selectedVideo.toString());
        i.putExtra("title", activeMode);
        i.putExtra("subtitle", "Mueve la barra inferior");
        i.putExtra("compare_progress", compareProgress);
        startActivity(i);
    }

    private void preparePlayer() {
        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        player.setRepeatMode(Player.REPEAT_MODE_ONE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PICK_VIDEO && resultCode == RESULT_OK && data != null) {
            selectedVideo = data.getData();
            if (selectedVideo != null) {
                try {
                    getContentResolver().takePersistableUriPermission(selectedVideo, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Exception ignored) {}
                player.setMediaItem(MediaItem.fromUri(selectedVideo));
                player.prepare();
                player.play();
                refreshAll();
            }
        }
    }

    private String getFileName(Uri uri) {
        String result = "video seleccionado";
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) result = cursor.getString(idx);
            }
        } catch (Exception ignored) {}
        return result;
    }

    private void updateCompareViews() {
        if (previewFrame == null || previewFrame.getWidth() == 0) return;

        int w = previewFrame.getWidth();
        int h = previewFrame.getHeight();
        int x = (int)(w * (compareProgress / 100f));

        FrameLayout.LayoutParams overlay = (FrameLayout.LayoutParams) afterOverlay.getLayoutParams();
        overlay.width = Math.max(0, w - x);
        overlay.height = h;
        overlay.gravity = Gravity.RIGHT;
        afterOverlay.setLayoutParams(overlay);

        FrameLayout.LayoutParams line = (FrameLayout.LayoutParams) divider.getLayoutParams();
        line.width = dp(3);
        line.height = h;
        line.leftMargin = Math.max(0, x - dp(1));
        divider.setLayoutParams(line);

        divider.bringToFront();
        beforeLabel.bringToFront();
        afterLabel.bringToFront();
    }

    private LinearLayout panelBox() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(panel);
        box.setPadding(dp(12), dp(10), dp(12), dp(12));
        return box;
    }

    private TextView topIcon(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(white);
        v.setTextSize(20);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setGravity(Gravity.CENTER);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(42), dp(52)));
        return v;
    }

    private TextView topPill(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(white);
        v.setTextSize(16);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setGravity(Gravity.CENTER);
        v.setBackgroundColor(card);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(112), dp(52)));
        return v;
    }

    private TextView previewLabel(String text, int gravity) {
        TextView v = infoBold(text);
        v.setTextSize(18);
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, gravity);
        p.leftMargin = dp(14);
        p.rightMargin = dp(14);
        p.bottomMargin = dp(14);
        v.setLayoutParams(p);
        return v;
    }

    private TextView previewTag(String text) {
        TextView v = infoBold(text);
        v.setTextSize(12);
        v.setBackgroundColor(Color.argb(150, 0, 0, 0));
        v.setPadding(dp(10), dp(6), dp(10), dp(6));
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.RIGHT);
        p.rightMargin = dp(12);
        p.topMargin = dp(12);
        v.setLayoutParams(p);
        return v;
    }

    private View actionButton(String text, Runnable action) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(white);
        b.setBackgroundColor(card);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(44), 1f);
        p.rightMargin = dp(8);
        b.setLayoutParams(p);
        b.setOnClickListener(v -> action.run());
        return b;
    }

    private TextView tool(String text, boolean active, Runnable action) {
        TextView v = new TextView(this);
        v.setText((active ? "OK\n" : "O\n") + text);
        v.setTextColor(active ? cyan : white);
        v.setTextSize(13);
        v.setGravity(Gravity.CENTER);
        v.setBackgroundColor(card);
        v.setTypeface(active ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        v.setPadding(dp(6), dp(8), dp(6), dp(8));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(108), dp(76));
        p.rightMargin = dp(10);
        v.setLayoutParams(p);
        v.setOnClickListener(view -> action.run());
        return v;
    }

    private TextView info(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(white);
        v.setTextSize(13);
        return v;
    }

    private TextView infoBold(String text) {
        TextView v = info(text);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (player != null) player.pause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
        if (player != null) {
            player.release();
            player = null;
        }
    }
}
