# Instrucciones V7.0

1. Borra el ZIP anterior.
2. Sube este ZIP.
3. Ejecuta Actions.
4. Descarga el APK.
