# Instrucciones V6.8 REAL HD PRO

1. Borra el ZIP anterior del repositorio.
2. Sube este ZIP.
3. Ejecuta Actions.
4. Descarga el APK.
5. Instala.
6. Presiona + Importar video.
7. Ajusta y exporta.

Esta versión NO es la versión sin motor. Mantiene el motor HD real.
