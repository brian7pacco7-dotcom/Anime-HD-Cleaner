# Anime HD Cleaner V11 REAL OFFLINE ENGINE

Esta versión cambia el motor. Ya no copia el video igual.

## Motor real offline
Al exportar usa Android MediaCodec + MediaMuxer + MediaMetadataRetriever para:
- leer frames del video
- aplicar filtros de color reales con ColorMatrix
- re-encodificar a MP4 H.264
- aplicar resolución de salida
- aplicar FPS seleccionado
- aplicar bitrate seleccionado
- conservar audio si el video original tiene audio

## Filtros reales aplicados
- Brillo
- Contraste
- Saturación
- Luz / luminosidad

## Exportación PRO
- Calidad
- FPS
- Bitrate
- Peso estimado
- Resolución
- Historial
- Abrir / compartir video exportado

## Limitaciones
- Puede demorar bastante porque procesa frame por frame.
- Para videos largos puede calentar el celular.
- Enfoque y ruido quedan como valores de plantilla, pero el motor real actual aplica color/luz/resolución/FPS/bitrate.
- No usa IA real.
