package com.zeta.animehdcleaner;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.ui.PlayerView;

public class EditorActivity extends Activity {

    private static final int REQ_PICK_VIDEO = 1001;

    private Uri selectedVideo;
    private VideoPlayerManager playerManager;
    private ExportSettings settings = new ExportSettings();

    private CompareView compareView;
    private TextView qualityButton;
    private TextView playButton;
    private TextView activeText;
    private TextView fileText;
    private TextView detailText;
    private GridLayout presetGrid;
    private GridLayout sliderGrid;

    private Dialog dialog;
    private ProgressBar progressBar;
    private TextView progressText;
    private TextView progressMessage;
    private Handler handler = new Handler(Looper.getMainLooper());
    private int fakeProgress = 0;
    private boolean processDone = false;

    private final int bg = 0xFF090D12;
    private final int panel = 0xFF12181F;
    private final int card = 0xFF1F2530;
    private final int cyan = 0xFF11D2FF;
    private final int green = 0xFF1CC07D;
    private final int white = 0xFFFFFFFF;
    private final int muted = 0xFFB0B5BC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String uriText = getIntent().getStringExtra("video_uri");
        if (uriText != null) selectedVideo = Uri.parse(uriText);

        buildUi();

        if (selectedVideo != null) {
            loadVideo(selectedVideo);
        }
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(8), dp(8), dp(8), dp(8));
        root.setBackgroundColor(bg);

        LinearLayout top = row();
        root.addView(top, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));

        top.addView(topIcon("X"));
        top.addView(topIcon("?"));
        top.addView(topIcon("HD"));

        View spacer = new View(this);
        top.addView(spacer, new LinearLayout.LayoutParams(0, 1, 1f));

        qualityButton = pill(settings.qualityName + " v", dp(96), dp(42));
        qualityButton.setOnClickListener(v -> chooseQuality());
        top.addView(qualityButton);

        Button exportButton = button("Exportar", cyan, 0xFF000000);
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(dp(108), dp(42));
        ep.leftMargin = dp(8);
        top.addView(exportButton, ep);
        exportButton.setOnClickListener(v -> openExport());

        Button importButton = button("+ Importar video", green, 0xFF000000);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42));
        ip.topMargin = dp(6);
        root.addView(importButton, ip);
        importButton.setOnClickListener(v -> pickVideo());

        FrameLayout preview = new FrameLayout(this);
        preview.setBackgroundColor(0xFF000000);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 3.0f);
        pp.topMargin = dp(6);
        root.addView(preview, pp);

        PlayerView playerView = new PlayerView(this);
        playerView.setUseController(false);
        preview.addView(playerView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        compareView = new CompareView(this);
        preview.addView(compareView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        playerManager = new VideoPlayerManager(this, playerView);

        SeekBar compareSlider = new SeekBar(this);
        compareSlider.setMax(100);
        compareSlider.setProgress(50);
        root.addView(compareSlider, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(26)));
        compareSlider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                compareView.setProgress(progress / 100f);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        LinearLayout controls = row();
        root.addView(controls, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)));

        TextView time = smallBox("00:00");
        controls.addView(time, new LinearLayout.LayoutParams(0, dp(38), 0.9f));
        controls.addView(control("-5s", () -> {
            if (playerManager != null) playerManager.seekBy(-5000);
        }));
        playButton = controlText("Play", () -> togglePlay());
        controls.addView(playButton);
        controls.addView(control("+5s", () -> {
            if (playerManager != null) playerManager.seekBy(5000);
        }));
        controls.addView(control("Full", () -> openFullscreen()));

        LinearLayout presetsPanel = panelBox();
        LinearLayout.LayoutParams pp2 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(148));
        pp2.topMargin = dp(6);
        root.addView(presetsPanel, pp2);

        LinearLayout header = row();
        presetsPanel.addView(header, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(28)));

        TextView title = text("Presets / plantillas", 15, true, cyan);
        header.addView(title, new LinearLayout.LayoutParams(0, dp(28), 1f));

        activeText = text("✓ Activo: " + settings.modeName, 11, true, white);
        activeText.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        header.addView(activeText, new LinearLayout.LayoutParams(0, dp(28), 1f));

        Button templatesButton = button("Plantillas", cyan, 0xFF000000);
        LinearLayout.LayoutParams templateParams = new LinearLayout.LayoutParams(dp(86), dp(28));
        templateParams.leftMargin = dp(6);
        header.addView(templatesButton, templateParams);
        templatesButton.setOnClickListener(v -> showTemplates());

        presetGrid = new GridLayout(this);
        presetGrid.setColumnCount(3);
        presetGrid.setRowCount(2);
        presetsPanel.addView(presetGrid, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        rebuildPresets();

        LinearLayout adjustPanel = panelBox();
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(166));
        ap.topMargin = dp(6);
        root.addView(adjustPanel, ap);

        LinearLayout adjustHeader = row();
        adjustPanel.addView(adjustHeader, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(28)));

        TextView adjustTitle = text("Filtros reales", 15, true, white);
        adjustHeader.addView(adjustTitle, new LinearLayout.LayoutParams(0, dp(28), 1f));

        Button apply = button("Vista", cyan, 0xFF000000);
        adjustHeader.addView(apply, new LinearLayout.LayoutParams(dp(86), dp(28)));
        apply.setOnClickListener(v -> previewProcess());

        sliderGrid = new GridLayout(this);
        sliderGrid.setColumnCount(3);
        sliderGrid.setRowCount(2);
        adjustPanel.addView(sliderGrid, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        rebuildSliders();

        LinearLayout bottomInfo = row();
        root.addView(bottomInfo, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(28)));

        detailText = text("Exportar: peso, FPS, bitrate y resolucion.", 10, false, muted);
        detailText.setSingleLine(true);
        bottomInfo.addView(detailText, new LinearLayout.LayoutParams(0, dp(28), 1f));

        Button historyButton = button("Historial", card, white);
        bottomInfo.addView(historyButton, new LinearLayout.LayoutParams(dp(86), dp(28)));
        historyButton.setOnClickListener(v -> startActivity(new Intent(this, HistoryActivity.class)));

        fileText = text("Video: no cargado", 10, false, muted);
        fileText.setSingleLine(true);
        root.addView(fileText, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(18)));

        setContentView(root);
    }


    private void showTemplates() {
        new AlertDialog.Builder(this)
                .setTitle("Plantillas locales")
                .setItems(TemplateManager.TEMPLATES, (dialog, which) -> {
                    String template = TemplateManager.TEMPLATES[which];
                    TemplateManager.apply(template, settings);
                    refreshUi();
                    rebuildPresets();
                    rebuildSliders();
                    Toast.makeText(this, "Plantilla aplicada: " + template, Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private void rebuildPresets() {
        presetGrid.removeAllViews();
        String[] visible = {
                "Anime HD",
                "Reparacion IA",
                "Color IA",
                "Quitar ruido",
                "Sombras limpias",
                "IA 4K+"
        };
        for (String preset : visible) {
            presetGrid.addView(presetButton(preset));
        }
    }

    private TextView presetButton(String preset) {
        boolean active = preset.equals(settings.modeName);
        String mark = active ? "✓ " : "";
        TextView v = text(mark + iconFor(preset) + "\n" + preset, 10, active, active ? cyan : white);
        v.setGravity(Gravity.CENTER);
        v.setBackgroundColor(card);
        v.setPadding(dp(4), dp(4), dp(4), dp(4));
        GridLayout.LayoutParams gp = new GridLayout.LayoutParams();
        gp.width = 0;
        gp.height = dp(46);
        gp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        gp.setMargins(dp(3), dp(3), dp(3), dp(3));
        v.setLayoutParams(gp);
        v.setOnClickListener(view -> {
            PresetManager.apply(preset, settings);
            refreshUi();
            rebuildPresets();
            rebuildSliders();
            Toast.makeText(this, "Preset guardado: " + preset, Toast.LENGTH_SHORT).show();
        });
        return v;
    }

    private void rebuildSliders() {
        sliderGrid.removeAllViews();
        sliderGrid.addView(compactSlider("Brillo", 0, 20, settings.brightness, v -> settings.brightness = v));
        sliderGrid.addView(compactSlider("Contraste", 0, 20, settings.contrast, v -> settings.contrast = v));
        sliderGrid.addView(compactSlider("Saturacion", 0, 20, settings.saturation, v -> settings.saturation = v));
        sliderGrid.addView(compactSlider("Luz", 0, 20, settings.luminosity, v -> settings.luminosity = v));
        sliderGrid.addView(compactSlider("Enfoque", 0, 20, settings.sharpen, v -> settings.sharpen = v));
        sliderGrid.addView(compactSlider("Ruido", 0, 20, settings.denoise, v -> settings.denoise = v));
    }

    private String iconFor(String preset) {
        if (preset.contains("Color")) return "CLR";
        if (preset.contains("ruido")) return "NR";
        if (preset.contains("4K")) return "4K+";
        if (preset.contains("Sombras")) return "SUN";
        if (preset.contains("Reparacion")) return "HD";
        return "AI";
    }

    private void refreshUi() {
        qualityButton.setText(settings.qualityName + " v");
        activeText.setText("✓ Activo: " + settings.modeName);
        detailText.setText(settings.qualityName + " · " + settings.fps + " FPS · " + settings.bitrateMbps + " Mbps · " + settings.width + "x" + settings.height + " · motor real");
        if (fileText != null) fileText.setText(selectedVideo == null ? "Video: no cargado" : "Video: " + getFileName(selectedVideo));
    }

    private interface SetInt { void set(int value); }

    private View compactSlider(String name, int min, int max, int current, SetInt setter) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(3), dp(2), dp(3), dp(2));
        box.setBackgroundColor(panel);

        TextView label = text(name, 10, false, white);
        label.setGravity(Gravity.CENTER);
        box.addView(label, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(16)));

        TextView value = text(String.valueOf(current), 12, true, cyan);
        value.setGravity(Gravity.CENTER);
        box.addView(value, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(16)));

        SeekBar seek = new SeekBar(this);
        seek.setMax(max - min);
        seek.setProgress(current - min);
        box.addView(seek, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(30)));

        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int real = min + progress;
                setter.set(real);
                value.setText(String.valueOf(real));
                activeText.setText("✓ " + name + ": " + real);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                refreshUi();
            }
        });

        GridLayout.LayoutParams gp = new GridLayout.LayoutParams();
        gp.width = 0;
        gp.height = dp(58);
        gp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        gp.setMargins(dp(3), dp(3), dp(3), dp(3));
        box.setLayoutParams(gp);
        return box;
    }

    private void togglePlay() {
        if (selectedVideo == null) {
            Toast.makeText(this, "Primero importa un video", Toast.LENGTH_SHORT).show();
            return;
        }
        playerManager.toggle();
        playButton.setText(playerManager.isPlaying() ? "Pausa" : "Play");
    }

    private void previewProcess() {
        if (selectedVideo == null) {
            Toast.makeText(this, "Primero importa un video", Toast.LENGTH_SHORT).show();
            return;
        }
        showProgress("Preparando vista");
        fakeProgress = 0;
        processDone = false;
        stepPreviewProgress();
    }

    private void stepPreviewProgress() {
        if (processDone) return;
        fakeProgress += 8;
        if (fakeProgress > 100) fakeProgress = 100;
        progressBar.setProgress(fakeProgress);
        progressText.setText(fakeProgress + "%");
        progressMessage.setText("Vista previa abierta.\nLos filtros reales se aplican al exportar.");

        if (fakeProgress >= 100) {
            processDone = true;
            progressMessage.setText("Listo. Revisa Original / Despues.");
            handler.postDelayed(() -> {
                if (dialog != null && dialog.isShowing()) dialog.dismiss();
                openFullscreen();
            }, 650);
            return;
        }
        handler.postDelayed(this::stepPreviewProgress, 140);
    }

    private void showProgress(String title) {
        dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(20), dp(20), dp(20));
        box.setBackgroundColor(card);

        TextView titleView = text(title, 22, true, white);
        titleView.setGravity(Gravity.CENTER);
        box.addView(titleView);

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        pp.topMargin = dp(16);
        box.addView(progressBar, pp);

        progressText = text("0%", 20, true, white);
        progressText.setGravity(Gravity.CENTER);
        progressText.setPadding(0, dp(8), 0, dp(8));
        box.addView(progressText);

        progressMessage = text("Preparando...", 14, false, white);
        progressMessage.setGravity(Gravity.CENTER);
        box.addView(progressMessage);

        Button cancel = button("Cancelar", panel, white);
        cancel.setOnClickListener(v -> {
            processDone = true;
            if (dialog != null && dialog.isShowing()) dialog.dismiss();
        });
        box.addView(cancel);

        dialog.setContentView(box);
        dialog.setCancelable(false);
        dialog.show();
    }

    private void chooseQuality() {
        String[] options = {"720P · 30 FPS · 8 Mbps", "1080P · 30 FPS · 12 Mbps", "1080P 60 · 60 FPS · 15 Mbps", "2K · 30 FPS · 20 Mbps", "4K · 30 FPS · 35 Mbps"};
        new AlertDialog.Builder(this)
                .setTitle("Elegir calidad")
                .setItems(options, (d, which) -> {
                    if (which == 0) setQuality("720P", 720, 1280, 30, 8);
                    if (which == 1) setQuality("1080P", 1080, 1920, 30, 12);
                    if (which == 2) setQuality("1080P 60", 1080, 1920, 60, 15);
                    if (which == 3) setQuality("2K", 1440, 2560, 30, 20);
                    if (which == 4) setQuality("4K", 2160, 3840, 30, 35);
                    refreshUi();
                }).show();
    }

    private void setQuality(String name, int width, int height, int fps, int bitrate) {
        settings.qualityName = name;
        settings.width = width;
        settings.height = height;
        settings.fps = fps;
        settings.bitrateMbps = bitrate;
    }

    private void openExport() {
        if (selectedVideo == null) {
            Toast.makeText(this, "Primero importa un video", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(this, ExportActivity.class);
        i.putExtra("video_uri", selectedVideo.toString());
        i.putExtra("settings", settings);
        startActivity(i);
    }

    private void openFullscreen() {
        if (selectedVideo == null) {
            Toast.makeText(this, "Primero importa un video", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(this, FullscreenCompareActivity.class);
        i.putExtra("video_uri", selectedVideo.toString());
        i.putExtra("title", settings.modeName);
        i.putExtra("compare_progress", compareView.getProgress());
        startActivity(i);
    }

    private void pickVideo() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("video/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, REQ_PICK_VIDEO);
    }

    private void loadVideo(Uri uri) {
        selectedVideo = uri;
        playerManager.load(uri);
        playerManager.play();
        playButton.setText("Pausa");
        refreshUi();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PICK_VIDEO && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                try {
                    getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Exception ignored) {}
                loadVideo(uri);
            }
        }
    }

    private String getFileName(Uri uri) {
        String result = "video seleccionado";
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) result = cursor.getString(idx);
            }
        } catch (Exception ignored) {}
        return result;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        return r;
    }

    private LinearLayout panelBox() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(panel);
        box.setPadding(dp(8), dp(6), dp(8), dp(6));
        return box;
    }

    private TextView topIcon(String value) {
        TextView v = text(value, 20, true, white);
        v.setGravity(Gravity.CENTER);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(42), dp(42)));
        return v;
    }

    private TextView pill(String value, int width, int height) {
        TextView v = text(value, 15, true, white);
        v.setGravity(Gravity.CENTER);
        v.setBackgroundColor(card);
        v.setLayoutParams(new LinearLayout.LayoutParams(width, height));
        return v;
    }

    private TextView smallBox(String value) {
        TextView v = text(value, 12, false, white);
        v.setGravity(Gravity.CENTER);
        v.setBackgroundColor(card);
        return v;
    }

    private View control(String label, Runnable action) {
        Button b = button(label, card, white);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(38), 1f);
        p.leftMargin = dp(6);
        b.setLayoutParams(p);
        b.setOnClickListener(v -> action.run());
        return b;
    }

    private TextView controlText(String label, Runnable action) {
        TextView b = text(label, 13, false, white);
        b.setGravity(Gravity.CENTER);
        b.setBackgroundColor(card);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(38), 1f);
        p.leftMargin = dp(6);
        b.setLayoutParams(p);
        b.setOnClickListener(v -> action.run());
        return b;
    }

    private Button button(String label, int bg, int fg) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(fg);
        b.setBackgroundColor(bg);
        b.setAllCaps(false);
        b.setTextSize(13);
        return b;
    }

    private TextView text(String value, int size, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(color);
        t.setTextSize(size);
        if (bold) t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        return t;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (playerManager != null) playerManager.pause();
        if (playButton != null) playButton.setText("Play");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
        if (playerManager != null) playerManager.release();
    }
}
