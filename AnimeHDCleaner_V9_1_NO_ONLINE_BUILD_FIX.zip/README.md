# Anime HD Cleaner V9.1 NO ONLINE BUILD FIX

Versión corregida para compilar en GitHub Actions.

## Cambios
- Se quitó IA online por ahora.
- Se quitó permiso INTERNET.
- Se agregó gradle.properties para AndroidX/Media3.
- Mantiene interfaz tipo editor.
- Mantiene importar video.
- Mantiene reproductor con -5s, Play/Pausa, +5s y pantalla.
- Mantiene timeline visual simple.
- Mantiene panel Mejoras IA locales:
  - Anime HD
  - Reparación IA
  - Color IA
  - Quitar ruido
  - Sombras
  - IA 4K+
- Mantiene ajustes:
  - Brillo
  - Contraste
  - Saturación
  - Luminosidad
  - Enfocar
  - Ruido
- Mantiene Antes/Después.
- Mantiene exportación sin marca de agua a Movies/AnimeHDCleaner.

## Nota
Esta versión no usa servidor ni internet. Es para que compile e instale sin ese problema.
