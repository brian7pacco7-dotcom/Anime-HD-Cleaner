package com.zeta.animehdcleaner;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

public class MainActivity extends Activity {

    private static final int REQ_PICK_VIDEO = 1001;

    private Uri selectedVideo;
    private ExoPlayer player;
    private PlayerView playerView;
    private final ExportSettings settings = new ExportSettings();

    private String activeMode = "Anime HD";
    private String activeQuality = "1080P";
    private int compareProgress = 50;

    private FrameLayout previewFrame;
    private View beforeOverlay;
    private View divider;
    private TextView beforeLabel;
    private TextView afterLabel;
    private SeekBar compareSeek;

    private TextView qualityButton;
    private TextView fileInfo;
    private TextView activeText;
    private TextView playButton;
    private LinearLayout aiRow;
    private LinearLayout tabsRow;

    private Dialog processDialog;
    private ProgressBar processProgress;
    private TextView processPercent;
    private TextView processState;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean processDone = false;
    private int fakeProgress = 0;

    private final int dark = Color.rgb(9, 13, 18);
    private final int panel = Color.rgb(18, 24, 31);
    private final int card = Color.rgb(31, 37, 47);
    private final int white = Color.WHITE;
    private final int muted = Color.rgb(175, 180, 188);
    private final int cyan = Color.rgb(17, 210, 255);
    private final int green = Color.rgb(28, 190, 125);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        preparePlayer();
        applyPreset("Anime HD", false);
        refreshUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.setBackgroundColor(dark);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(12), dp(12), dp(18));
        scroll.addView(root);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(top);

        top.addView(topIcon("X"));
        TextView help = topIcon("?");
        ((LinearLayout.LayoutParams) help.getLayoutParams()).leftMargin = dp(8);
        top.addView(help);

        TextView logo = topIcon("HD");
        ((LinearLayout.LayoutParams) logo.getLayoutParams()).leftMargin = dp(8);
        top.addView(logo);

        View spacer = new View(this);
        top.addView(spacer, new LinearLayout.LayoutParams(0, 1, 1f));

        qualityButton = topPill(activeQuality + " v");
        qualityButton.setOnClickListener(v -> showQualitySelector());
        top.addView(qualityButton);

        Button exportTop = new Button(this);
        exportTop.setText("Exportar");
        exportTop.setAllCaps(false);
        exportTop.setTextSize(16);
        exportTop.setTypeface(Typeface.DEFAULT_BOLD);
        exportTop.setTextColor(Color.BLACK);
        exportTop.setBackgroundColor(cyan);
        LinearLayout.LayoutParams exp = new LinearLayout.LayoutParams(dp(126), dp(52));
        exp.leftMargin = dp(10);
        exportTop.setLayoutParams(exp);
        exportTop.setOnClickListener(v -> showExportConfirm());
        top.addView(exportTop);

        Button importButton = new Button(this);
        importButton.setText("+ Importar video");
        importButton.setAllCaps(false);
        importButton.setTextSize(18);
        importButton.setTypeface(Typeface.DEFAULT_BOLD);
        importButton.setTextColor(Color.BLACK);
        importButton.setBackgroundColor(green);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54));
        ip.topMargin = dp(10);
        root.addView(importButton, ip);
        importButton.setOnClickListener(v -> pickVideo());

        previewFrame = new FrameLayout(this);
        previewFrame.setBackgroundColor(Color.BLACK);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(380));
        pp.topMargin = dp(10);
        root.addView(previewFrame, pp);

        playerView = new PlayerView(this);
        playerView.setUseController(false);
        previewFrame.addView(playerView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        beforeOverlay = new View(this);
        beforeOverlay.setBackgroundColor(Color.argb(85, 0, 0, 0));
        previewFrame.addView(beforeOverlay, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        divider = new View(this);
        divider.setBackgroundColor(Color.WHITE);
        previewFrame.addView(divider, new FrameLayout.LayoutParams(dp(3), ViewGroup.LayoutParams.MATCH_PARENT));

        beforeLabel = previewLabel("Before", Gravity.BOTTOM | Gravity.LEFT);
        afterLabel = previewLabel("After", Gravity.BOTTOM | Gravity.RIGHT);
        previewFrame.addView(beforeLabel);
        previewFrame.addView(afterLabel);
        previewFrame.addView(previewTag("Comparar"));

        previewFrame.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN || event.getAction() == MotionEvent.ACTION_MOVE) {
                updateCompareFromTouch(event.getX());
                return true;
            }
            return false;
        });

        compareSeek = new SeekBar(this);
        compareSeek.setMax(100);
        compareSeek.setProgress(compareProgress);
        root.addView(compareSeek);
        compareSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                compareProgress = progress;
                updateCompareViews();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        LinearLayout playerControls = new LinearLayout(this);
        playerControls.setOrientation(LinearLayout.HORIZONTAL);
        playerControls.setGravity(Gravity.CENTER_VERTICAL);
        playerControls.setPadding(0, dp(8), 0, dp(8));
        root.addView(playerControls);

        playerControls.addView(timeBox());
        playerControls.addView(controlButton("-5s", () -> seekBy(-5000)));
        playButton = controlButtonText("Play", () -> togglePlay());
        playerControls.addView(playButton);
        playerControls.addView(controlButton("+5s", () -> seekBy(5000)));
        playerControls.addView(controlButton("Pantalla", () -> openFullscreen()));

        root.addView(fakeTimeline());

        LinearLayout editorPanel = panelBox();
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ep.topMargin = dp(8);
        root.addView(editorPanel, ep);

        tabsRow = new LinearLayout(this);
        tabsRow.setOrientation(LinearLayout.HORIZONTAL);
        editorPanel.addView(tabsRow);
        tabsRow.addView(tab("Mejoras IA", true));
        tabsRow.addView(tab("Ajustar", false));
        tabsRow.addView(tab("Filtros", false));
        tabsRow.addView(tab("Calidad", false));

        HorizontalScrollView aiScroll = new HorizontalScrollView(this);
        aiScroll.setHorizontalScrollBarEnabled(false);
        aiRow = new LinearLayout(this);
        aiRow.setOrientation(LinearLayout.HORIZONTAL);
        aiScroll.addView(aiRow);
        editorPanel.addView(aiScroll);
        rebuildAiButtons();

        LinearLayout activeRow = new LinearLayout(this);
        activeRow.setOrientation(LinearLayout.HORIZONTAL);
        activeRow.setGravity(Gravity.CENTER_VERTICAL);
        activeRow.setPadding(0, dp(12), 0, 0);
        editorPanel.addView(activeRow);

        activeText = info("");
        activeText.setBackgroundColor(card);
        activeText.setPadding(dp(12), dp(10), dp(12), dp(10));
        activeRow.addView(activeText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button tryNow = new Button(this);
        tryNow.setText("Probar ahora");
        tryNow.setAllCaps(false);
        tryNow.setTextSize(16);
        tryNow.setTypeface(Typeface.DEFAULT_BOLD);
        tryNow.setTextColor(Color.BLACK);
        tryNow.setBackgroundColor(cyan);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(dp(190), dp(54));
        tp.leftMargin = dp(10);
        activeRow.addView(tryNow, tp);
        tryNow.setOnClickListener(v -> showProcessingPreview());

        LinearLayout adjustPanel = panelBox();
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ap.topMargin = dp(8);
        root.addView(adjustPanel, ap);

        LinearLayout manualGrid = new LinearLayout(this);
        manualGrid.setOrientation(LinearLayout.HORIZONTAL);
        adjustPanel.addView(manualGrid);

        manualGrid.addView(compactSlider("Brillo", 0, 20, settings.brightness, v -> settings.brightness = v));
        manualGrid.addView(compactSlider("Contraste", 0, 20, settings.contrast, v -> settings.contrast = v));
        manualGrid.addView(compactSlider("Saturacion", 0, 20, settings.saturation, v -> settings.saturation = v));
        manualGrid.addView(compactSlider("Luminosidad", 0, 20, settings.luminosity, v -> settings.luminosity = v));
        manualGrid.addView(compactSlider("Enfocar", 0, 20, settings.sharpen, v -> settings.sharpen = v));
        manualGrid.addView(compactSlider("Ruido", 0, 20, settings.denoise, v -> settings.denoise = v));

        fileInfo = info("");
        fileInfo.setTextColor(muted);
        fileInfo.setPadding(0, dp(10), 0, 0);
        root.addView(fileInfo);

        setContentView(scroll);
        previewFrame.post(this::updateCompareViews);
    }

    private LinearLayout fakeTimeline() {
        LinearLayout box = panelBox();
        box.setPadding(dp(12), dp(8), dp(12), dp(8));

        LinearLayout time = new LinearLayout(this);
        time.setOrientation(LinearLayout.HORIZONTAL);
        String[] marks = {"00:00", "00:02", "00:04", "00:06", "00:08", "00:10", "00:12", "00:14", "00:16"};
        for (String m : marks) {
            TextView t = info(m);
            t.setTextColor(muted);
            t.setGravity(Gravity.CENTER);
            time.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        box.addView(time);

        LinearLayout strip = new LinearLayout(this);
        strip.setOrientation(LinearLayout.HORIZONTAL);
        strip.setPadding(0, dp(6), 0, 0);
        box.addView(strip);

        for (int i = 0; i < 10; i++) {
            TextView block = new TextView(this);
            block.setText(i == 5 ? "|" : "");
            block.setGravity(Gravity.CENTER);
            block.setTextColor(white);
            block.setBackgroundColor(i % 2 == 0 ? Color.rgb(50, 65, 90) : Color.rgb(60, 55, 88));
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, dp(42), 1f);
            bp.rightMargin = dp(2);
            strip.addView(block, bp);
        }

        View wave = new View(this);
        wave.setBackgroundColor(Color.rgb(0, 160, 170));
        LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(18));
        wp.topMargin = dp(4);
        box.addView(wave, wp);

        return box;
    }

    private void rebuildAiButtons() {
        aiRow.removeAllViews();
        aiRow.addView(aiButton("Anime HD", "AI", activeMode.equals("Anime HD"), () -> applyPreset("Anime HD", false)));
        aiRow.addView(aiButton("Reparacion IA", "HD", activeMode.equals("Reparacion IA"), () -> applyPreset("Reparacion IA", false)));
        aiRow.addView(aiButton("Color IA", "CLR", activeMode.equals("Color IA"), () -> applyPreset("Color IA", false)));
        aiRow.addView(aiButton("Quitar ruido", "NR", activeMode.equals("Quitar ruido"), () -> applyPreset("Quitar ruido", false)));
        aiRow.addView(aiButton("Sombras", "SUN", activeMode.equals("Sombras limpias"), () -> applyPreset("Sombras limpias", false)));
        aiRow.addView(aiButton("IA 4K+", "4K+", activeMode.equals("IA 4K+"), () -> applyPreset("IA 4K+", false)));
    }

    private void applyPreset(String name, boolean silent) {
        activeMode = name;
        settings.modeName = name;
        if (name.equals("Anime HD")) {
            settings.sharpen = 7;
            settings.saturation = 9;
            settings.denoise = 7;
        } else if (name.equals("Reparacion IA")) {
            settings.sharpen = 6;
            settings.denoise = 9;
            settings.luminosity = 12;
        } else if (name.equals("Color IA")) {
            settings.saturation = 12;
            settings.contrast = 8;
            settings.brightness = 6;
        } else if (name.equals("Quitar ruido")) {
            settings.denoise = 12;
            settings.sharpen = 5;
        } else if (name.equals("Sombras limpias")) {
            settings.luminosity = 16;
            settings.denoise = 8;
        } else if (name.equals("IA 4K+")) {
            setQuality("4K", 2160, 3840, 30, 35);
            settings.sharpen = 8;
            settings.saturation = 10;
        }

        rebuildAiButtons();
        refreshUi();
        if (!silent) Toast.makeText(this, name + " activo", Toast.LENGTH_SHORT).show();
    }

    private void refreshUi() {
        qualityButton.setText(activeQuality + " v");
        activeText.setText("Funcion activa: " + activeMode);
        if (fileInfo != null) {
            fileInfo.setText(selectedVideo == null ? "Video: no cargado" : "Video cargado: " + getFileName(selectedVideo));
        }
    }

    private interface SetInt { void set(int value); }

    private View compactSlider(String name, int min, int max, int current, SetInt setter) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(5), dp(6), dp(5), dp(6));
        box.setBackgroundColor(panel);

        TextView label = info(name);
        label.setGravity(Gravity.CENTER);
        label.setTextSize(12);
        box.addView(label);

        TextView value = info(String.valueOf(current));
        value.setGravity(Gravity.CENTER);
        value.setTypeface(Typeface.DEFAULT_BOLD);
        box.addView(value);

        SeekBar seek = new SeekBar(this);
        seek.setMax(max - min);
        seek.setProgress(current - min);
        box.addView(seek, new LinearLayout.LayoutParams(dp(108), ViewGroup.LayoutParams.WRAP_CONTENT));

        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int real = min + progress;
                setter.set(real);
                value.setText(String.valueOf(real));
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                refreshUi();
            }
        });

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(116), ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.rightMargin = dp(4);
        box.setLayoutParams(lp);
        return box;
    }

    private void showProcessingPreview() {
        if (selectedVideo == null) {
            Toast.makeText(this, "Primero importa un video", Toast.LENGTH_SHORT).show();
            return;
        }

        showProgressDialog("Mejorando la calidad");
        fakeProgress = 0;
        processDone = false;
        stepPreviewProgress();
    }

    private void stepPreviewProgress() {
        if (processDone) return;
        fakeProgress += 5;
        if (fakeProgress > 100) fakeProgress = 100;

        processProgress.setProgress(fakeProgress);
        processPercent.setText(fakeProgress + "%");

        processState.setText("Aplicando " + activeMode + "...\nPreparando Antes / Despues.");

        if (fakeProgress >= 100) {
            processDone = true;
            processState.setText("Listo. Revisa el Antes / Despues.");
            handler.postDelayed(() -> {
                if (processDialog != null && processDialog.isShowing()) processDialog.dismiss();
                openFullscreen();
            }, 850);
            return;
        }

        handler.postDelayed(this::stepPreviewProgress, 260);
    }

    private void showExportConfirm() {
        if (selectedVideo == null) {
            Toast.makeText(this, "Primero importa un video", Toast.LENGTH_SHORT).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Exportacion HD")
                .setMessage(settings.summary())
                .setPositiveButton("Exportar", (d, w) -> exportVideo())
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void exportVideo() {
        showProgressDialog("Procesando exportacion");
        fakeProgress = 0;
        processDone = false;

        LocalVideoExporter.export(this, selectedVideo, settings, new LocalVideoExporter.Listener() {
            @Override public void onProgress(int percent, String message) {
                runOnUiThread(() -> {
                    processProgress.setProgress(percent);
                    processPercent.setText(percent + "%");
                    processState.setText(message + "\nNo cierres la app.");
                });
            }

            @Override public void onFinished(boolean success, Uri outputUri, String message) {
                runOnUiThread(() -> {
                    processDone = true;
                    processProgress.setProgress(100);
                    processPercent.setText("100%");
                    processState.setText(message);
                    handler.postDelayed(() -> {
                        if (processDialog != null && processDialog.isShowing()) processDialog.dismiss();
                        Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
                    }, 1000);
                });
            }
        });
    }

    private void showProgressDialog(String titleText) {
        processDialog = new Dialog(this);
        processDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(22), dp(22), dp(22), dp(22));
        box.setBackgroundColor(card);

        TextView title = infoBold(titleText);
        title.setTextSize(22);
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        box.addView(title);

        processProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        processProgress.setMax(100);
        processProgress.setProgress(0);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        pp.topMargin = dp(16);
        box.addView(processProgress, pp);

        processPercent = infoBold("0%");
        processPercent.setGravity(Gravity.CENTER_HORIZONTAL);
        processPercent.setTextSize(20);
        processPercent.setPadding(0, dp(8), 0, dp(8));
        box.addView(processPercent);

        processState = info("Preparando...");
        processState.setGravity(Gravity.CENTER_HORIZONTAL);
        box.addView(processState);

        Button cancel = new Button(this);
        cancel.setText("Cancelar");
        cancel.setAllCaps(false);
        cancel.setOnClickListener(v -> {
            processDone = true;
            if (processDialog != null && processDialog.isShowing()) processDialog.dismiss();
        });
        box.addView(cancel);

        processDialog.setContentView(box);
        processDialog.setCancelable(false);
        processDialog.show();
    }

    private void showQualitySelector() {
        String[] options = {"720P", "1080P", "2K", "4K"};
        new AlertDialog.Builder(this)
                .setTitle("Elegir calidad")
                .setItems(options, (d, which) -> {
                    if (which == 0) setQuality("720P", 720, 1280, 30, 8);
                    if (which == 1) setQuality("1080P", 1080, 1920, 30, 12);
                    if (which == 2) setQuality("2K", 1440, 2560, 30, 20);
                    if (which == 3) setQuality("4K", 2160, 3840, 30, 35);
                    refreshUi();
                })
                .show();
    }

    private void setQuality(String name, int w, int h, int fps, int mbps) {
        activeQuality = name;
        settings.qualityName = name;
        settings.width = w;
        settings.height = h;
        settings.fps = fps;
        settings.bitrateMbps = mbps;
        if (qualityButton != null) qualityButton.setText(activeQuality + " v");
    }

    private void togglePlay() {
        if (player == null) return;
        if (player.isPlaying()) {
            player.pause();
            playButton.setText("Play");
        } else {
            player.play();
            playButton.setText("Pausa");
        }
    }

    private void seekBy(long ms) {
        if (player == null) return;
        long pos = player.getCurrentPosition();
        long dur = player.getDuration();
        long next = pos + ms;
        if (next < 0) next = 0;
        if (dur > 0 && next > dur) next = dur;
        player.seekTo(next);
    }

    private void pickVideo() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("video/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "video/mp4", "video/quicktime", "video/x-matroska", "video/webm",
                "video/x-msvideo", "video/3gpp", "video/x-ms-wmv", "video/*"
        });
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, REQ_PICK_VIDEO);
    }

    private void openFullscreen() {
        if (selectedVideo == null) {
            Toast.makeText(this, "Primero importa un video", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(this, FullscreenCompareActivity.class);
        i.putExtra("video_uri", selectedVideo.toString());
        i.putExtra("title", activeMode);
        i.putExtra("subtitle", "Mueve la regla o la barra inferior");
        i.putExtra("compare_progress", compareProgress);
        startActivity(i);
    }

    private void preparePlayer() {
        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        player.setRepeatMode(Player.REPEAT_MODE_ONE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PICK_VIDEO && resultCode == RESULT_OK && data != null) {
            selectedVideo = data.getData();
            if (selectedVideo != null) {
                try {
                    getContentResolver().takePersistableUriPermission(selectedVideo, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Exception ignored) {
                }
                player.setMediaItem(MediaItem.fromUri(selectedVideo));
                player.prepare();
                player.play();
                playButton.setText("Pausa");
                refreshUi();
            }
        }
    }

    private String getFileName(Uri uri) {
        String result = "video seleccionado";
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) result = cursor.getString(idx);
            }
        } catch (Exception ignored) {
        }
        return result;
    }

    private void updateCompareFromTouch(float touchX) {
        if (previewFrame == null || previewFrame.getWidth() == 0) return;
        int w = previewFrame.getWidth();
        int p = Math.max(0, Math.min(100, Math.round((touchX / w) * 100f)));
        compareProgress = p;
        compareSeek.setProgress(p);
        updateCompareViews();
    }

    private void updateCompareViews() {
        if (previewFrame == null || previewFrame.getWidth() == 0) return;

        int w = previewFrame.getWidth();
        int h = previewFrame.getHeight();
        int x = (int)(w * (compareProgress / 100f));

        FrameLayout.LayoutParams overlay = (FrameLayout.LayoutParams) beforeOverlay.getLayoutParams();
        overlay.width = Math.max(0, x);
        overlay.height = h;
        overlay.gravity = Gravity.LEFT;
        beforeOverlay.setLayoutParams(overlay);

        FrameLayout.LayoutParams line = (FrameLayout.LayoutParams) divider.getLayoutParams();
        line.width = dp(3);
        line.height = h;
        line.leftMargin = Math.max(0, x - dp(1));
        divider.setLayoutParams(line);

        beforeOverlay.bringToFront();
        divider.bringToFront();
        beforeLabel.bringToFront();
        afterLabel.bringToFront();
    }

    private LinearLayout panelBox() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(panel);
        box.setPadding(dp(12), dp(10), dp(12), dp(12));
        return box;
    }

    private TextView topIcon(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(white);
        v.setTextSize(20);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setGravity(Gravity.CENTER);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(42), dp(52)));
        return v;
    }

    private TextView topPill(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(white);
        v.setTextSize(16);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setGravity(Gravity.CENTER);
        v.setBackgroundColor(card);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(112), dp(52)));
        return v;
    }

    private TextView previewLabel(String text, int gravity) {
        TextView v = infoBold(text);
        v.setTextSize(18);
        v.setBackgroundColor(Color.argb(150, 0, 0, 0));
        v.setPadding(dp(10), dp(6), dp(10), dp(6));
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, gravity);
        p.leftMargin = dp(14);
        p.rightMargin = dp(14);
        p.bottomMargin = dp(14);
        v.setLayoutParams(p);
        return v;
    }

    private TextView previewTag(String text) {
        TextView v = infoBold(text);
        v.setTextSize(12);
        v.setBackgroundColor(Color.argb(150, 0, 0, 0));
        v.setPadding(dp(10), dp(6), dp(10), dp(6));
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.RIGHT);
        p.rightMargin = dp(12);
        p.topMargin = dp(12);
        v.setLayoutParams(p);
        return v;
    }

    private TextView tab(String text, boolean active) {
        TextView v = infoBold(text);
        v.setTextSize(14);
        v.setTextColor(active ? cyan : muted);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(8), dp(8), dp(8), dp(10));
        v.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return v;
    }

    private TextView timeBox() {
        TextView v = info("00:00 / 00:00");
        v.setGravity(Gravity.CENTER);
        v.setBackgroundColor(card);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(120), dp(48)));
        return v;
    }

    private View controlButton(String text, Runnable action) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(white);
        b.setBackgroundColor(card);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(48), 1f);
        p.rightMargin = dp(8);
        b.setLayoutParams(p);
        b.setOnClickListener(v -> action.run());
        return b;
    }

    private TextView controlButtonText(String text, Runnable action) {
        TextView b = new TextView(this);
        b.setText(text);
        b.setTextColor(white);
        b.setTextSize(15);
        b.setGravity(Gravity.CENTER);
        b.setBackgroundColor(card);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(48), 1f);
        p.rightMargin = dp(8);
        b.setLayoutParams(p);
        b.setOnClickListener(v -> action.run());
        return b;
    }

    private TextView aiButton(String title, String icon, boolean active, Runnable action) {
        TextView v = new TextView(this);
        v.setText(icon + "\n" + title);
        v.setTextColor(active ? cyan : white);
        v.setTextSize(13);
        v.setGravity(Gravity.CENTER);
        v.setTypeface(active ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        v.setBackgroundColor(card);
        v.setPadding(dp(8), dp(10), dp(8), dp(10));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(122), dp(86));
        p.rightMargin = dp(10);
        v.setLayoutParams(p);
        v.setOnClickListener(view -> action.run());
        return v;
    }

    private TextView info(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(white);
        v.setTextSize(13);
        return v;
    }

    private TextView infoBold(String text) {
        TextView v = info(text);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (player != null) player.pause();
        if (playButton != null) playButton.setText("Play");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
        if (player != null) {
            player.release();
            player = null;
        }
    }
}
