# Anime HD Cleaner V6.1 FIXED

Corrección de la V6.

## Error corregido

La V6 fallaba porque Media3 1.10.1 pide compileSdk 36.
El proyecto estaba en compileSdk 35.

## Solución

Se bajó Media3 a 1.4.1, compatible con compileSdk 35.

## Mantiene

- Diseño estilo Quality Restoration / AI Repair.
- Before / After.
- Reparación IA.
- Ultra HD.
- Anime HD.
- Exportación 720p, 1080p, 2K y 4K.
- Motor experimental con Media3 Transformer.

Si vuelve a fallar, manda captura del nuevo error rojo.
