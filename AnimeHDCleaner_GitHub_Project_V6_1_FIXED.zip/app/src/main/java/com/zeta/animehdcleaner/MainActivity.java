package com.zeta.animehdcleaner;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

public class MainActivity extends Activity {

    private static final int REQ_PICK_VIDEO = 1001;

    private Uri selectedVideo;
    private ExoPlayer player;
    private PlayerView playerView;

    private final ExportSettings settings = new ExportSettings();

    private TextView titleHero;
    private TextView subtitleHero;
    private TextView status;
    private TextView fileInfo;
    private LinearLayout modeGrid;
    private LinearLayout qualityRow;
    private View divider;
    private TextView beforeLabel;
    private TextView afterLabel;
    private View afterOverlay;

    private String activeMode = "Reparación IA";
    private String activeQuality = "Ultra HD";

    private final int dark = Color.rgb(31, 31, 31);
    private final int black = Color.rgb(8, 8, 8);
    private final int light = Color.rgb(245, 245, 249);
    private final int white = Color.WHITE;
    private final int soft = Color.rgb(230, 230, 238);
    private final int muted = Color.rgb(160, 160, 166);
    private final int pink = Color.rgb(255, 220, 225);
    private final int violet = Color.rgb(224, 220, 255);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        preparePlayer();
        setStatus("Importa un video y elige Reparación IA, Ultra HD o Anime HD.");
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(dark);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(18));
        scroll.addView(root);

        TextView back = new TextView(this);
        back.setText("‹");
        back.setTextColor(white);
        back.setTextSize(42);
        back.setPadding(0, 0, 0, dp(16));
        root.addView(back);

        titleHero = new TextView(this);
        titleHero.setText("✨ Reparación IA ✨");
        titleHero.setTextColor(white);
        titleHero.setTextSize(27);
        titleHero.setTypeface(Typeface.DEFAULT_BOLD);
        titleHero.setGravity(Gravity.CENTER);
        root.addView(titleHero);

        subtitleHero = new TextView(this);
        subtitleHero.setText("Soluciones IA y ajustes manuales para HD, 4K, ruido, color y anime.");
        subtitleHero.setTextColor(muted);
        subtitleHero.setTextSize(16);
        subtitleHero.setGravity(Gravity.CENTER);
        subtitleHero.setPadding(0, dp(8), 0, dp(22));
        root.addView(subtitleHero);

        FrameLayout preview = new FrameLayout(this);
        preview.setBackgroundColor(Color.BLACK);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(360));
        pp.setMargins(0, 0, 0, dp(16));
        root.addView(preview, pp);

        playerView = new PlayerView(this);
        playerView.setUseController(true);
        playerView.setControllerAutoShow(true);
        preview.addView(playerView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        afterOverlay = new View(this);
        afterOverlay.setBackgroundColor(Color.argb(32, 255, 255, 255));
        FrameLayout.LayoutParams ovp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT);
        ovp.leftMargin = dp(160);
        preview.addView(afterOverlay, ovp);

        divider = new View(this);
        divider.setBackgroundColor(white);
        preview.addView(divider, new FrameLayout.LayoutParams(dp(3), FrameLayout.LayoutParams.MATCH_PARENT, Gravity.CENTER));

        beforeLabel = labelOnVideo("Before");
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM | Gravity.LEFT);
        bp.setMargins(dp(28), 0, 0, dp(20));
        preview.addView(beforeLabel, bp);

        afterLabel = labelOnVideo("After");
        FrameLayout.LayoutParams ap = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM | Gravity.RIGHT);
        ap.setMargins(0, 0, dp(28), dp(20));
        preview.addView(afterLabel, ap);

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        Button importBtn = smallBlackButton("Importar");
        importBtn.setOnClickListener(v -> pickVideo());
        Button exportBtn = smallBlackButton("Exportar");
        exportBtn.setOnClickListener(v -> showExportDialog());
        buttons.addView(importBtn);
        buttons.addView(exportBtn);
        root.addView(buttons);

        fileInfo = new TextView(this);
        fileInfo.setText("MP4, MOV, MKV, WEBM, AVI, 3GP y video/*");
        fileInfo.setTextColor(muted);
        fileInfo.setTextSize(12);
        fileInfo.setPadding(0, dp(10), 0, dp(14));
        root.addView(fileInfo);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(light);
        panel.setPadding(dp(10), dp(18), dp(10), dp(18));
        root.addView(panel);

        TextView modeTitle = section("Quality Restoration");
        modeTitle.setTextColor(Color.BLACK);
        panel.addView(modeTitle);

        modeGrid = new LinearLayout(this);
        modeGrid.setOrientation(LinearLayout.VERTICAL);
        panel.addView(modeGrid);
        rebuildModeGrid();

        TextView qualityTitle = section("Exportación");
        qualityTitle.setTextColor(Color.BLACK);
        panel.addView(qualityTitle);

        HorizontalScrollView qscroll = new HorizontalScrollView(this);
        qscroll.setHorizontalScrollBarEnabled(false);
        qualityRow = new LinearLayout(this);
        qualityRow.setOrientation(LinearLayout.HORIZONTAL);
        qscroll.addView(qualityRow);
        panel.addView(qscroll);
        rebuildQualityRow();

        TextView manualTitle = section("Ajustes manuales");
        manualTitle.setTextColor(Color.BLACK);
        panel.addView(manualTitle);

        addSlider(panel, "Sombras", 0, 20, settings.shadows, v -> settings.shadows = v);
        addSlider(panel, "Denoise", 0, 10, settings.denoise, v -> settings.denoise = v);
        addSlider(panel, "Nitidez", 0, 10, settings.sharpen, v -> settings.sharpen = v);
        addSlider(panel, "Color", 0, 15, settings.saturation, v -> settings.saturation = v);

        Button tryNow = bigGradientLikeButton("Probar ahora / Exportar HD");
        tryNow.setOnClickListener(v -> showExportDialog());
        panel.addView(tryNow);

        status = new TextView(this);
        status.setTextColor(Color.BLACK);
        status.setTextSize(13);
        status.setPadding(dp(8), dp(12), dp(8), 0);
        panel.addView(status);

        setContentView(scroll);
    }

    private void rebuildModeGrid() {
        modeGrid.removeAllViews();

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.addView(modeCard("Reparación IA", "HD AI", () -> {
            activeMode = "Reparación IA";
            settings.modeName = activeMode;
            settings.shadows = 12; settings.denoise = 8; settings.sharpen = 5; settings.saturation = 8;
            updateHero("✨ Reparación IA ✨", "Reduce ruido, mejora sombras, color y nitidez.");
        }));
        row1.addView(modeCard("Ultra HD", "HD+", () -> {
            activeMode = "Ultra HD";
            settings.modeName = activeMode;
            settings.qualityName = "4K";
            setQuality("4K", 2160, 3840, 30, 35, false);
            settings.sharpen = 8; settings.saturation = 9;
            updateHero("✨ Ultra HD ✨", "Mejora avanzada y salida hasta 4K.");
        }));
        row1.addView(modeCard("Anime HD", "ANI", () -> {
            activeMode = "Anime HD";
            settings.modeName = activeMode;
            settings.shadows = 10; settings.denoise = 8; settings.sharpen = 7; settings.grain = 4;
            updateHero("✨ Anime HD ✨", "Líneas más limpias, menos manchas y mejor color.");
        }));
        modeGrid.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.addView(modeCard("Color IA", "CLR", () -> {
            activeMode = "Color IA";
            settings.modeName = activeMode;
            settings.saturation = 12; settings.contrast = 4; settings.brightness = 4;
            updateHero("✨ Color IA ✨", "Color más vivo sin exagerar.");
        }));
        row2.addView(modeCard("Quitar ruido", "NR", () -> {
            activeMode = "Quitar ruido";
            settings.modeName = activeMode;
            settings.denoise = 10; settings.sharpen = 4; settings.grain = 3;
            updateHero("✨ Quitar ruido ✨", "Reduce manchas y bloques en zonas oscuras.");
        }));
        row2.addView(modeCard("Sombras", "SHD", () -> {
            activeMode = "Sombras";
            settings.modeName = activeMode;
            settings.shadows = 16; settings.denoise = 8; settings.contrast = 2;
            updateHero("✨ Sombras limpias ✨", "Mejora negros feos y zonas oscuras.");
        }));
        modeGrid.addView(row2);
    }

    private void rebuildQualityRow() {
        qualityRow.removeAllViews();
        qualityRow.addView(qualityCard("720p", 720, 1280, 30, 8));
        qualityRow.addView(qualityCard("1080p", 1080, 1920, 30, 12));
        qualityRow.addView(qualityCard("1080p 60", 1080, 1920, 60, 15));
        qualityRow.addView(qualityCard("2K", 1440, 2560, 30, 20));
        qualityRow.addView(qualityCard("4K", 2160, 3840, 30, 35));
    }

    private View modeCard(String name, String icon, Runnable action) {
        boolean active = activeMode.equals(name);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setBackgroundColor(active ? Color.WHITE : Color.rgb(250, 250, 255));
        box.setPadding(dp(6), dp(8), dp(6), dp(8));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(104), 1);
        p.setMargins(dp(5), dp(6), dp(5), dp(6));
        box.setLayoutParams(p);

        TextView ic = new TextView(this);
        ic.setText((active ? "✓ " : "") + icon);
        ic.setTextSize(18);
        ic.setTypeface(Typeface.DEFAULT_BOLD);
        ic.setTextColor(Color.BLACK);
        ic.setGravity(Gravity.CENTER);
        box.addView(ic);

        TextView tx = new TextView(this);
        tx.setText(name);
        tx.setTextSize(12);
        tx.setTextColor(Color.BLACK);
        tx.setGravity(Gravity.CENTER);
        box.addView(tx);

        box.setOnClickListener(v -> {
            action.run();
            rebuildModeGrid();
            setStatus("Activo: ✓ " + activeMode + "\n" + settings.summary());
            Toast.makeText(this, "✓ " + activeMode, Toast.LENGTH_SHORT).show();
        });

        return box;
    }

    private View qualityCard(String name, int w, int h, int fps, int mbps) {
        boolean active = activeQuality.equals(name);
        TextView card = new TextView(this);
        card.setText((active ? "✓ " : "") + name + "\n" + fps + " FPS\n" + mbps + " Mbps");
        card.setGravity(Gravity.CENTER);
        card.setTextSize(13);
        card.setTypeface(Typeface.DEFAULT_BOLD);
        card.setTextColor(active ? Color.WHITE : Color.BLACK);
        card.setBackgroundColor(active ? Color.BLACK : Color.WHITE);
        card.setPadding(dp(12), dp(8), dp(12), dp(8));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(112), dp(86));
        p.setMargins(dp(5), dp(8), dp(5), dp(8));
        card.setLayoutParams(p);
        card.setOnClickListener(v -> setQuality(name, w, h, fps, mbps, true));
        return card;
    }

    private void setQuality(String name, int w, int h, int fps, int mbps, boolean toast) {
        activeQuality = name;
        settings.qualityName = name;
        settings.width = w;
        settings.height = h;
        settings.fps = fps;
        settings.bitrateMbps = mbps;
        rebuildQualityRow();
        setStatus("Calidad activa: ✓ " + activeQuality + "\n" + settings.summary());
        if (toast) Toast.makeText(this, "✓ " + activeQuality, Toast.LENGTH_SHORT).show();
    }

    private void updateHero(String title, String sub) {
        titleHero.setText(title);
        subtitleHero.setText(sub);
    }

    private void showExportDialog() {
        String[] options = new String[] {
                "720p HD / 30 FPS / 8 Mbps",
                "1080p Full HD / 30 FPS / 12 Mbps",
                "1080p Full HD / 60 FPS / 15 Mbps",
                "2K / 30 FPS / 20 Mbps",
                "4K / 30 FPS / 35 Mbps",
                "Exportar ahora"
        };

        new AlertDialog.Builder(this)
                .setTitle("Exportación HD")
                .setMessage("Activo:\n✓ " + activeMode + "\n✓ " + activeQuality + "\n\n" + settings.summary())
                .setItems(options, (dialog, which) -> {
                    if (which == 0) setQuality("720p", 720, 1280, 30, 8, true);
                    if (which == 1) setQuality("1080p", 1080, 1920, 30, 12, true);
                    if (which == 2) setQuality("1080p 60", 1080, 1920, 60, 15, true);
                    if (which == 3) setQuality("2K", 1440, 2560, 30, 20, true);
                    if (which == 4) setQuality("4K", 2160, 3840, 30, 35, true);
                    if (which == 5) exportHd();
                })
                .setPositiveButton("Exportar ahora", (d, w) -> exportHd())
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void exportHd() {
        if (selectedVideo == null) {
            setStatus("Primero importa un video.");
            return;
        }

        setStatus("Exportando... puede demorar. No cierres la app.\n" + settings.summary());

        RealHdExporter.export(this, selectedVideo, settings, new RealHdExporter.Listener() {
            @Override
            public void onLog(String message) {
                runOnUiThread(() -> setStatus(message + "\n\n" + settings.summary()));
            }

            @Override
            public void onFinished(boolean success, Uri outputUri, String message) {
                runOnUiThread(() -> setStatus(message + "\n\nGuardado en Movies/AnimeHDCleaner"));
            }
        });
    }

    private void pickVideo() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("video/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {
                "video/mp4", "video/quicktime", "video/x-matroska", "video/webm",
                "video/x-msvideo", "video/3gpp", "video/x-ms-wmv", "video/*"
        });
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, REQ_PICK_VIDEO);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PICK_VIDEO && resultCode == RESULT_OK && data != null) {
            selectedVideo = data.getData();
            if (selectedVideo != null) {
                try {
                    getContentResolver().takePersistableUriPermission(selectedVideo, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Exception ignored) {}

                player.setMediaItem(MediaItem.fromUri(selectedVideo));
                player.prepare();
                player.play();

                fileInfo.setText("Video cargado: " + getFileName(selectedVideo));
                setStatus("Video listo. Elige modo y toca Probar ahora / Exportar HD.");
            }
        }
    }

    private String getFileName(Uri uri) {
        String result = "video seleccionado";
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) result = cursor.getString(index);
            }
        } catch (Exception ignored) {}
        return result;
    }

    private void preparePlayer() {
        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        player.setRepeatMode(Player.REPEAT_MODE_ONE);
    }

    private TextView labelOnVideo(String txt) {
        TextView v = new TextView(this);
        v.setText(txt);
        v.setTextColor(Color.WHITE);
        v.setTextSize(22);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setShadowLayer(6, 0, 0, Color.BLACK);
        v.setPadding(dp(8), dp(4), dp(8), dp(4));
        return v;
    }

    private TextView section(String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextColor(Color.BLACK);
        v.setTextSize(18);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setPadding(0, dp(12), 0, dp(6));
        return v;
    }

    private Button smallBlackButton(String t) {
        Button b = new Button(this);
        b.setText(t);
        b.setTextColor(Color.WHITE);
        b.setTextSize(15);
        b.setAllCaps(false);
        b.setBackgroundColor(Color.BLACK);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(54), 1);
        p.setMargins(dp(4), dp(6), dp(4), dp(8));
        b.setLayoutParams(p);
        return b;
    }

    private Button bigGradientLikeButton(String t) {
        Button b = new Button(this);
        b.setText(t);
        b.setTextColor(Color.BLACK);
        b.setTextSize(18);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setAllCaps(false);
        b.setBackgroundColor(pink);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(62));
        p.setMargins(dp(4), dp(18), dp(4), dp(8));
        b.setLayoutParams(p);
        return b;
    }

    private interface Change { void set(int value); }

    private void addSlider(LinearLayout root, String name, int min, int max, int value, Change change) {
        TextView label = new TextView(this);
        label.setText(name + ": " + value);
        label.setTextColor(Color.BLACK);
        label.setTextSize(13);
        label.setPadding(dp(6), dp(8), dp(6), 0);
        root.addView(label);

        SeekBar bar = new SeekBar(this);
        bar.setMax(max - min);
        bar.setProgress(value - min);
        root.addView(bar);

        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int real = min + progress;
                label.setText(name + ": " + real);
                change.set(real);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                setStatus("Ajuste actualizado.\n" + settings.summary());
            }
        });
    }

    private void setStatus(String msg) {
        if (status != null) status.setText(msg);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (player != null) player.pause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (player != null) {
            player.release();
            player = null;
        }
    }
}
