package com.zeta.animehdcleaner;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;

import androidx.media3.common.Effects;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.effect.Presentation;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.Transformer;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;

public class RealHdExporter {

    public interface Listener {
        void onLog(String message);
        void onFinished(boolean success, Uri outputUri, String message);
    }

    public static void export(Context context, Uri inputUri, ExportSettings settings, Listener listener) {
        try {
            File outDir = new File(context.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "AnimeHDCleaner");
            if (!outDir.exists()) outDir.mkdirs();

            String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            File tempOutput = new File(outDir, "anime_hd_cleaner_v6_" + stamp + ".mp4");

            listener.onLog("Iniciando motor HD real...");
            listener.onLog("Modo: " + settings.modeName);
            listener.onLog("Salida: " + settings.width + "x" + settings.height + " · " + settings.fps + " FPS");

            Effects effects = new Effects(
                    Collections.emptyList(),
                    Collections.singletonList(
                            Presentation.createForWidthAndHeight(
                                    settings.width,
                                    settings.height,
                                    Presentation.LAYOUT_SCALE_TO_FIT
                            )
                    )
            );

            MediaItem mediaItem = MediaItem.fromUri(inputUri);
            EditedMediaItem editedMediaItem = new EditedMediaItem.Builder(mediaItem)
                    .setEffects(effects)
                    .build();

            Transformer.Listener transformerListener = new Transformer.Listener() {
                @Override
                public void onCompleted(Composition composition, ExportResult result) {
                    try {
                        Uri saved = saveToGallery(context, tempOutput);
                        listener.onFinished(true, saved, "Listo. Exportado en HD sin marca.");
                    } catch (Exception e) {
                        listener.onFinished(false, null, "Exportó, pero no se pudo guardar en galería: " + e.getMessage());
                    }
                }

                @Override
                public void onError(Composition composition, ExportResult result, ExportException exception) {
                    listener.onFinished(false, null, "Falló el motor HD: " + exception.getMessage());
                }
            };

            Transformer transformer = new Transformer.Builder(context)
                    .setVideoMimeType(MimeTypes.VIDEO_H264)
                    .addListener(transformerListener)
                    .build();

            transformer.start(editedMediaItem, tempOutput.getAbsolutePath());

        } catch (Exception e) {
            listener.onFinished(false, null, "Error al iniciar exportación: " + e.getMessage());
        }
    }

    private static Uri saveToGallery(Context context, File tempOutput) throws Exception {
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        String fileName = "anime_hd_cleaner_v6_" + stamp + ".mp4";

        ContentValues values = new ContentValues();
        values.put(MediaStore.Video.Media.DISPLAY_NAME, fileName);
        values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/AnimeHDCleaner");

        ContentResolver resolver = context.getContentResolver();
        Uri outputUri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
        if (outputUri == null) throw new Exception("No se pudo crear el archivo final.");

        try (InputStream in = new FileInputStream(tempOutput);
             OutputStream out = resolver.openOutputStream(outputUri)) {

            if (out == null) throw new Exception("No se pudo abrir salida.");
            byte[] buffer = new byte[1024 * 1024];
            int read;
            while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
            out.flush();
        }

        return outputUri;
    }
}
