# Anime HD Cleaner V4

Versión con interfaz más profesional, selector de formatos y panel de exportación.

## Formatos aceptados

La app usa el selector Android con `video/*`, más MIME específicos:

- MP4
- MOV
- MKV
- WEBM
- AVI
- 3GP
- WMV
- Otros videos compatibles con Android

## Exportación configurada

La app permite elegir:

- 720p HD
- 1080p Full HD
- 1080p 60 FPS
- 2K
- 4K
- Bitrate recomendado
- Codec H.264 MP4
- Audio AAC

## Nota honesta

Esta V4 mejora interfaz, formatos y configuración de exportación.
La exportación real todavía es de prueba/copia sin marca.

La V5 debe agregar motor real de procesamiento:
- Mejorar calidad HD/Full HD/4K.
- Filtros reales de sombras, denoise, nitidez y anti-banding.
- Exportación real con recodificación.
