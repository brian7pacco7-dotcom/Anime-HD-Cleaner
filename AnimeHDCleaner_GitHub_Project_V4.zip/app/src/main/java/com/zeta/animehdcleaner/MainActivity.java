package com.zeta.animehdcleaner;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.OpenableColumns;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final int REQ_PICK_VIDEO = 1001;

    private Uri selectedVideo;
    private ExoPlayer player;
    private PlayerView playerView;
    private TextView status;
    private TextView fileInfo;
    private LinearLayout timelineBar;

    private int brillo = 4;
    private int sombras = 10;
    private int contraste = 3;
    private int saturacion = 8;
    private int denoise = 7;
    private int nitidez = 4;
    private int grano = 4;

    private String exportResolution = "1080p Full HD";
    private int exportWidth = 1080;
    private int exportHeight = 1920;
    private int exportFps = 30;
    private int exportBitrate = 12;
    private String exportCodec = "H.264 MP4";
    private String exportMode = "TikTok/Reels HD";

    private final int bg = Color.rgb(5, 8, 22);
    private final int card = Color.rgb(17, 24, 39);
    private final int card2 = Color.rgb(31, 41, 55);
    private final int text = Color.rgb(243, 244, 246);
    private final int muted = Color.rgb(156, 163, 175);
    private final int purple = Color.rgb(124, 58, 237);
    private final int cyan = Color.rgb(34, 211, 238);
    private final int green = Color.rgb(16, 185, 129);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        preparePlayer();
        setStatus("V4: formatos amplios, preview profesional y panel de exportación tipo CapCut. Motor real de filtros se agrega en V5.");
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(bg);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(14), dp(14), dp(18));
        scroll.addView(root);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(top);

        TextView title = new TextView(this);
        title.setText("Anime HD Cleaner");
        title.setTextSize(23);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(text);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        top.addView(title, titleParams);

        TextView badge = pill("V4 Export", purple);
        top.addView(badge);

        TextView subtitle = new TextView(this);
        subtitle.setText("Formatos: MP4, MOV, MKV, WEBM, AVI, 3GP y otros videos compatibles con Android.");
        subtitle.setTextSize(13);
        subtitle.setTextColor(muted);
        subtitle.setPadding(0, dp(6), 0, dp(12));
        root.addView(subtitle);

        FrameLayout previewCard = new FrameLayout(this);
        previewCard.setBackgroundColor(Color.BLACK);
        LinearLayout.LayoutParams previewParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(420)
        );
        previewParams.setMargins(0, dp(4), 0, dp(10));
        root.addView(previewCard, previewParams);

        playerView = new PlayerView(this);
        playerView.setUseController(true);
        playerView.setControllerAutoShow(true);
        playerView.setKeepContentOnPlayerReset(true);
        previewCard.addView(playerView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));

        TextView watermark = new TextView(this);
        watermark.setText("HD PREVIEW");
        watermark.setTextColor(Color.argb(140, 255, 255, 255));
        watermark.setTextSize(11);
        watermark.setTypeface(Typeface.DEFAULT_BOLD);
        watermark.setPadding(dp(8), dp(4), dp(8), dp(4));
        FrameLayout.LayoutParams wmParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.RIGHT
        );
        wmParams.setMargins(0, dp(8), dp(8), 0);
        previewCard.addView(watermark, wmParams);

        LinearLayout mainButtons = new LinearLayout(this);
        mainButtons.setOrientation(LinearLayout.HORIZONTAL);
        Button pick = smallPrimary("Importar video");
        pick.setOnClickListener(v -> pickVideo());
        Button export = smallPrimary("Exportar");
        export.setOnClickListener(v -> showExportDialog());
        mainButtons.addView(pick);
        mainButtons.addView(export);
        root.addView(mainButtons);

        fileInfo = new TextView(this);
        fileInfo.setText("Formatos aceptados: video/*  |  Recomendado: MP4 H.264");
        fileInfo.setTextSize(12);
        fileInfo.setTextColor(muted);
        fileInfo.setPadding(0, dp(8), 0, dp(8));
        root.addView(fileInfo);

        root.addView(section("Calidad rápida"));
        HorizontalScrollView qualityScroll = new HorizontalScrollView(this);
        qualityScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout quality = new LinearLayout(this);
        quality.setOrientation(LinearLayout.HORIZONTAL);
        qualityScroll.addView(quality);
        root.addView(qualityScroll);

        quality.addView(qualityCard("HD", "720p", "Ligero", 720, 1280, 30, 8));
        quality.addView(qualityCard("Full HD", "1080p", "Recomendado", 1080, 1920, 30, 12));
        quality.addView(qualityCard("2K", "1440p", "Más detalle", 1440, 2560, 30, 20));
        quality.addView(qualityCard("4K", "2160p", "Pesado", 2160, 3840, 30, 35));

        root.addView(section("Línea de tiempo"));
        timelineBar = new LinearLayout(this);
        timelineBar.setOrientation(LinearLayout.HORIZONTAL);
        timelineBar.setGravity(Gravity.CENTER_VERTICAL);
        timelineBar.setPadding(0, dp(8), 0, dp(10));
        root.addView(timelineBar);
        buildTimeline(false);

        root.addView(section("Mejorar calidad"));
        HorizontalScrollView presetScroll = new HorizontalScrollView(this);
        presetScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout presets = new LinearLayout(this);
        presets.setOrientation(LinearLayout.HORIZONTAL);
        presetScroll.addView(presets);
        root.addView(presetScroll);

        presets.addView(presetButton("Anime oscuro", "Sombras + anti-manchas", () -> {
            brillo = 4; sombras = 12; contraste = 2; saturacion = 8; denoise = 8; nitidez = 4; grano = 5;
            exportMode = "Anime oscuro HD";
            setStatus("Preset Anime oscuro aplicado.");
        }));

        presets.addView(presetButton("Sombras limpias", "Negros más limpios", () -> {
            brillo = 5; sombras = 14; contraste = 1; saturacion = 6; denoise = 8; nitidez = 3; grano = 5;
            exportMode = "Sombras limpias";
            setStatus("Preset Sombras limpias aplicado.");
        }));

        presets.addView(presetButton("HD profesional", "Nitidez + color", () -> {
            brillo = 3; sombras = 8; contraste = 4; saturacion = 10; denoise = 6; nitidez = 7; grano = 3;
            exportMode = "HD profesional";
            setStatus("Preset HD profesional aplicado.");
        }));

        presets.addView(presetButton("TikTok/Reels", "1080p estable", () -> {
            brillo = 3; sombras = 8; contraste = 3; saturacion = 8; denoise = 6; nitidez = 5; grano = 4;
            exportResolution = "1080p Full HD";
            exportWidth = 1080; exportHeight = 1920; exportFps = 30; exportBitrate = 12;
            exportMode = "TikTok/Reels HD";
            setStatus("Preset TikTok/Reels HD aplicado.");
        }));

        root.addView(section("Ajustes manuales"));
        addSlider(root, "Brillo", 0, 20, brillo, v -> brillo = v);
        addSlider(root, "Sombras / Gamma", 0, 20, sombras, v -> sombras = v);
        addSlider(root, "Contraste", 0, 10, contraste, v -> contraste = v);
        addSlider(root, "Saturación", 0, 15, saturacion, v -> saturacion = v);
        addSlider(root, "Denoise / anti-manchas", 0, 10, denoise, v -> denoise = v);
        addSlider(root, "Nitidez", 0, 10, nitidez, v -> nitidez = v);
        addSlider(root, "Grano anti-banding", 0, 10, grano, v -> grano = v);

        root.addView(section("Exportación actual"));
        TextView exportBox = new TextView(this);
        exportBox.setTextColor(text);
        exportBox.setTextSize(14);
        exportBox.setBackgroundColor(card);
        exportBox.setPadding(dp(12), dp(12), dp(12), dp(12));
        exportBox.setText(getExportText());
        root.addView(exportBox);

        Button exportFinal = primaryButton("Configurar exportación");
        exportFinal.setOnClickListener(v -> showExportDialog());
        root.addView(exportFinal);

        status = new TextView(this);
        status.setTextSize(13);
        status.setTextColor(text);
        status.setPadding(dp(10), dp(12), dp(10), dp(40));
        status.setBackgroundColor(card);
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        statusParams.setMargins(0, dp(12), 0, dp(18));
        root.addView(status, statusParams);

        setContentView(scroll);
    }

    private void preparePlayer() {
        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        player.setRepeatMode(Player.REPEAT_MODE_ONE);
    }

    private void buildTimeline(boolean active) {
        timelineBar.removeAllViews();
        for (int i = 0; i < 14; i++) {
            View v = new View(this);
            v.setBackgroundColor(active ? (i % 3 == 0 ? purple : (i % 2 == 0 ? cyan : green)) : card2);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(34), 1);
            p.setMargins(dp(2), 0, dp(2), 0);
            timelineBar.addView(v, p);
        }
    }

    private TextView section(String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(17);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setTextColor(text);
        v.setPadding(0, dp(14), 0, dp(8));
        return v;
    }

    private TextView pill(String t, int color) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(12);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setTextColor(Color.WHITE);
        v.setBackgroundColor(color);
        v.setPadding(dp(10), dp(5), dp(10), dp(5));
        return v;
    }

    private Button primaryButton(String textValue) {
        Button b = new Button(this);
        b.setText(textValue);
        b.setTextSize(16);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(purple);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(54)
        );
        p.setMargins(0, dp(8), 0, dp(6));
        b.setLayoutParams(p);
        return b;
    }

    private Button smallPrimary(String textValue) {
        Button b = new Button(this);
        b.setText(textValue);
        b.setTextSize(15);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(purple);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(54), 1);
        p.setMargins(dp(4), dp(4), dp(4), dp(6));
        b.setLayoutParams(p);
        return b;
    }

    private View qualityCard(String title, String res, String sub, int w, int h, int fps, int mbps) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(card);
        box.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams boxP = new LinearLayout.LayoutParams(dp(126), dp(92));
        boxP.setMargins(0, 0, dp(10), 0);
        box.setLayoutParams(boxP);

        TextView a = new TextView(this);
        a.setText(title);
        a.setTextColor(text);
        a.setTextSize(16);
        a.setTypeface(Typeface.DEFAULT_BOLD);
        box.addView(a);

        TextView b = new TextView(this);
        b.setText(res);
        b.setTextColor(cyan);
        b.setTextSize(14);
        b.setPadding(0, dp(4), 0, 0);
        box.addView(b);

        TextView c = new TextView(this);
        c.setText(sub);
        c.setTextColor(muted);
        c.setTextSize(12);
        c.setPadding(0, dp(4), 0, 0);
        box.addView(c);

        box.setOnClickListener(v -> {
            exportResolution = title + " " + res;
            exportWidth = w;
            exportHeight = h;
            exportFps = fps;
            exportBitrate = mbps;
            setStatus("Calidad seleccionada: " + exportResolution);
            Toast.makeText(this, exportResolution, Toast.LENGTH_SHORT).show();
        });

        return box;
    }

    private View presetButton(String title, String sub, Runnable action) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(card);
        box.setPadding(dp(12), dp(12), dp(12), dp(12));
        LinearLayout.LayoutParams boxP = new LinearLayout.LayoutParams(dp(166), dp(92));
        boxP.setMargins(0, 0, dp(10), 0);
        box.setLayoutParams(boxP);

        TextView a = new TextView(this);
        a.setText(title);
        a.setTextColor(text);
        a.setTextSize(15);
        a.setTypeface(Typeface.DEFAULT_BOLD);
        box.addView(a);

        TextView b = new TextView(this);
        b.setText(sub);
        b.setTextColor(muted);
        b.setTextSize(12);
        b.setPadding(0, dp(6), 0, 0);
        box.addView(b);

        box.setOnClickListener(v -> {
            action.run();
            Toast.makeText(this, title, Toast.LENGTH_SHORT).show();
        });

        return box;
    }

    private interface Change {
        void set(int value);
    }

    private void addSlider(LinearLayout root, String name, int min, int max, int value, Change change) {
        TextView label = new TextView(this);
        label.setText(name + ": " + value);
        label.setTextColor(text);
        label.setTextSize(13);
        label.setPadding(0, dp(8), 0, 0);
        root.addView(label);

        SeekBar bar = new SeekBar(this);
        bar.setMax(max - min);
        bar.setProgress(value - min);
        root.addView(bar);

        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int real = min + progress;
                label.setText(name + ": " + real);
                change.set(real);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                setStatus("Ajuste actualizado.");
            }
        });
    }

    private void showExportDialog() {
        String[] options = new String[] {
                "720p HD / 30 FPS / 8 Mbps",
                "1080p Full HD / 30 FPS / 12 Mbps",
                "1080p Full HD / 60 FPS / 15 Mbps",
                "2K / 30 FPS / 20 Mbps",
                "4K / 30 FPS / 35 Mbps",
                "Exportar prueba ahora"
        };

        new AlertDialog.Builder(this)
                .setTitle("Exportar video")
                .setMessage("Configura cómo quieres exportar, parecido a CapCut. Recomendado para tus datos: 1080p / 30 FPS / 12 Mbps.")
                .setItems(options, (dialog, which) -> {
                    if (which == 0) setExport("720p HD", 720, 1280, 30, 8);
                    if (which == 1) setExport("1080p Full HD", 1080, 1920, 30, 12);
                    if (which == 2) setExport("1080p Full HD", 1080, 1920, 60, 15);
                    if (which == 3) setExport("2K", 1440, 2560, 30, 20);
                    if (which == 4) setExport("4K", 2160, 3840, 30, 35);
                    if (which == 5) exportCopy();
                })
                .setPositiveButton("Exportar prueba", (d, w) -> exportCopy())
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void setExport(String label, int w, int h, int fps, int mbps) {
        exportResolution = label;
        exportWidth = w;
        exportHeight = h;
        exportFps = fps;
        exportBitrate = mbps;
        setStatus("Exportación configurada: " + getExportText());
    }

    private void pickVideo() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("video/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {
                "video/mp4",
                "video/quicktime",
                "video/x-matroska",
                "video/webm",
                "video/x-msvideo",
                "video/3gpp",
                "video/x-ms-wmv",
                "video/*"
        });
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, REQ_PICK_VIDEO);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PICK_VIDEO && resultCode == RESULT_OK && data != null) {
            selectedVideo = data.getData();
            if (selectedVideo != null) {
                try {
                    getContentResolver().takePersistableUriPermission(
                            selectedVideo,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION
                    );
                } catch (Exception ignored) {}

                player.setMediaItem(MediaItem.fromUri(selectedVideo));
                player.prepare();
                player.play();

                fileInfo.setText("Video cargado: " + getFileName(selectedVideo));
                buildTimeline(true);
                setStatus("Video cargado. Formato aceptado por el selector Android. Si no se reproduce, puede ser un códec no soportado por tu celular.");
            }
        }
    }

    private String getFileName(Uri uri) {
        String result = "video seleccionado";
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) result = cursor.getString(index);
            }
        } catch (Exception ignored) {}
        return result;
    }

    private void exportCopy() {
        if (selectedVideo == null) {
            setStatus("Primero elige un video.");
            return;
        }

        setStatus("Exportando prueba sin marca...");

        try {
            String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            String fileName = "anime_hd_cleaner_v4_" + stamp + ".mp4";

            ContentValues values = new ContentValues();
            values.put(MediaStore.Video.Media.DISPLAY_NAME, fileName);
            values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/AnimeHDCleaner");

            ContentResolver resolver = getContentResolver();
            Uri outputUri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);

            if (outputUri == null) {
                setStatus("No se pudo crear el archivo de salida.");
                return;
            }

            try (InputStream in = resolver.openInputStream(selectedVideo);
                 OutputStream out = resolver.openOutputStream(outputUri)) {

                if (in == null || out == null) {
                    setStatus("No se pudo abrir el video.");
                    return;
                }

                byte[] buffer = new byte[1024 * 1024];
                int read;
                while ((read = in.read(buffer)) != -1) {
                    out.write(buffer, 0, read);
                }
                out.flush();
            }

            setStatus("Exportado sin marca en Galería > Movies > AnimeHDCleaner. La V5 agregará procesamiento real HD/4K.");
        } catch (Exception e) {
            setStatus("Error al exportar: " + e.getMessage());
        }
    }

    private String getExportText() {
        return exportMode
                + "\nResolución: " + exportResolution + " (" + exportWidth + "x" + exportHeight + ")"
                + "\nFPS: " + exportFps
                + "\nBitrate: " + exportBitrate + " Mbps"
                + "\nCódec: " + exportCodec
                + "\nAudio: AAC 192 kbps";
    }

    private void setStatus(String textValue) {
        if (status == null) return;
        status.setText(textValue + "\n\n" + resumen());
    }

    private String resumen() {
        return "Mejora actual:\n"
                + "Brillo " + brillo
                + " | Sombras " + sombras
                + " | Contraste " + contraste
                + " | Saturación " + saturacion
                + "\nDenoise " + denoise
                + " | Nitidez " + nitidez
                + " | Grano " + grano
                + "\n\nExportación:\n"
                + getExportText();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (player != null) player.pause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (player != null) {
            player.release();
            player = null;
        }
    }
}
