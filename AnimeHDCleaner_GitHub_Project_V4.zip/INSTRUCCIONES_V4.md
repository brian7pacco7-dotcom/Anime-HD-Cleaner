# Instrucciones V4

1. Borra el ZIP V3 del repositorio.
2. Sube este ZIP V4.
3. Ejecuta Actions.
4. Descarga el APK desde Artifacts.
5. Instala y prueba:
   - Importar video.
   - Ver preview.
   - Seleccionar calidad.
   - Abrir exportación.

La V4 no usa FFmpeg para evitar el error de dependencia.
