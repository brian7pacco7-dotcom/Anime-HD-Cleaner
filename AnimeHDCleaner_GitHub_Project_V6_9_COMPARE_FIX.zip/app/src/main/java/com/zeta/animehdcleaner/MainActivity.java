package com.zeta.animehdcleaner;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

public class MainActivity extends Activity {

    private static final int REQ_PICK_VIDEO = 1001;

    private Uri selectedVideo;
    private ExoPlayer player;
    private PlayerView playerView;
    private final ExportSettings settings = new ExportSettings();

    private String activeTab = "Ajustar";
    private String activeMode = "Brillo";
    private String activeQuality = "1080P";
    private int compareProgress = 50;

    private FrameLayout previewFrame;
    private View afterOverlay;
    private View divider;
    private TextView handle;
    private SeekBar compareSeek;

    private TextView fileInfo;
    private TextView activeSummary;
    private TextView exportSummary;
    private TextView quickValue;
    private TextView qualityDrop;
    private LinearLayout toolsRow;
    private LinearLayout lowerControls;
    private SeekBar quickSeek;
    private TextView quickTitle;

    private Dialog exportDialog;
    private ProgressBar exportProgress;
    private TextView exportPercent;
    private TextView exportState;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean exportDone = false;
    private int fakeProgress = 0;

    private final int dark = Color.rgb(13,14,18);
    private final int panel = Color.rgb(28,30,36);
    private final int card = Color.rgb(38,40,47);
    private final int white = Color.WHITE;
    private final int muted = Color.rgb(160,164,171);
    private final int cyan = Color.rgb(14,211,255);
    private final int green = Color.rgb(45,208,124);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initDefaults();
        buildUi();
        preparePlayer();
        refreshInfo();
    }

    private void initDefaults() {
        settings.modeName = activeMode;
        settings.qualityName = activeQuality;
        settings.width = 1080;
        settings.height = 1920;
        settings.fps = 30;
        settings.bitrateMbps = 12;
        settings.brightness = 4;
        settings.contrast = 3;
        settings.saturation = 8;
        settings.shadows = 10;
        settings.denoise = 7;
        settings.sharpen = 5;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(dark);
        root.setPadding(dp(12), dp(12), dp(12), dp(10));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(top);

        top.addView(topIcon("✕"));
        TextView help = topIcon("?");
        ((LinearLayout.LayoutParams) help.getLayoutParams()).leftMargin = dp(12);
        top.addView(help);
        TextView fire = topIcon("🔥");
        ((LinearLayout.LayoutParams) fire.getLayoutParams()).leftMargin = dp(12);
        top.addView(fire);
        View spacer = new View(this);
        top.addView(spacer, new LinearLayout.LayoutParams(0,1,1f));
        qualityDrop = topPill(activeQuality + " ▾");
        qualityDrop.setOnClickListener(v -> showQualitySelector());
        top.addView(qualityDrop);
        Button exportBtn = new Button(this);
        exportBtn.setText("Exportar");
        exportBtn.setAllCaps(false);
        exportBtn.setTextSize(16);
        exportBtn.setTypeface(Typeface.DEFAULT_BOLD);
        exportBtn.setTextColor(Color.BLACK);
        exportBtn.setBackgroundColor(cyan);
        LinearLayout.LayoutParams eb = new LinearLayout.LayoutParams(dp(128), dp(54));
        eb.leftMargin = dp(10);
        exportBtn.setLayoutParams(eb);
        exportBtn.setOnClickListener(v -> showExportConfirm());
        top.addView(exportBtn);

        Button importBtn = new Button(this);
        importBtn.setText("＋ Importar video");
        importBtn.setAllCaps(false);
        importBtn.setTextSize(17);
        importBtn.setTypeface(Typeface.DEFAULT_BOLD);
        importBtn.setTextColor(Color.BLACK);
        importBtn.setBackgroundColor(green);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        ip.topMargin = dp(10);
        root.addView(importBtn, ip);
        importBtn.setOnClickListener(v -> pickVideo());

        previewFrame = new FrameLayout(this);
        previewFrame.setBackgroundColor(Color.BLACK);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(380));
        pp.topMargin = dp(10);
        root.addView(previewFrame, pp);

        playerView = new PlayerView(this);
        playerView.setUseController(false);
        previewFrame.addView(playerView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        afterOverlay = new View(this);
        afterOverlay.setBackgroundColor(Color.argb(40,255,255,255));
        previewFrame.addView(afterOverlay, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        divider = new View(this);
        divider.setBackgroundColor(Color.WHITE);
        previewFrame.addView(divider, new FrameLayout.LayoutParams(dp(3), ViewGroup.LayoutParams.MATCH_PARENT));

        handle = new TextView(this);
        handle.setText("◀ ▶");
        handle.setTextColor(Color.DKGRAY);
        handle.setTypeface(Typeface.DEFAULT_BOLD);
        handle.setTextSize(12);
        handle.setGravity(Gravity.CENTER);
        handle.setBackgroundColor(Color.argb(240,255,255,255));
        previewFrame.addView(handle, new FrameLayout.LayoutParams(dp(62), dp(62)));

        previewFrame.addView(previewLabel("Before", Gravity.BOTTOM|Gravity.LEFT));
        previewFrame.addView(previewLabel("After", Gravity.BOTTOM|Gravity.RIGHT));

        previewFrame.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN || event.getAction() == MotionEvent.ACTION_MOVE) {
                updateCompareFromTouch(event.getX());
                return true;
            }
            return false;
        });

        compareSeek = new SeekBar(this);
        compareSeek.setMax(100);
        compareSeek.setProgress(compareProgress);
        compareSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                compareProgress = progress;
                updateCompareViews();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        root.addView(compareSeek);

        // QUICK LIVE CONTROL DIRECTLY UNDER VIDEO
        LinearLayout quickCard = new LinearLayout(this);
        quickCard.setOrientation(LinearLayout.VERTICAL);
        quickCard.setBackgroundColor(panel);
        quickCard.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams qcp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        qcp.topMargin = dp(6);
        root.addView(quickCard, qcp);

        quickTitle = infoTextBold("Ajuste rápido visible");
        quickCard.addView(quickTitle);
        quickValue = infoText("Valor actual");
        quickCard.addView(quickValue);
        quickSeek = new SeekBar(this);
        quickCard.addView(quickSeek);
        quickSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                applyQuickProgress(progress);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                Toast.makeText(MainActivity.this, "✓ Cambio aplicado y guardado", Toast.LENGTH_SHORT).show();
            }
        });

        activeSummary = infoText("");
        quickCard.addView(activeSummary);
        exportSummary = infoText("");
        quickCard.addView(exportSummary);

        LinearLayout actionRow = new LinearLayout(this);
        actionRow.setOrientation(LinearLayout.HORIZONTAL);
        actionRow.setPadding(0, dp(8), 0, 0);
        quickCard.addView(actionRow);
        actionRow.addView(actionBtn("Pantalla completa", () -> openFullscreen()));
        actionRow.addView(actionBtn("Exportar ahora", () -> showExportConfirm()));

        // LOWER PANEL
        LinearLayout lower = new LinearLayout(this);
        lower.setOrientation(LinearLayout.VERTICAL);
        lower.setBackgroundColor(panel);
        lower.setPadding(dp(12), dp(8), dp(12), dp(12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        lp.topMargin = dp(6);
        root.addView(lower, lp);

        fileInfo = new TextView(this);
        fileInfo.setTextColor(muted);
        fileInfo.setTextSize(12);
        lower.addView(fileInfo);

        LinearLayout tabRow = new LinearLayout(this);
        tabRow.setOrientation(LinearLayout.HORIZONTAL);
        tabRow.setPadding(0, dp(10), 0, 0);
        lower.addView(tabRow);
        tabRow.addView(tab("Filtros"));
        tabRow.addView(tab("Ajustar"));
        tabRow.addView(tab("Calidad del video"));

        toolsRow = new LinearLayout(this);
        toolsRow.setOrientation(LinearLayout.HORIZONTAL);
        HorizontalScrollView h = new HorizontalScrollView(this);
        h.setHorizontalScrollBarEnabled(false);
        h.setPadding(0, dp(10), 0, dp(8));
        h.addView(toolsRow);
        lower.addView(h);

        lowerControls = new LinearLayout(this);
        lowerControls.setOrientation(LinearLayout.VERTICAL);
        lower.addView(lowerControls);

        setContentView(root);
        rebuildTools();
        rebuildLowerControls();
        syncQuickControl();
        previewFrame.post(this::updateCompareViews);
    }

    private void rebuildTools() {
        toolsRow.removeAllViews();
        if (activeTab.equals("Ajustar")) {
            toolsRow.addView(tool("Brillo", activeMode.equals("Brillo"), () -> setMode("Brillo")));
            toolsRow.addView(tool("Contraste", activeMode.equals("Contraste"), () -> setMode("Contraste")));
            toolsRow.addView(tool("Saturación", activeMode.equals("Saturación"), () -> setMode("Saturación")));
            toolsRow.addView(tool("Sombras", activeMode.equals("Sombras"), () -> setMode("Sombras")));
            toolsRow.addView(tool("Nitidez", activeMode.equals("Nitidez"), () -> setMode("Nitidez")));
        } else if (activeTab.equals("Calidad del video")) {
            toolsRow.addView(tool("Reducir ruido", activeMode.equals("Reducir ruido"), () -> setMode("Reducir ruido")));
            toolsRow.addView(tool("Eliminar parpadeos", activeMode.equals("Eliminar parpadeos"), () -> setMode("Eliminar parpadeos")));
            toolsRow.addView(tool("Calidad", activeMode.equals("Calidad"), () -> setMode("Calidad")));
        } else {
            toolsRow.addView(tool("Color IA", activeMode.equals("Color IA"), () -> setMode("Color IA")));
            toolsRow.addView(tool("Anime HD", activeMode.equals("Anime HD"), () -> setMode("Anime HD")));
            toolsRow.addView(tool("Sombras IA", activeMode.equals("Sombras IA"), () -> setMode("Sombras IA")));
        }
    }

    private void rebuildLowerControls() {
        lowerControls.removeAllViews();
        TextView t = infoText("Aquí eliges la función. Arriba ves el cambio y abajo queda guardado.");
        lowerControls.addView(t);
    }

    private void setMode(String mode) {
        activeMode = mode;
        settings.modeName = mode;
        rebuildTools();
        syncQuickControl();
        refreshInfo();
        Toast.makeText(this, "✓ " + mode + " seleccionado", Toast.LENGTH_SHORT).show();
    }

    private void syncQuickControl() {
        quickTitle.setText("Ajuste rápido: " + activeMode);
        if (activeMode.equals("Brillo")) { quickSeek.setMax(10); quickSeek.setProgress(settings.brightness); }
        else if (activeMode.equals("Contraste")) { quickSeek.setMax(10); quickSeek.setProgress(settings.contrast); }
        else if (activeMode.equals("Saturación")) { quickSeek.setMax(15); quickSeek.setProgress(settings.saturation); }
        else if (activeMode.equals("Sombras") || activeMode.equals("Sombras IA")) { quickSeek.setMax(20); quickSeek.setProgress(settings.shadows); }
        else if (activeMode.equals("Nitidez") || activeMode.equals("Anime HD")) { quickSeek.setMax(10); quickSeek.setProgress(settings.sharpen); }
        else if (activeMode.equals("Reducir ruido")) { quickSeek.setMax(15); quickSeek.setProgress(settings.denoise); }
        else if (activeMode.equals("Color IA")) { quickSeek.setMax(15); quickSeek.setProgress(settings.saturation); }
        else { quickSeek.setMax(20); quickSeek.setProgress(settings.bitrateMbps); }
        refreshQuickValue();
    }

    private void applyQuickProgress(int progress) {
        if (activeMode.equals("Brillo")) settings.brightness = progress;
        else if (activeMode.equals("Contraste")) settings.contrast = progress;
        else if (activeMode.equals("Saturación")) settings.saturation = progress;
        else if (activeMode.equals("Sombras") || activeMode.equals("Sombras IA")) settings.shadows = progress;
        else if (activeMode.equals("Nitidez") || activeMode.equals("Anime HD")) settings.sharpen = progress;
        else if (activeMode.equals("Reducir ruido")) settings.denoise = progress;
        else if (activeMode.equals("Color IA")) settings.saturation = progress;
        else settings.bitrateMbps = Math.max(8, progress);
        refreshQuickValue();
        refreshInfo();
    }

    private void refreshQuickValue() {
        String val;
        if (activeMode.equals("Brillo")) val = String.valueOf(settings.brightness);
        else if (activeMode.equals("Contraste")) val = String.valueOf(settings.contrast);
        else if (activeMode.equals("Saturación") || activeMode.equals("Color IA")) val = String.valueOf(settings.saturation);
        else if (activeMode.equals("Sombras") || activeMode.equals("Sombras IA")) val = String.valueOf(settings.shadows);
        else if (activeMode.equals("Nitidez") || activeMode.equals("Anime HD")) val = String.valueOf(settings.sharpen);
        else if (activeMode.equals("Reducir ruido")) val = String.valueOf(settings.denoise);
        else val = settings.bitrateMbps + " Mbps";
        quickValue.setText("Valor actual aplicado: " + val + "  •  sí se guardó");
    }

    private void refreshInfo() {
        qualityDrop.setText(activeQuality + " ▾");
        fileInfo.setText(selectedVideo == null ? "Primero toca "＋ Importar video"." : "Video cargado: " + getFileName(selectedVideo));
        activeSummary.setText("
Cambios activos ahora:
• Modo: " + activeMode + "
• Calidad: " + activeQuality + "
• Brillo " + settings.brightness + " • Contraste " + settings.contrast + " • Saturación " + settings.saturation + " • Sombras " + settings.shadows + " • Nitidez " + settings.sharpen + " • Ruido " + settings.denoise + "
Si cambias un slider, aquí se actualiza al instante.");
        exportSummary.setText("
Al exportar se aplicará esto:
• " + settings.width + "x" + settings.height + " • " + settings.fps + " FPS • " + settings.bitrateMbps + " Mbps
• Motor HD real activado
• Si la barra de exportación avanza, sí está trabajando.");
    }

    private void showQualitySelector() {
        String[] options = {"720P", "1080P", "UHD"};
        new AlertDialog.Builder(this)
                .setTitle("Elegir calidad")
                .setItems(options, (d, which) -> {
                    if (which == 0) setQuality("720P", 720, 1280, 30, 8);
                    if (which == 1) setQuality("1080P", 1080, 1920, 30, 12);
                    if (which == 2) setQuality("UHD", 2160, 3840, 30, 35);
                }).show();
    }

    private void setQuality(String name, int w, int h, int fps, int mbps) {
        activeQuality = name;
        settings.qualityName = name;
        settings.width = w;
        settings.height = h;
        settings.fps = fps;
        settings.bitrateMbps = mbps;
        syncQuickControl();
        refreshInfo();
    }

    private void showExportConfirm() {
        if (selectedVideo == null) {
            Toast.makeText(this, "Primero importa un video.", Toast.LENGTH_SHORT).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Exportación HD")
                .setMessage("Se va a exportar con:

" + settings.summary() + "

Esto sí es lo que se aplicará al archivo final.")
                .setPositiveButton("Exportar", (d,w) -> exportHd())
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void exportHd() {
        showProgressDialog();
        fakeProgress = 0;
        exportDone = false;
        stepProgress();
        RealHdExporter.export(this, selectedVideo, settings, new RealHdExporter.Listener() {
            @Override public void onLog(String message) {
                runOnUiThread(() -> { if (exportState != null) exportState.setText(message + "
No cierres la app."); });
            }
            @Override public void onFinished(boolean success, Uri outputUri, String message) {
                runOnUiThread(() -> {
                    exportDone = true;
                    exportProgress.setProgress(100);
                    exportPercent.setText("100%");
                    exportState.setText(message + "
Se aplicaron los cambios activos.");
                    handler.postDelayed(() -> {
                        if (exportDialog != null && exportDialog.isShowing()) exportDialog.dismiss();
                        Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
                    }, 1200);
                });
            }
        });
    }

    private void showProgressDialog() {
        exportDialog = new Dialog(this);
        exportDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(card);
        root.setPadding(dp(20), dp(20), dp(20), dp(20));
        TextView t = infoTextBold("Procesando exportación HD real");
        t.setTextSize(22);
        t.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(t);
        exportProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        exportProgress.setMax(100);
        exportProgress.setProgress(0);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        pp.topMargin = dp(16);
        root.addView(exportProgress, pp);
        exportPercent = infoTextBold("0%");
        exportPercent.setTextSize(20);
        exportPercent.setGravity(Gravity.CENTER_HORIZONTAL);
        exportPercent.setPadding(0, dp(10), 0, dp(6));
        root.addView(exportPercent);
        exportState = infoText("Preparando...");
        exportState.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(exportState);
        exportDialog.setContentView(root);
        exportDialog.setCancelable(false);
        exportDialog.show();
    }

    private void stepProgress() {
        if (exportDone) return;
        fakeProgress += fakeProgress < 70 ? 8 : 2;
        if (fakeProgress > 95) fakeProgress = 95;
        exportProgress.setProgress(fakeProgress);
        exportPercent.setText(fakeProgress + "%");
        String msg;
        if (fakeProgress < 20) msg = "Analizando video...";
        else if (fakeProgress < 40) msg = "Aplicando cambios guardados...";
        else if (fakeProgress < 60) msg = "Procesando motor HD...";
        else if (fakeProgress < 80) msg = "Codificando salida...";
        else msg = "Guardando archivo final...";
        exportState.setText(msg + "
No cierres la app.");
        handler.postDelayed(this::stepProgress, 700);
    }

    private void pickVideo() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("video/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"video/mp4", "video/quicktime", "video/x-matroska", "video/webm", "video/x-msvideo", "video/3gpp", "video/x-ms-wmv", "video/*"});
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, REQ_PICK_VIDEO);
    }

    private void openFullscreen() {
        if (selectedVideo == null) { Toast.makeText(this, "Primero importa un video.", Toast.LENGTH_SHORT).show(); return; }
        Intent i = new Intent(this, FullscreenCompareActivity.class);
        i.putExtra("video_uri", selectedVideo.toString());
        i.putExtra("title", activeMode);
        i.putExtra("subtitle", "Desliza la línea del centro o la barra inferior");
        i.putExtra("compare_progress", compareProgress);
        startActivity(i);
    }

    private void preparePlayer() {
        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        player.setRepeatMode(Player.REPEAT_MODE_ONE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PICK_VIDEO && resultCode == RESULT_OK && data != null) {
            selectedVideo = data.getData();
            if (selectedVideo != null) {
                try { getContentResolver().takePersistableUriPermission(selectedVideo, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
                player.setMediaItem(MediaItem.fromUri(selectedVideo));
                player.prepare();
                player.play();
                refreshInfo();
            }
        }
    }

    private String getFileName(Uri uri) {
        String result = "video seleccionado";
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) result = cursor.getString(idx);
            }
        } catch (Exception ignored) {}
        return result;
    }

    private void updateCompareFromTouch(float touchX) {
        if (previewFrame == null || previewFrame.getWidth() == 0) return;
        int w = previewFrame.getWidth();
        int p = Math.max(0, Math.min(100, Math.round((touchX / w) * 100f)));
        compareProgress = p;
        compareSeek.setProgress(p);
        updateCompareViews();
    }

    private void updateCompareViews() {
        if (previewFrame == null || previewFrame.getWidth() == 0) return;
        int w = previewFrame.getWidth();
        int h = previewFrame.getHeight();
        int x = (int)(w * (compareProgress / 100f));
        FrameLayout.LayoutParams overlay = (FrameLayout.LayoutParams) afterOverlay.getLayoutParams();
        overlay.width = Math.max(0, w - x);
        overlay.height = h;
        overlay.gravity = Gravity.RIGHT;
        afterOverlay.setLayoutParams(overlay);
        FrameLayout.LayoutParams line = (FrameLayout.LayoutParams) divider.getLayoutParams();
        line.width = dp(3);
        line.height = h;
        line.leftMargin = Math.max(0, x - dp(1));
        divider.setLayoutParams(line);
        FrameLayout.LayoutParams hp = (FrameLayout.LayoutParams) handle.getLayoutParams();
        hp.width = dp(62);
        hp.height = dp(62);
        hp.leftMargin = Math.max(0, Math.min(w - dp(62), x - dp(31)));
        hp.topMargin = Math.max(0, h / 2 - dp(31));
        handle.setLayoutParams(hp);
        divider.bringToFront();
        handle.bringToFront();
    }

    private TextView topIcon(String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextColor(white);
        v.setGravity(Gravity.CENTER);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setTextSize(20);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(36), dp(36)));
        return v;
    }

    private TextView topPill(String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextColor(white);
        v.setTextSize(16);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setGravity(Gravity.CENTER);
        v.setBackgroundColor(card);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(110), dp(54)));
        return v;
    }

    private TextView previewLabel(String text, int gravity) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(white);
        v.setTextSize(18);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, gravity);
        p.leftMargin = dp(14);
        p.rightMargin = dp(14);
        p.bottomMargin = dp(14);
        v.setLayoutParams(p);
        return v;
    }

    private View actionBtn(String text, Runnable run) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(white);
        b.setBackgroundColor(card);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(44), 1f);
        p.rightMargin = dp(8);
        b.setLayoutParams(p);
        b.setOnClickListener(v -> run.run());
        return b;
    }

    private TextView tab(String name) {
        TextView v = new TextView(this);
        v.setText(name);
        v.setTextColor(activeTab.equals(name) ? white : muted);
        v.setTypeface(activeTab.equals(name) ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        v.setGravity(Gravity.CENTER);
        v.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        v.setOnClickListener(view -> { activeTab = name; rebuildTools(); rebuildLowerControls(); });
        return v;
    }

    private TextView tool(String name, boolean active, Runnable run) {
        TextView v = new TextView(this);
        v.setText((active ? "✓
" : "○
") + name);
        v.setTextColor(active ? cyan : white);
        v.setGravity(Gravity.CENTER);
        v.setBackgroundColor(card);
        v.setPadding(dp(8), dp(10), dp(8), dp(10));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(110), dp(80));
        p.rightMargin = dp(10);
        v.setLayoutParams(p);
        v.setOnClickListener(view -> run.run());
        return v;
    }

    private TextView infoText(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(white);
        v.setTextSize(13);
        return v;
    }

    private TextView infoTextBold(String text) {
        TextView v = infoText(text);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override protected void onStop() { super.onStop(); if (player != null) player.pause(); }
    @Override protected void onDestroy() { super.onDestroy(); handler.removeCallbacksAndMessages(null); if (player != null) { player.release(); player = null; } }
}
