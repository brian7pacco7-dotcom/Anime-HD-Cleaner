# Anime HD Cleaner V6.9 COMPARE FIX

- Línea central del comparador corregida.
- Sliders rápidos arriba, justo debajo del video.
- Muestra en vivo qué cambios sí están aplicados.
- Mantiene motor HD real.
