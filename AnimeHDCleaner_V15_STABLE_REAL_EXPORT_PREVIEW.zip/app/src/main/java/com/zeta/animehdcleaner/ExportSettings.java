package com.zeta.animehdcleaner;

import java.io.Serializable;

public class ExportSettings implements Serializable {
    public String modeName = "Normal";
    public String qualityName = "Original";

    // 0 = mantener resolucion original
    public int width = 0;
    public int height = 0;

    public int fps = 24;
    public int bitrateMbps = 8;

    // 10 = normal. 0 baja fuerte. 20 sube fuerte.
    public int brightness = 10;
    public int contrast = 10;
    public int saturation = 10;
    public int luminosity = 10;

    public int sharpen = 10;
    public int denoise = 10;

    public String resolutionText() {
        if (width <= 0 || height <= 0) return "Original";
        return width + "x" + height;
    }
}
