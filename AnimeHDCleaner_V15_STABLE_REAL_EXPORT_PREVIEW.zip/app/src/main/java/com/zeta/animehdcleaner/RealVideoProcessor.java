package com.zeta.animehdcleaner;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.File;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class RealVideoProcessor {

    public interface Listener {
        void onProgress(int percent, String message);
        void onFinished(boolean success, Uri outputUri, String message);
    }

    private static final String MIME_VIDEO = "video/avc";
    private static final long TIMEOUT_US = 10000;

    public static void export(Context context, Uri inputUri, ExportSettings settings, Listener listener) {
        new Thread(() -> {
            MediaMetadataRetriever retriever = null;
            MediaExtractor audioExtractor = null;
            MediaCodec encoder = null;
            MediaMuxer muxer = null;
            File tempFile = null;

            try {
                listener.onProgress(1, "Leyendo video...");

                VideoInfo info = VideoInfo.read(context, inputUri);
                int originalW = info.width > 0 ? info.width : 720;
                int originalH = info.height > 0 ? info.height : 720;
                int outW = makeEven(settings.width > 0 ? settings.width : originalW);
                int outH = makeEven(settings.height > 0 ? settings.height : originalH);
                int fps = Math.max(8, Math.min(60, settings.fps));
                int bitrate = Math.max(2, settings.bitrateMbps) * 1000 * 1000;
                long durationUs = info.durationMs > 0 ? info.durationMs * 1000L : 10_000_000L;
                int frameCount = Math.max(1, (int)Math.ceil((durationUs / 1_000_000.0) * fps));

                retriever = new MediaMetadataRetriever();
                retriever.setDataSource(context, inputUri);

                String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
                String displayName = "anime_hd_cleaner_real_" + stamp + ".mp4";
                tempFile = new File(context.getCacheDir(), displayName);
                if (tempFile.exists()) tempFile.delete();

                MediaCodecInfo codecInfo = selectCodec();
                int colorFormat = selectColorFormat(codecInfo);

                MediaFormat videoFormat = MediaFormat.createVideoFormat(MIME_VIDEO, outW, outH);
                videoFormat.setInteger(MediaFormat.KEY_COLOR_FORMAT, colorFormat);
                videoFormat.setInteger(MediaFormat.KEY_BIT_RATE, bitrate);
                videoFormat.setInteger(MediaFormat.KEY_FRAME_RATE, fps);
                videoFormat.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);

                encoder = MediaCodec.createByCodecName(codecInfo.getName());
                encoder.configure(videoFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
                encoder.start();

                muxer = new MediaMuxer(tempFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);

                int audioMuxerTrack = -1;
                audioExtractor = new MediaExtractor();
                try {
                    audioExtractor.setDataSource(context, inputUri, null);
                    int audioTrack = selectAudioTrack(audioExtractor);
                    if (audioTrack >= 0) {
                        audioExtractor.selectTrack(audioTrack);
                        MediaFormat af = audioExtractor.getTrackFormat(audioTrack);
                        audioMuxerTrack = muxer.addTrack(af);
                    }
                } catch (Exception ignored) {
                    audioMuxerTrack = -1;
                }

                MediaCodec.BufferInfo outInfo = new MediaCodec.BufferInfo();
                MuxState state = new MuxState();
                state.muxer = muxer;
                state.audioMuxerTrack = audioMuxerTrack;

                Bitmap work = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(work);
                Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
                paint.setColorFilter(FilterMath.makeFilter(settings));
                byte[] yuv = new byte[outW * outH * 3 / 2];

                listener.onProgress(3, "Procesando video completo...");

                for (int i = 0; i < frameCount; i++) {
                    long ptsUs = (i * 1_000_000L) / fps;
                    long srcUs = Math.min(durationUs - 1, ptsUs);

                    Bitmap frame = retriever.getFrameAtTime(srcUs, MediaMetadataRetriever.OPTION_CLOSEST);
                    canvas.drawColor(Color.BLACK);
                    if (frame != null) {
                        RectF dst = centerFitRect(frame.getWidth(), frame.getHeight(), outW, outH);
                        canvas.drawBitmap(frame, null, dst, paint);
                        frame.recycle();
                    }

                    if (colorFormat == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar) {
                        bitmapToI420(work, yuv, outW, outH);
                    } else {
                        bitmapToNV12(work, yuv, outW, outH);
                    }

                    boolean queued = false;
                    while (!queued) {
                        int inputIndex = encoder.dequeueInputBuffer(TIMEOUT_US);
                        if (inputIndex >= 0) {
                            ByteBuffer input = encoder.getInputBuffer(inputIndex);
                            if (input == null) throw new RuntimeException("Buffer de entrada nulo");
                            input.clear();
                            input.put(yuv);
                            encoder.queueInputBuffer(inputIndex, 0, yuv.length, ptsUs, 0);
                            queued = true;
                        }
                        drainEncoder(encoder, outInfo, state, false);
                    }

                    drainEncoder(encoder, outInfo, state, false);

                    int percent = 5 + (int)((i + 1) * 82L / frameCount);
                    listener.onProgress(percent, "Aplicando filtros al video " + percent + "%");
                }

                // EOS
                boolean eosQueued = false;
                while (!eosQueued) {
                    int inputIndex = encoder.dequeueInputBuffer(TIMEOUT_US);
                    if (inputIndex >= 0) {
                        long eosPtsUs = (frameCount * 1_000_000L) / fps;
                        encoder.queueInputBuffer(inputIndex, 0, 0, eosPtsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                        eosQueued = true;
                    }
                    drainEncoder(encoder, outInfo, state, false);
                }

                drainEncoder(encoder, outInfo, state, true);

                try {
                    work.recycle();
                } catch (Exception ignored) {}

                if (audioMuxerTrack >= 0 && state.muxerStarted) {
                    listener.onProgress(90, "Agregando audio...");
                    copyAudio(audioExtractor, audioMuxerTrack, muxer);
                }

                try { muxer.stop(); } catch (Exception ignored) {}

                listener.onProgress(96, "Guardando...");
                Uri outputUri = saveToGallery(context, tempFile, displayName);

                listener.onProgress(100, "Listo");
                listener.onFinished(true, outputUri, "Video exportado con filtros aplicados");

            } catch (Exception e) {
                listener.onFinished(false, null, "Error: " + (e.getMessage() == null ? e.toString() : e.getMessage()));
            } finally {
                try { if (retriever != null) retriever.release(); } catch (Exception ignored) {}
                try { if (audioExtractor != null) audioExtractor.release(); } catch (Exception ignored) {}
                try { if (encoder != null) { encoder.stop(); encoder.release(); } } catch (Exception ignored) {}
                try { if (muxer != null) muxer.release(); } catch (Exception ignored) {}
            }
        }).start();
    }

    private static class MuxState {
        MediaMuxer muxer;
        boolean muxerStarted = false;
        int videoTrack = -1;
        int audioMuxerTrack = -1;
    }

    private static void drainEncoder(MediaCodec encoder, MediaCodec.BufferInfo info, MuxState state, boolean end) {
        while (true) {
            int status = encoder.dequeueOutputBuffer(info, TIMEOUT_US);

            if (status == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!end) break;
            } else if (status == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                if (state.muxerStarted) throw new RuntimeException("Formato cambio dos veces");
                MediaFormat newFormat = encoder.getOutputFormat();
                state.videoTrack = state.muxer.addTrack(newFormat);
                state.muxer.start();
                state.muxerStarted = true;
            } else if (status >= 0) {
                ByteBuffer encoded = encoder.getOutputBuffer(status);
                if (encoded == null) throw new RuntimeException("Buffer de salida nulo");

                if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                    info.size = 0;
                }

                if (info.size > 0 && state.muxerStarted) {
                    encoded.position(info.offset);
                    encoded.limit(info.offset + info.size);
                    state.muxer.writeSampleData(state.videoTrack, encoded, info);
                }

                boolean eos = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
                encoder.releaseOutputBuffer(status, false);
                if (eos) break;
            }
        }
    }

    private static MediaCodecInfo selectCodec() {
        MediaCodecList list = new MediaCodecList(MediaCodecList.REGULAR_CODECS);
        MediaCodecInfo[] infos = list.getCodecInfos();
        for (MediaCodecInfo info : infos) {
            if (!info.isEncoder()) continue;
            try {
                for (String type : info.getSupportedTypes()) {
                    if (MIME_VIDEO.equalsIgnoreCase(type)) {
                        int cf = selectColorFormat(info);
                        if (cf != 0) return info;
                    }
                }
            } catch (Exception ignored) {}
        }
        throw new RuntimeException("No hay encoder H.264 compatible");
    }

    private static int selectColorFormat(MediaCodecInfo info) {
        try {
            MediaCodecInfo.CodecCapabilities caps = info.getCapabilitiesForType(MIME_VIDEO);
            int fallback = 0;
            for (int c : caps.colorFormats) {
                if (c == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar) return c;
                if (c == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar) fallback = c;
                if (c == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible && fallback == 0) fallback = c;
            }
            return fallback;
        } catch (Exception e) {
            return 0;
        }
    }

    private static int selectAudioTrack(MediaExtractor extractor) {
        for (int i = 0; i < extractor.getTrackCount(); i++) {
            MediaFormat f = extractor.getTrackFormat(i);
            String mime = f.getString(MediaFormat.KEY_MIME);
            if (mime != null && mime.startsWith("audio/")) return i;
        }
        return -1;
    }

    private static void copyAudio(MediaExtractor extractor, int track, MediaMuxer muxer) {
        ByteBuffer buffer = ByteBuffer.allocate(1024 * 1024);
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();

        while (true) {
            buffer.clear();
            int size = extractor.readSampleData(buffer, 0);
            if (size < 0) break;
            info.set(0, size, extractor.getSampleTime(), extractor.getSampleFlags());
            muxer.writeSampleData(track, buffer, info);
            extractor.advance();
        }
    }

    private static Uri saveToGallery(Context context, File temp, String displayName) throws Exception {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Video.Media.DISPLAY_NAME, displayName);
        values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/AnimeHDCleaner");

        ContentResolver resolver = context.getContentResolver();
        Uri uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new RuntimeException("No se pudo crear salida");

        try (java.io.InputStream in = new java.io.FileInputStream(temp);
             java.io.OutputStream out = resolver.openOutputStream(uri)) {
            if (out == null) throw new RuntimeException("No se pudo abrir salida");
            byte[] b = new byte[1024 * 1024];
            int r;
            while ((r = in.read(b)) != -1) out.write(b, 0, r);
            out.flush();
        }

        try { temp.delete(); } catch (Exception ignored) {}
        return uri;
    }

    private static RectF centerFitRect(int srcW, int srcH, int dstW, int dstH) {
        float srcRatio = srcW / (float) srcH;
        float dstRatio = dstW / (float) dstH;
        float drawW, drawH;

        if (srcRatio > dstRatio) {
            drawW = dstW;
            drawH = dstW / srcRatio;
        } else {
            drawH = dstH;
            drawW = dstH * srcRatio;
        }

        float left = (dstW - drawW) / 2f;
        float top = (dstH - drawH) / 2f;
        return new RectF(left, top, left + drawW, top + drawH);
    }

    private static void bitmapToNV12(Bitmap bitmap, byte[] out, int width, int height) {
        int[] pixels = new int[width * height];
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height);

        int frameSize = width * height;
        int uvIndex = frameSize;

        for (int y = 0; y < height; y++) {
            int row = y * width;
            for (int x = 0; x < width; x++) {
                int argb = pixels[row + x];
                int r = (argb >> 16) & 0xff;
                int g = (argb >> 8) & 0xff;
                int b = argb & 0xff;

                int yy = ((66 * r + 129 * g + 25 * b + 128) >> 8) + 16;
                int uu = ((-38 * r - 74 * g + 112 * b + 128) >> 8) + 128;
                int vv = ((112 * r - 94 * g - 18 * b + 128) >> 8) + 128;

                out[row + x] = (byte) clamp(yy);

                if ((y & 1) == 0 && (x & 1) == 0 && uvIndex + 1 < out.length) {
                    out[uvIndex++] = (byte) clamp(uu);
                    out[uvIndex++] = (byte) clamp(vv);
                }
            }
        }
    }

    private static void bitmapToI420(Bitmap bitmap, byte[] out, int width, int height) {
        int[] pixels = new int[width * height];
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height);

        int frameSize = width * height;
        int uIndex = frameSize;
        int vIndex = frameSize + frameSize / 4;

        for (int y = 0; y < height; y++) {
            int row = y * width;
            for (int x = 0; x < width; x++) {
                int argb = pixels[row + x];
                int r = (argb >> 16) & 0xff;
                int g = (argb >> 8) & 0xff;
                int b = argb & 0xff;

                int yy = ((66 * r + 129 * g + 25 * b + 128) >> 8) + 16;
                int uu = ((-38 * r - 74 * g + 112 * b + 128) >> 8) + 128;
                int vv = ((112 * r - 94 * g - 18 * b + 128) >> 8) + 128;

                out[row + x] = (byte) clamp(yy);

                if ((y & 1) == 0 && (x & 1) == 0) {
                    if (uIndex < frameSize + frameSize / 4) out[uIndex++] = (byte) clamp(uu);
                    if (vIndex < out.length) out[vIndex++] = (byte) clamp(vv);
                }
            }
        }
    }

    private static int makeEven(int value) {
        if (value < 2) return 2;
        return value % 2 == 0 ? value : value - 1;
    }

    private static int clamp(int v) {
        return Math.max(0, Math.min(255, v));
    }
}
