# Anime HD Cleaner V15 STABLE REAL EXPORT PREVIEW

Correcciones importantes:
- Eliminado ExoPlayer del editor para que los filtros no se quiten al reproducir.
- El preview ahora reproduce frames con filtros aplicados en vivo.
- Brillo, contraste, saturación y luminosidad se ven durante la reproducción del preview.
- Exportación reescrita con encoder por ByteBuffer y timestamps fijos.
- Corrige el error de duración gigante tipo 59:39:08.
- Calidad por defecto: Original, 12 FPS, 6 Mbps para exportar más rápido.
- Sin timeline falso ni onda de audio inútil.
- Botones Predefinidos, Filtros, Ajustar y Calidad sí funcionan.

Limitaciones:
- El preview es sin audio.
- Exportar todavía demora porque procesa frame por frame.
- Para exportar rápido usa Calidad > Original.
