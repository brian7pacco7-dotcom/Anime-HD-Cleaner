# Anime HD Cleaner V10.2 INTERNET PRESETS

Corrección pedida:
- Se agregó funcionamiento con internet sin IA real.
- Botón Online para descargar mejoras desde GitHub.
- Permiso INTERNET agregado.
- Archivo presets.json incluido en la raíz del repo.
- Las mejoras siguen visibles en una pantalla.
- Cuando un preset online se descarga, aparece marcado con NET.
- Si seleccionas un preset NET, se aplican los valores descargados desde internet.

## Importante

Esto no usa IA real de servidor. Funciona por internet para actualizar presets:
brillo, contraste, saturación, luminosidad, enfoque, ruido, calidad, bitrate y resolución.

## URL usada por la app

La app descarga:

https://raw.githubusercontent.com/brian7pacco7-dotcom/Anime-HD-Cleaner/main/presets.json

Si tu repo tiene otro nombre o usuario, cambia la URL en:

app/src/main/java/com/zeta/animehdcleaner/OnlinePresetManager.java

## Cómo probar

1. Sube todo el ZIP a GitHub.
2. Asegúrate de que `presets.json` esté en la raíz del repo.
3. Compila APK en Actions.
4. Instala.
5. Abre la app.
6. Toca el botón **Online**.
7. Debe decir: **Mejoras online cargadas**.
