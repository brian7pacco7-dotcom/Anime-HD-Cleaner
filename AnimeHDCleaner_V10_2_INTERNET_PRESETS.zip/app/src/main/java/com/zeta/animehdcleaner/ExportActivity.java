package com.zeta.animehdcleaner;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class ExportActivity extends Activity {

    private Uri videoUri;
    private ExportSettings settings;
    private ProgressBar progressBar;
    private TextView percent;
    private TextView state;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String uriText = getIntent().getStringExtra("video_uri");
        if (uriText != null) videoUri = Uri.parse(uriText);

        Object obj = getIntent().getSerializableExtra("settings");
        if (obj instanceof ExportSettings) {
            settings = (ExportSettings) obj;
        } else {
            settings = new ExportSettings();
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(36), dp(20), dp(20));
        root.setBackgroundColor(0xFF090D12);

        TextView title = text("Exportacion HD", 26, true);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView summary = text(settings.summary(), 14, false);
        summary.setPadding(0, dp(18), 0, dp(18));
        root.addView(summary);

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        root.addView(progressBar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        percent = text("0%", 22, true);
        percent.setGravity(Gravity.CENTER);
        percent.setPadding(0, dp(12), 0, dp(8));
        root.addView(percent);

        state = text("Listo para exportar", 15, false);
        state.setGravity(Gravity.CENTER);
        root.addView(state);

        Button start = new Button(this);
        start.setText("Exportar ahora");
        start.setAllCaps(false);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56));
        sp.topMargin = dp(18);
        root.addView(start, sp);
        start.setOnClickListener(v -> startExport());

        Button close = new Button(this);
        close.setText("Volver");
        close.setAllCaps(false);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        cp.topMargin = dp(8);
        root.addView(close, cp);
        close.setOnClickListener(v -> finish());

        setContentView(root);
    }

    private void startExport() {
        if (videoUri == null) {
            Toast.makeText(this, "No hay video", Toast.LENGTH_SHORT).show();
            return;
        }

        LocalExporter.export(this, videoUri, settings, new LocalExporter.Listener() {
            @Override public void onProgress(int p, String message) {
                runOnUiThread(() -> {
                    progressBar.setProgress(p);
                    percent.setText(p + "%");
                    state.setText(message);
                });
            }

            @Override public void onFinished(boolean success, Uri outputUri, String message) {
                runOnUiThread(() -> {
                    progressBar.setProgress(100);
                    percent.setText("100%");
                    state.setText(message);
                    Toast.makeText(ExportActivity.this, message, Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private TextView text(String value, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(size);
        if (bold) t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        return t;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
