package com.zeta.animehdcleaner;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class OnlinePresetManager {

    // Cuando subas el ZIP a tu repo, este archivo debe existir en la raiz:
    // presets.json
    // Si tu usuario o repo cambia, cambia esta URL.
    public static final String PRESETS_URL =
            "https://raw.githubusercontent.com/brian7pacco7-dotcom/Anime-HD-Cleaner/main/presets.json";

    public interface Listener {
        void onSuccess(int count);
        void onError(String message);
    }

    public static void fetch(Listener listener) {
        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                URL url = new URL(PRESETS_URL);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(12000);
                connection.setReadTimeout(12000);
                connection.setUseCaches(false);

                int code = connection.getResponseCode();
                if (code < 200 || code >= 300) {
                    listener.onError("Servidor respondio: " + code);
                    return;
                }

                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder builder = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    builder.append(line);
                }
                reader.close();

                JSONObject root = new JSONObject(builder.toString());
                JSONArray presets = root.getJSONArray("presets");

                PresetManager.clearOnlinePresets();

                for (int i = 0; i < presets.length(); i++) {
                    JSONObject item = presets.getJSONObject(i);
                    String name = item.getString("name");

                    ExportSettings settings = new ExportSettings();
                    settings.modeName = name;
                    settings.qualityName = item.optString("quality", "1080P");
                    settings.width = item.optInt("width", 1080);
                    settings.height = item.optInt("height", 1920);
                    settings.fps = item.optInt("fps", 30);
                    settings.bitrateMbps = item.optInt("bitrateMbps", 12);
                    settings.brightness = item.optInt("brightness", 4);
                    settings.contrast = item.optInt("contrast", 4);
                    settings.saturation = item.optInt("saturation", 9);
                    settings.luminosity = item.optInt("luminosity", 10);
                    settings.sharpen = item.optInt("sharpen", 7);
                    settings.denoise = item.optInt("denoise", 7);

                    PresetManager.setOnlinePreset(name, settings);
                }

                listener.onSuccess(PresetManager.onlineCount());

            } catch (Exception e) {
                listener.onError(e.getMessage() == null ? "Error de internet" : e.getMessage());
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }
        }).start();
    }
}
