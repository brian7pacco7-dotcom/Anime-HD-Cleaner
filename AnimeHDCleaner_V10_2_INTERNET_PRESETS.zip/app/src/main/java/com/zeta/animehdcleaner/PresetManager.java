package com.zeta.animehdcleaner;

import java.util.HashMap;
import java.util.Map;

public class PresetManager {

    public static final String[] PRESETS = {
            "Anime HD",
            "Reparacion IA",
            "Color IA",
            "Quitar ruido",
            "Sombras limpias",
            "TikTok/Reels HD",
            "IA 4K+"
    };

    private static final Map<String, ExportSettings> onlinePresets = new HashMap<>();

    public static void setOnlinePreset(String name, ExportSettings settings) {
        ExportSettings copy = new ExportSettings();
        copySettings(settings, copy);
        onlinePresets.put(name, copy);
    }

    public static boolean hasOnlinePreset(String name) {
        return onlinePresets.containsKey(name);
    }

    public static int onlineCount() {
        return onlinePresets.size();
    }

    public static void clearOnlinePresets() {
        onlinePresets.clear();
    }

    public static void apply(String name, ExportSettings settings) {
        if (onlinePresets.containsKey(name)) {
            copySettings(onlinePresets.get(name), settings);
            settings.modeName = name;
            return;
        }

        settings.modeName = name;

        if ("Anime HD".equals(name)) {
            settings.sharpen = 7;
            settings.saturation = 9;
            settings.denoise = 7;
            settings.brightness = 4;
            settings.contrast = 4;
            settings.luminosity = 10;
        } else if ("Reparacion IA".equals(name)) {
            settings.sharpen = 6;
            settings.denoise = 9;
            settings.luminosity = 12;
            settings.contrast = 5;
        } else if ("Color IA".equals(name)) {
            settings.saturation = 12;
            settings.contrast = 8;
            settings.brightness = 6;
            settings.luminosity = 10;
        } else if ("Quitar ruido".equals(name)) {
            settings.denoise = 12;
            settings.sharpen = 5;
            settings.saturation = 8;
        } else if ("Sombras limpias".equals(name)) {
            settings.luminosity = 16;
            settings.denoise = 8;
            settings.contrast = 6;
        } else if ("TikTok/Reels HD".equals(name)) {
            settings.width = 1080;
            settings.height = 1920;
            settings.fps = 30;
            settings.bitrateMbps = 12;
            settings.qualityName = "1080P";
            settings.saturation = 10;
            settings.sharpen = 6;
            settings.contrast = 6;
        } else if ("IA 4K+".equals(name)) {
            settings.width = 2160;
            settings.height = 3840;
            settings.fps = 30;
            settings.bitrateMbps = 35;
            settings.qualityName = "4K";
            settings.sharpen = 8;
            settings.saturation = 10;
            settings.contrast = 6;
        }
    }

    private static void copySettings(ExportSettings src, ExportSettings dst) {
        dst.modeName = src.modeName;
        dst.qualityName = src.qualityName;
        dst.width = src.width;
        dst.height = src.height;
        dst.fps = src.fps;
        dst.bitrateMbps = src.bitrateMbps;
        dst.brightness = src.brightness;
        dst.contrast = src.contrast;
        dst.saturation = src.saturation;
        dst.luminosity = src.luminosity;
        dst.sharpen = src.sharpen;
        dst.denoise = src.denoise;
    }
}
