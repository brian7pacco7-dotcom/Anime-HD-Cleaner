# Anime HD Cleaner V7.0 FIXED REAL HD

Corregido: no hay strings rotos, la linea del comparador captura toques con capa transparente, los sliders estan arriba y los valores se muestran al instante. Mantiene motor HD real.
