
package com.zeta.animehdcleaner;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

public class FullscreenCompareActivity extends Activity {

    private ExoPlayer player;
    private FrameLayout preview;
    private PlayerView playerView;
    private View afterOverlay;
    private View touchLayer;
    private View divider;
    private TextView handle;
    private SeekBar compareSeek;
    private int compareProgress = 50;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String title = getIntent().getStringExtra("title");
        String subtitle = getIntent().getStringExtra("subtitle");
        String uriText = getIntent().getStringExtra("video_uri");
        compareProgress = getIntent().getIntExtra("compare_progress", 50);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(18,18,20));
        root.setPadding(dp(12), dp(18), dp(12), dp(18));

        TextView back = new TextView(this);
        back.setText("< Volver");
        back.setTextColor(Color.WHITE);
        back.setTextSize(18);
        back.setPadding(0, 0, 0, dp(8));
        back.setOnClickListener(v -> finish());
        root.addView(back);

        TextView t = new TextView(this);
        t.setText(title == null ? "Comparacion" : title);
        t.setTextColor(Color.WHITE);
        t.setTextSize(24);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setGravity(Gravity.CENTER);
        root.addView(t);

        TextView s = new TextView(this);
        s.setText(subtitle == null ? "Arrastra la linea central" : subtitle);
        s.setTextColor(Color.rgb(180,180,186));
        s.setTextSize(14);
        s.setGravity(Gravity.CENTER);
        s.setPadding(0, dp(6), 0, dp(10));
        root.addView(s);

        preview = new FrameLayout(this);
        preview.setBackgroundColor(Color.BLACK);
        root.addView(preview, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(560)));

        playerView = new PlayerView(this);
        playerView.setUseController(false);
        preview.addView(playerView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        afterOverlay = new View(this);
        afterOverlay.setBackgroundColor(Color.argb(48, 255, 255, 255));
        preview.addView(afterOverlay, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        touchLayer = new View(this);
        touchLayer.setBackgroundColor(Color.TRANSPARENT);
        preview.addView(touchLayer, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        View.OnTouchListener touch = (v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN || event.getAction() == MotionEvent.ACTION_MOVE) {
                updateCompareFromTouch(event.getX());
                return true;
            }
            return true;
        };
        touchLayer.setOnTouchListener(touch);
        preview.setOnTouchListener(touch);

        divider = new View(this);
        divider.setBackgroundColor(Color.WHITE);
        preview.addView(divider, new FrameLayout.LayoutParams(dp(3), FrameLayout.LayoutParams.MATCH_PARENT));
        divider.setOnTouchListener(touch);

        handle = new TextView(this);
        handle.setText("< >");
        handle.setGravity(Gravity.CENTER);
        handle.setTextColor(Color.DKGRAY);
        handle.setTypeface(Typeface.DEFAULT_BOLD);
        handle.setBackgroundColor(Color.argb(236, 255, 255, 255));
        preview.addView(handle, new FrameLayout.LayoutParams(dp(72), dp(72)));
        handle.setOnTouchListener(touch);

        preview.addView(label("Before", Gravity.BOTTOM | Gravity.LEFT));
        preview.addView(label("After", Gravity.BOTTOM | Gravity.RIGHT));

        compareSeek = new SeekBar(this);
        compareSeek.setMax(100);
        compareSeek.setProgress(compareProgress);
        compareSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                compareProgress = progress;
                updateCompare();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        root.addView(compareSeek);

        TextView tip = new TextView(this);
        tip.setText("Arrastra sobre el video o usa la barra de abajo");
        tip.setTextColor(Color.rgb(180,180,186));
        tip.setGravity(Gravity.CENTER);
        tip.setPadding(0, dp(4), 0, 0);
        root.addView(tip);

        setContentView(root);

        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        player.setRepeatMode(Player.REPEAT_MODE_ONE);

        if (uriText != null) {
            Uri uri = Uri.parse(uriText);
            player.setMediaItem(MediaItem.fromUri(uri));
            player.prepare();
            player.play();
        }

        preview.post(this::updateCompare);
    }

    private void updateCompareFromTouch(float touchX) {
        if (preview == null || preview.getWidth() == 0) return;
        int w = preview.getWidth();
        int p = Math.max(0, Math.min(100, Math.round((touchX / w) * 100f)));
        compareProgress = p;
        compareSeek.setProgress(p);
        updateCompare();
    }

    private void updateCompare() {
        if (preview == null || preview.getWidth() == 0) return;
        int w = preview.getWidth();
        int h = preview.getHeight();
        int x = (int)(w * (compareProgress / 100f));
        FrameLayout.LayoutParams overlayP = (FrameLayout.LayoutParams) afterOverlay.getLayoutParams();
        overlayP.width = Math.max(0, w - x);
        overlayP.height = h;
        overlayP.gravity = Gravity.RIGHT;
        afterOverlay.setLayoutParams(overlayP);
        FrameLayout.LayoutParams divP = (FrameLayout.LayoutParams) divider.getLayoutParams();
        divP.width = dp(3);
        divP.height = h;
        divP.leftMargin = Math.max(0, x - dp(1));
        divider.setLayoutParams(divP);
        FrameLayout.LayoutParams handleP = (FrameLayout.LayoutParams) handle.getLayoutParams();
        handleP.width = dp(72);
        handleP.height = dp(72);
        handleP.leftMargin = Math.max(0, Math.min(w - dp(72), x - dp(36)));
        handleP.topMargin = Math.max(0, h / 2 - dp(36));
        handle.setLayoutParams(handleP);
        touchLayer.bringToFront();
        divider.bringToFront();
        handle.bringToFront();
    }

    private TextView label(String text, int gravity) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(Color.WHITE);
        v.setTextSize(18);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, gravity);
        p.leftMargin = dp(16);
        p.rightMargin = dp(16);
        p.bottomMargin = dp(16);
        v.setLayoutParams(p);
        return v;
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override protected void onStop() { super.onStop(); if (player != null) player.pause(); }
    @Override protected void onDestroy() { super.onDestroy(); if (player != null) { player.release(); player = null; } }
}
