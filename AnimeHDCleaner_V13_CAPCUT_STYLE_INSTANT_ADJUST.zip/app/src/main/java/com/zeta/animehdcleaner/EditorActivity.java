package com.zeta.animehdcleaner;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.ui.PlayerView;

public class EditorActivity extends Activity {

    private static final int REQ_PICK_VIDEO = 1001;

    private Uri selectedVideo;
    private VideoPlayerManager playerManager;
    private MediaMetadataRetriever frameRetriever;

    private ExportSettings settings = new ExportSettings();

    private PlayerView playerView;
    private ImageView filteredFrameView;
    private FrameTimelineView timelineView;

    private TextView qualityButton;
    private TextView playButton;
    private TextView selectedAdjustText;
    private SeekBar mainAdjustSeek;
    private TextView adjustValueText;
    private LinearLayout adjustButtonsRow;
    private TextView fileText;

    private String selectedAdjust = "Saturacion";

    private final int bg = 0xFF090D12;
    private final int panel = 0xFF202124;
    private final int card = 0xFF151A22;
    private final int cyan = 0xFF13D7F2;
    private final int white = 0xFFFFFFFF;
    private final int muted = 0xFFB0B5BC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String uriText = getIntent().getStringExtra("video_uri");
        if (uriText != null) selectedVideo = Uri.parse(uriText);

        buildUi();

        if (selectedVideo != null) loadVideo(selectedVideo);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(8), dp(6), dp(8), dp(8));
        root.setBackgroundColor(bg);

        LinearLayout top = row();
        root.addView(top, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)));

        top.addView(topIcon("×"));
        top.addView(topIcon("?"));
        top.addView(topIcon("🔥"));

        View spacer = new View(this);
        top.addView(spacer, new LinearLayout.LayoutParams(0, 1, 1f));

        qualityButton = pill(settings.qualityName + " ▾", dp(112), dp(44));
        qualityButton.setOnClickListener(v -> chooseQuality());
        top.addView(qualityButton);

        Button exportButton = button("Exportar", cyan, 0xFF000000);
        LinearLayout.LayoutParams exp = new LinearLayout.LayoutParams(dp(118), dp(44));
        exp.leftMargin = dp(8);
        top.addView(exportButton, exp);
        exportButton.setOnClickListener(v -> openExport());

        FrameLayout preview = new FrameLayout(this);
        preview.setBackgroundColor(0xFF000000);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 2.6f);
        pp.topMargin = dp(4);
        root.addView(preview, pp);

        playerView = new PlayerView(this);
        playerView.setUseController(false);
        preview.addView(playerView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        filteredFrameView = new ImageView(this);
        filteredFrameView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        filteredFrameView.setBackgroundColor(0xFF000000);
        filteredFrameView.setVisibility(View.GONE);
        preview.addView(filteredFrameView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        playerManager = new VideoPlayerManager(this, playerView);

        LinearLayout previewTools = row();
        previewTools.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams ptp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42));
        ptp.topMargin = dp(4);
        root.addView(previewTools, ptp);

        previewTools.addView(controlIcon("□", () -> Toast.makeText(this, "Pantalla completa después de exportar", Toast.LENGTH_SHORT).show()));
        previewTools.addView(controlIcon("↶", () -> {
            if (playerManager != null) {
                hideFilteredPreview();
                playerManager.seekBy(-5000);
                updateTimeline();
            }
        }));
        playButton = controlIcon("▶", () -> togglePlay());
        previewTools.addView(playButton);
        previewTools.addView(controlIcon("↷", () -> {
            if (playerManager != null) {
                hideFilteredPreview();
                playerManager.seekBy(5000);
                updateTimeline();
            }
        }));
        previewTools.addView(controlIcon("↺", () -> resetFilters()));

        timelineView = new FrameTimelineView(this);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(94));
        tlp.topMargin = dp(2);
        root.addView(timelineView, tlp);

        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setPadding(dp(10), dp(8), dp(10), dp(8));
        bottom.setBackgroundColor(panel);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.65f);
        bp.topMargin = dp(6);
        root.addView(bottom, bp);

        LinearLayout tabs = row();
        bottom.addView(tabs, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36)));
        tabs.addView(tab("Predefinidos", false));
        tabs.addView(tab("Filtros", false));
        tabs.addView(tab("Ajustar", true));
        tabs.addView(tab("Calidad", false));

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        adjustButtonsRow = new LinearLayout(this);
        adjustButtonsRow.setOrientation(LinearLayout.HORIZONTAL);
        hsv.addView(adjustButtonsRow);
        bottom.addView(hsv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(82)));
        rebuildAdjustButtons();

        selectedAdjustText = text(selectedAdjust, 16, true, cyan);
        selectedAdjustText.setGravity(Gravity.CENTER);
        bottom.addView(selectedAdjustText, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(24)));

        mainAdjustSeek = new SeekBar(this);
        mainAdjustSeek.setMax(20);
        mainAdjustSeek.setProgress(getAdjustValue(selectedAdjust));
        bottom.addView(mainAdjustSeek, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)));

        LinearLayout bottomRow = row();
        bottom.addView(bottomRow, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)));

        TextView reset = text("↺ Restablecer", 16, false, white);
        reset.setGravity(Gravity.CENTER_VERTICAL);
        bottomRow.addView(reset, new LinearLayout.LayoutParams(0, dp(42), 1f));
        reset.setOnClickListener(v -> resetFilters());

        adjustValueText = text("Valor: " + getAdjustValue(selectedAdjust), 14, true, white);
        adjustValueText.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        bottomRow.addView(adjustValueText, new LinearLayout.LayoutParams(0, dp(42), 1f));

        mainAdjustSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                setAdjustValue(selectedAdjust, progress);
                adjustValueText.setText("Valor: " + progress);
                if (fromUser) updateFilteredPreviewNow();
            }

            @Override public void onStartTrackingTouch(SeekBar seekBar) {
                if (playerManager != null) playerManager.pause();
                playButton.setText("▶");
                updateFilteredPreviewNow();
            }

            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                updateFilteredPreviewNow();
            }
        });

        LinearLayout fileRow = row();
        root.addView(fileRow, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(30)));

        Button importButton = button("+ Importar", card, white);
        fileRow.addView(importButton, new LinearLayout.LayoutParams(dp(96), dp(30)));
        importButton.setOnClickListener(v -> pickVideo());

        fileText = text("Video: no cargado", 10, false, muted);
        fileText.setSingleLine(true);
        fileRow.addView(fileText, new LinearLayout.LayoutParams(0, dp(30), 1f));

        setContentView(root);
    }

    private void rebuildAdjustButtons() {
        adjustButtonsRow.removeAllViews();
        addAdjustButton("☀", "Brillo");
        addAdjustButton("◐", "Contraste");
        addAdjustButton("💧", "Saturacion");
        addAdjustButton("☼", "Luminosidad");
        addAdjustButton("△", "Enfocar");
        addAdjustButton("◌", "Ruido");
    }

    private void addAdjustButton(String icon, String name) {
        boolean active = selectedAdjust.equals(name);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(8), dp(4), dp(8), dp(4));

        TextView ic = text(icon, 27, false, active ? cyan : white);
        ic.setGravity(Gravity.CENTER);
        box.addView(ic, new LinearLayout.LayoutParams(dp(70), dp(42)));

        TextView label = text(name, 12, true, active ? cyan : white);
        label.setGravity(Gravity.CENTER);
        box.addView(label, new LinearLayout.LayoutParams(dp(86), dp(28)));

        box.setOnClickListener(v -> {
            selectedAdjust = name;
            selectedAdjustText.setText(name);
            mainAdjustSeek.setProgress(getAdjustValue(name));
            adjustValueText.setText("Valor: " + getAdjustValue(name));
            rebuildAdjustButtons();
            updateFilteredPreviewNow();
        });

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(92), dp(76));
        lp.rightMargin = dp(8);
        adjustButtonsRow.addView(box, lp);
    }

    private int getAdjustValue(String name) {
        if ("Brillo".equals(name)) return settings.brightness;
        if ("Contraste".equals(name)) return settings.contrast;
        if ("Saturacion".equals(name)) return settings.saturation;
        if ("Luminosidad".equals(name)) return settings.luminosity;
        if ("Enfocar".equals(name)) return settings.sharpen;
        if ("Ruido".equals(name)) return settings.denoise;
        return 10;
    }

    private void setAdjustValue(String name, int value) {
        if ("Brillo".equals(name)) settings.brightness = value;
        if ("Contraste".equals(name)) settings.contrast = value;
        if ("Saturacion".equals(name)) settings.saturation = value;
        if ("Luminosidad".equals(name)) settings.luminosity = value;
        if ("Enfocar".equals(name)) settings.sharpen = value;
        if ("Ruido".equals(name)) settings.denoise = value;
    }

    private void updateFilteredPreviewNow() {
        if (selectedVideo == null || frameRetriever == null || playerManager == null) return;

        try {
            long timeUs = Math.max(0, playerManager.getPosition() * 1000L);
            Bitmap frame = frameRetriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST);
            if (frame != null) {
                filteredFrameView.setImageBitmap(frame);
                filteredFrameView.setColorFilter(FilterMath.makeFilter(settings));
                filteredFrameView.setVisibility(View.VISIBLE);
                updateTimeline();
            }
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo mostrar vista previa", Toast.LENGTH_SHORT).show();
        }
    }

    private void hideFilteredPreview() {
        filteredFrameView.setVisibility(View.GONE);
    }

    private void resetFilters() {
        settings.brightness = 10;
        settings.contrast = 10;
        settings.saturation = 10;
        settings.luminosity = 10;
        settings.sharpen = 10;
        settings.denoise = 10;
        mainAdjustSeek.setProgress(getAdjustValue(selectedAdjust));
        adjustValueText.setText("Valor: " + getAdjustValue(selectedAdjust));
        updateFilteredPreviewNow();
    }

    private void togglePlay() {
        if (selectedVideo == null) {
            Toast.makeText(this, "Primero importa un video", Toast.LENGTH_SHORT).show();
            return;
        }
        hideFilteredPreview();
        playerManager.toggle();
        playButton.setText(playerManager.isPlaying() ? "⏸" : "▶");
        updateTimeline();
    }

    private void updateTimeline() {
        if (playerManager == null || timelineView == null) return;
        long d = playerManager.getDuration();
        long p = playerManager.getPosition();
        if (d > 0) timelineView.setProgress(p / (float)d);
    }

    private void chooseQuality() {
        String[] options = {"720P · 30 FPS · 8 Mbps", "1080P · 30 FPS · 12 Mbps", "1080P 60 · 60 FPS · 15 Mbps", "2K · 30 FPS · 20 Mbps", "4K · 30 FPS · 35 Mbps"};
        new AlertDialog.Builder(this)
                .setTitle("Calidad de salida")
                .setItems(options, (d, which) -> {
                    if (which == 0) setQuality("720P", 720, 1280, 30, 8);
                    if (which == 1) setQuality("1080P", 1080, 1920, 30, 12);
                    if (which == 2) setQuality("1080P 60", 1080, 1920, 60, 15);
                    if (which == 3) setQuality("2K", 1440, 2560, 30, 20);
                    if (which == 4) setQuality("4K", 2160, 3840, 30, 35);
                    qualityButton.setText(settings.qualityName + " ▾");
                }).show();
    }

    private void setQuality(String name, int width, int height, int fps, int bitrate) {
        settings.qualityName = name;
        settings.width = width;
        settings.height = height;
        settings.fps = fps;
        settings.bitrateMbps = bitrate;
    }

    private void openExport() {
        if (selectedVideo == null) {
            Toast.makeText(this, "Primero importa un video", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(this, ExportActivity.class);
        i.putExtra("video_uri", selectedVideo.toString());
        i.putExtra("settings", settings);
        startActivity(i);
    }

    private void pickVideo() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("video/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, REQ_PICK_VIDEO);
    }

    private void loadVideo(Uri uri) {
        selectedVideo = uri;

        if (frameRetriever != null) {
            try { frameRetriever.release(); } catch (Exception ignored) {}
        }
        frameRetriever = new MediaMetadataRetriever();

        try {
            frameRetriever.setDataSource(this, uri);
            Bitmap thumb = frameRetriever.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST);
            if (timelineView != null) timelineView.setThumbnail(thumb);
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo leer frames del video", Toast.LENGTH_LONG).show();
        }

        playerManager.load(uri);
        playerManager.play();
        playButton.setText("⏸");
        hideFilteredPreview();
        if (fileText != null) fileText.setText("Video: " + getFileName(uri));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PICK_VIDEO && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                try {
                    getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Exception ignored) {}
                loadVideo(uri);
            }
        }
    }

    private String getFileName(Uri uri) {
        String result = "video seleccionado";
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) result = cursor.getString(idx);
            }
        } catch (Exception ignored) {}
        return result;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        return r;
    }

    private TextView topIcon(String value) {
        TextView v = text(value, 28, false, white);
        v.setGravity(Gravity.CENTER);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(46), dp(46)));
        return v;
    }

    private TextView pill(String value, int width, int height) {
        TextView v = text(value, 15, true, white);
        v.setGravity(Gravity.CENTER);
        v.setBackgroundColor(card);
        v.setLayoutParams(new LinearLayout.LayoutParams(width, height));
        return v;
    }

    private TextView controlIcon(String value, Runnable action) {
        TextView v = text(value, 28, false, white);
        v.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(42), 1f);
        v.setLayoutParams(lp);
        v.setOnClickListener(x -> action.run());
        return v;
    }

    private TextView tab(String label, boolean active) {
        TextView t = text(label, 16, true, active ? white : muted);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, 0, 0, dp(4));
        if (active) t.setBackgroundColor(0xFF202A2D);
        t.setLayoutParams(new LinearLayout.LayoutParams(0, dp(36), 1f));
        return t;
    }

    private Button button(String label, int bg, int fg) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(fg);
        b.setBackgroundColor(bg);
        b.setAllCaps(false);
        b.setTextSize(13);
        return b;
    }

    private TextView text(String value, int size, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(color);
        t.setTextSize(size);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (playerManager != null) playerManager.pause();
        if (playButton != null) playButton.setText("▶");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (frameRetriever != null) {
            try { frameRetriever.release(); } catch (Exception ignored) {}
            frameRetriever = null;
        }
        if (playerManager != null) playerManager.release();
    }
}
