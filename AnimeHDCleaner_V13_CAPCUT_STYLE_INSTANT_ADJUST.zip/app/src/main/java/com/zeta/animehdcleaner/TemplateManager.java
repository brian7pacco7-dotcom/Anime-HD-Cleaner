package com.zeta.animehdcleaner;

public class TemplateManager {

    public static final String[] TEMPLATES = {
            "Reels Anime HD",
            "Anime Noche",
            "Sombras Limpias",
            "Color Viral",
            "WhatsApp HD",
            "Comparacion Antes/Despues"
    };

    public static void apply(String templateName, ExportSettings settings) {
        settings.modeName = templateName;

        if ("Reels Anime HD".equals(templateName)) {
            settings.qualityName = "1080P";
            settings.width = 1080;
            settings.height = 1920;
            settings.fps = 30;
            settings.bitrateMbps = 12;
            settings.brightness = 11;
            settings.contrast = 11;
            settings.saturation = 12;
            settings.luminosity = 10;
            settings.sharpen = 10;
            settings.denoise = 10;
        } else if ("Anime Noche".equals(templateName)) {
            settings.qualityName = "1080P";
            settings.width = 1080;
            settings.height = 1920;
            settings.fps = 30;
            settings.bitrateMbps = 13;
            settings.brightness = 12;
            settings.contrast = 10;
            settings.saturation = 10;
            settings.luminosity = 15;
            settings.sharpen = 10;
            settings.denoise = 10;
        } else if ("Sombras Limpias".equals(templateName)) {
            settings.qualityName = "1080P";
            settings.width = 1080;
            settings.height = 1920;
            settings.fps = 30;
            settings.bitrateMbps = 12;
            settings.brightness = 12;
            settings.contrast = 9;
            settings.saturation = 10;
            settings.luminosity = 16;
            settings.sharpen = 10;
            settings.denoise = 10;
        } else if ("Color Viral".equals(templateName)) {
            settings.qualityName = "1080P";
            settings.width = 1080;
            settings.height = 1920;
            settings.fps = 30;
            settings.bitrateMbps = 14;
            settings.brightness = 11;
            settings.contrast = 13;
            settings.saturation = 16;
            settings.luminosity = 11;
            settings.sharpen = 10;
            settings.denoise = 10;
        } else if ("WhatsApp HD".equals(templateName)) {
            settings.qualityName = "720P";
            settings.width = 720;
            settings.height = 1280;
            settings.fps = 30;
            settings.bitrateMbps = 7;
            settings.brightness = 10;
            settings.contrast = 10;
            settings.saturation = 10;
            settings.luminosity = 10;
            settings.sharpen = 10;
            settings.denoise = 10;
        } else if ("Comparacion Antes/Despues".equals(templateName)) {
            settings.qualityName = "1080P";
            settings.width = 1080;
            settings.height = 1920;
            settings.fps = 30;
            settings.bitrateMbps = 12;
            settings.brightness = 10;
            settings.contrast = 11;
            settings.saturation = 11;
            settings.luminosity = 10;
            settings.sharpen = 10;
            settings.denoise = 10;
        }
    }
}
