package com.zeta.animehdcleaner;

import android.content.Context;
import android.net.Uri;

public class LocalExporter {

    public interface Listener {
        void onProgress(int percent, String message);
        void onFinished(boolean success, Uri outputUri, String message);
    }

    public static void export(Context context, Uri inputUri, ExportSettings settings, Listener listener) {
        RealVideoProcessor.export(context, inputUri, settings, new RealVideoProcessor.Listener() {
            @Override
            public void onProgress(int percent, String message) {
                listener.onProgress(percent, message);
            }

            @Override
            public void onFinished(boolean success, Uri outputUri, String message) {
                listener.onFinished(success, outputUri, message);
            }
        });
    }
}
