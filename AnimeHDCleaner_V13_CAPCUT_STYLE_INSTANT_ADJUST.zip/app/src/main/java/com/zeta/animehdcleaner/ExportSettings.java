package com.zeta.animehdcleaner;

import java.io.Serializable;

public class ExportSettings implements Serializable {
    public String modeName = "Anime HD";
    public String qualityName = "720P";
    public int width = 720;
    public int height = 1280;
    public int fps = 30;
    public int bitrateMbps = 8;

    // Escala real: 10 = normal. 0 baja fuerte. 20 sube fuerte.
    public int brightness = 10;
    public int contrast = 10;
    public int saturation = 10;
    public int luminosity = 10;
    public int sharpen = 10;
    public int denoise = 10;

    public String summary() {
        return "Preset: " + modeName + "\n"
                + "Calidad: " + qualityName + "\n"
                + "Salida: " + width + "x" + height + " | " + fps + " FPS | " + bitrateMbps + " Mbps\n"
                + "Filtros reales: brillo " + brightness
                + ", contraste " + contrast
                + ", saturacion " + saturation
                + ", luz " + luminosity + "\n"
                + "Formato: MP4 H.264 | audio conservado si el video original tiene audio";
    }
}
