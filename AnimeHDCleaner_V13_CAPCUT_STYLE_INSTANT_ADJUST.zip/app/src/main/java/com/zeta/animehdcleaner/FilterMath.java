package com.zeta.animehdcleaner;

import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;

public class FilterMath {

    public static ColorMatrixColorFilter makeFilter(ExportSettings s) {
        float contrast = clamp(s.contrast / 10f, 0.05f, 2.5f);
        float saturation = clamp(s.saturation / 10f, 0f, 2.5f);
        float brightness = (s.brightness - 10) * 12.0f;
        float light = (s.luminosity - 10) * 8.0f;
        float translate = brightness + light + ((1f - contrast) * 128f);

        ColorMatrix sat = new ColorMatrix();
        sat.setSaturation(saturation);

        ColorMatrix con = new ColorMatrix(new float[]{
                contrast, 0, 0, 0, translate,
                0, contrast, 0, 0, translate,
                0, 0, contrast, 0, translate,
                0, 0, 0, 1, 0
        });

        sat.postConcat(con);
        return new ColorMatrixColorFilter(sat);
    }

    private static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }
}
