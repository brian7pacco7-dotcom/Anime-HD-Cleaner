package com.zeta.animehdcleaner;

public class PresetManager {

    public static final String[] PRESETS = {
            "Anime HD",
            "Reparacion IA",
            "Color IA",
            "Quitar ruido",
            "Sombras limpias",
            "TikTok/Reels HD",
            "IA 4K+"
    };

    public static void apply(String name, ExportSettings settings) {
        settings.modeName = name;

        if ("Anime HD".equals(name)) {
            settings.brightness = 11;
            settings.contrast = 11;
            settings.saturation = 12;
            settings.luminosity = 10;
            settings.sharpen = 10;
            settings.denoise = 10;
        } else if ("Reparacion IA".equals(name)) {
            settings.brightness = 11;
            settings.contrast = 10;
            settings.saturation = 11;
            settings.luminosity = 12;
            settings.sharpen = 10;
            settings.denoise = 10;
        } else if ("Color IA".equals(name)) {
            settings.brightness = 10;
            settings.contrast = 12;
            settings.saturation = 15;
            settings.luminosity = 11;
            settings.sharpen = 10;
            settings.denoise = 10;
        } else if ("Quitar ruido".equals(name)) {
            settings.brightness = 10;
            settings.contrast = 9;
            settings.saturation = 10;
            settings.luminosity = 10;
            settings.sharpen = 9;
            settings.denoise = 12;
        } else if ("Sombras limpias".equals(name)) {
            settings.brightness = 12;
            settings.contrast = 10;
            settings.saturation = 10;
            settings.luminosity = 15;
            settings.sharpen = 10;
            settings.denoise = 10;
        } else if ("TikTok/Reels HD".equals(name)) {
            settings.width = 1080;
            settings.height = 1920;
            settings.fps = 30;
            settings.bitrateMbps = 12;
            settings.qualityName = "1080P";
            settings.brightness = 11;
            settings.contrast = 12;
            settings.saturation = 13;
            settings.luminosity = 11;
            settings.sharpen = 10;
            settings.denoise = 10;
        } else if ("IA 4K+".equals(name)) {
            settings.width = 2160;
            settings.height = 3840;
            settings.fps = 30;
            settings.bitrateMbps = 35;
            settings.qualityName = "4K";
            settings.brightness = 10;
            settings.contrast = 11;
            settings.saturation = 12;
            settings.luminosity = 10;
            settings.sharpen = 10;
            settings.denoise = 10;
        }
    }
}
