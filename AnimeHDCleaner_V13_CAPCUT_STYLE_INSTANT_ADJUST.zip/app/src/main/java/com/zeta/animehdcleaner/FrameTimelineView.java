package com.zeta.animehdcleaner;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.View;

public class FrameTimelineView extends View {

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private Bitmap thumbnail;
    private float progress = 0.5f;

    public FrameTimelineView(Context context) {
        super(context);
        setMinimumHeight(dp(92));
    }

    public void setThumbnail(Bitmap bitmap) {
        thumbnail = bitmap;
        invalidate();
    }

    public void setProgress(float value) {
        progress = Math.max(0f, Math.min(1f, value));
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        paint.setColor(Color.rgb(18, 22, 28));
        canvas.drawRoundRect(0, 0, w, h, dp(10), dp(10), paint);

        int left = dp(48);
        int right = w - dp(52);
        int top = dp(18);
        int thumbH = dp(34);
        int blockW = dp(44);

        paint.setTextSize(dp(10));
        paint.setColor(Color.rgb(170, 176, 184));
        canvas.drawText("00:00", dp(8), dp(15), paint);
        canvas.drawText("00:16", w - dp(42), dp(15), paint);

        int x = left;
        while (x < right) {
            Rect dst = new Rect(x, top, Math.min(x + blockW, right), top + thumbH);
            if (thumbnail != null) {
                canvas.drawBitmap(thumbnail, null, dst, paint);
            } else {
                paint.setColor(Color.rgb(52, 66, 90));
                canvas.drawRect(dst, paint);
            }
            paint.setColor(Color.argb(90, 0, 0, 0));
            canvas.drawRect(dst.left, dst.top, dst.left + dp(1), dst.bottom, paint);
            x += blockW;
        }

        int waveTop = top + thumbH + dp(7);
        int waveBottom = h - dp(10);
        paint.setColor(Color.rgb(0, 165, 178));
        for (int wx = left; wx < right; wx += dp(4)) {
            int amp = (int)(Math.abs(Math.sin(wx * 0.065)) * Math.max(2, waveBottom - waveTop));
            canvas.drawLine(wx, waveBottom, wx, waveBottom - amp, paint);
        }

        float lineX = left + (right - left) * progress;
        paint.setColor(Color.WHITE);
        paint.setStrokeWidth(dp(2));
        canvas.drawLine(lineX, dp(8), lineX, h - dp(4), paint);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(2));
        paint.setColor(Color.WHITE);
        canvas.drawRoundRect(w - dp(44), top + dp(4), w - dp(8), top + dp(40), dp(7), dp(7), paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setTextSize(dp(25));
        canvas.drawText("+", w - dp(34), top + dp(31), paint);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
