# Anime HD Cleaner V13 CAPCUT STYLE INSTANT ADJUST

Cambios:
- Interfaz tipo CapCut: preview arriba, timeline, tabs y panel Ajustar abajo.
- Sin regla Antes/Después.
- Ajustes como CapCut: iconos arriba y un slider principal abajo.
- Al mover brillo/contraste/saturación/luminosidad se ve al instante en el frame actual.
- El video se pausa al mover el slider para ver el cambio.
- Play vuelve al video normal.
- Timeline muestra miniaturas reales usando un frame del video.
- Exporta con el motor real offline heredado de V11.

Uso:
1. Importa video.
2. Pausa o mueve un ajuste.
3. El cambio se muestra al toque en pantalla.
4. Exporta para aplicar al video completo.
