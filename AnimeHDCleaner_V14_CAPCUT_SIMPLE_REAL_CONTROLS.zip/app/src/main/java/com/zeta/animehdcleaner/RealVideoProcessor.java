package com.zeta.animehdcleaner;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.RectF;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Surface;

import java.io.File;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class RealVideoProcessor {

    public interface Listener {
        void onProgress(int percent, String message);
        void onFinished(boolean success, Uri outputUri, String message);
    }

    private static final String MIME_VIDEO = "video/avc";
    private static final long TIMEOUT_US = 10000;

    public static void export(Context context, Uri inputUri, ExportSettings settings, Listener listener) {
        new Thread(() -> {
            MediaMetadataRetriever retriever = new MediaMetadataRetriever();
            MediaExtractor audioExtractor = null;
            MediaCodec encoder = null;
            MediaMuxer muxer = null;
            Surface inputSurface = null;

            try {
                listener.onProgress(1, "Leyendo video...");

                VideoInfo info = VideoInfo.read(context, inputUri);
                long durationUs = info.durationMs > 0 ? info.durationMs * 1000L : 10_000_000L;
                int originalW = info.width > 0 ? info.width : 720;
                int originalH = info.height > 0 ? info.height : 720;
                int outW = makeEven(settings.width > 0 ? settings.width : originalW);
                int outH = makeEven(settings.height > 0 ? settings.height : originalH);
                int fps = Math.max(1, Math.min(60, settings.fps));
                int frameCount = Math.max(1, (int)Math.ceil((durationUs / 1_000_000.0) * fps));

                retriever.setDataSource(context, inputUri);

                String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
                String displayName = "anime_hd_cleaner_real_" + stamp + ".mp4";

                File tempFile = new File(context.getCacheDir(), displayName);
                if (tempFile.exists()) tempFile.delete();

                muxer = new MediaMuxer(tempFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);

                audioExtractor = new MediaExtractor();
                audioExtractor.setDataSource(context, inputUri, null);
                int audioSourceTrack = selectAudioTrack(audioExtractor);
                int audioMuxerTrack = -1;
                if (audioSourceTrack >= 0) {
                    audioExtractor.selectTrack(audioSourceTrack);
                    MediaFormat audioFormat = audioExtractor.getTrackFormat(audioSourceTrack);
                    audioMuxerTrack = muxer.addTrack(audioFormat);
                }

                MediaFormat format = MediaFormat.createVideoFormat(MIME_VIDEO, outW, outH);
                format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
                format.setInteger(MediaFormat.KEY_BIT_RATE, Math.max(1, settings.bitrateMbps) * 1000 * 1000);
                format.setInteger(MediaFormat.KEY_FRAME_RATE, fps);
                format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);

                encoder = MediaCodec.createEncoderByType(MIME_VIDEO);
                encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
                inputSurface = encoder.createInputSurface();
                encoder.start();

                Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
                paint.setColorFilter(FilterMath.makeFilter(settings));

                MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();
                MuxState state = new MuxState();
                state.muxer = muxer;
                state.audioMuxerTrack = audioMuxerTrack;

                drainEncoder(encoder, bufferInfo, state, false);

                listener.onProgress(3, "Procesando filtros reales...");

                for (int i = 0; i < frameCount; i++) {
                    long timeUs = Math.min(durationUs - 1, (i * 1_000_000L) / fps);
                    Bitmap frame = retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST);

                    Canvas canvas = inputSurface.lockCanvas(null);
                    try {
                        canvas.drawColor(Color.BLACK);
                        if (frame != null) {
                            RectF dst = centerCropRect(frame.getWidth(), frame.getHeight(), outW, outH);
                            canvas.drawBitmap(frame, null, dst, paint);
                        }
                    } finally {
                        inputSurface.unlockCanvasAndPost(canvas);
                    }

                    if (frame != null) frame.recycle();

                    drainEncoder(encoder, bufferInfo, state, false);

                    int percent = 5 + (int)((i + 1) * 78L / frameCount);
                    listener.onProgress(percent, "Aplicando filtros reales " + percent + "%");
                }

                encoder.signalEndOfInputStream();
                drainEncoder(encoder, bufferInfo, state, true);

                if (audioMuxerTrack >= 0 && state.muxerStarted) {
                    listener.onProgress(86, "Conservando audio...");
                    copyAudio(audioExtractor, audioMuxerTrack, muxer);
                }

                try {
                    muxer.stop();
                } catch (Exception ignored) {
                }

                listener.onProgress(94, "Guardando en galeria...");
                Uri outputUri = saveToGallery(context, tempFile, displayName);

                listener.onProgress(100, "Listo");
                listener.onFinished(true, outputUri, "Video procesado y guardado");

            } catch (Exception e) {
                listener.onFinished(false, null, "Error motor real: " + e.getMessage());
            } finally {
                try { retriever.release(); } catch (Exception ignored) {}
                try { if (audioExtractor != null) audioExtractor.release(); } catch (Exception ignored) {}
                try { if (inputSurface != null) inputSurface.release(); } catch (Exception ignored) {}
                try { if (encoder != null) { encoder.stop(); encoder.release(); } } catch (Exception ignored) {}
                try { if (muxer != null) muxer.release(); } catch (Exception ignored) {}
            }
        }).start();
    }

    private static class MuxState {
        MediaMuxer muxer;
        boolean muxerStarted = false;
        int videoTrack = -1;
        int audioMuxerTrack = -1;
    }

    private static void drainEncoder(MediaCodec encoder, MediaCodec.BufferInfo info, MuxState state, boolean endOfStream) {
        while (true) {
            int status = encoder.dequeueOutputBuffer(info, TIMEOUT_US);

            if (status == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!endOfStream) break;
            } else if (status == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                if (state.muxerStarted) {
                    throw new RuntimeException("Formato cambio dos veces");
                }
                MediaFormat newFormat = encoder.getOutputFormat();
                state.videoTrack = state.muxer.addTrack(newFormat);
                state.muxer.start();
                state.muxerStarted = true;
            } else if (status >= 0) {
                ByteBuffer encodedData = encoder.getOutputBuffer(status);
                if (encodedData == null) {
                    throw new RuntimeException("Buffer de encoder nulo");
                }

                if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                    info.size = 0;
                }

                if (info.size != 0 && state.muxerStarted) {
                    encodedData.position(info.offset);
                    encodedData.limit(info.offset + info.size);
                    state.muxer.writeSampleData(state.videoTrack, encodedData, info);
                }

                boolean eos = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
                encoder.releaseOutputBuffer(status, false);

                if (eos) break;
            }
        }
    }

    private static int selectAudioTrack(MediaExtractor extractor) {
        for (int i = 0; i < extractor.getTrackCount(); i++) {
            MediaFormat format = extractor.getTrackFormat(i);
            String mime = format.getString(MediaFormat.KEY_MIME);
            if (mime != null && mime.startsWith("audio/")) {
                return i;
            }
        }
        return -1;
    }

    private static void copyAudio(MediaExtractor extractor, int muxerTrack, MediaMuxer muxer) {
        MediaCodec.BufferInfo audioInfo = new MediaCodec.BufferInfo();
        ByteBuffer buffer = ByteBuffer.allocate(1024 * 1024);

        while (true) {
            buffer.clear();
            int sampleSize = extractor.readSampleData(buffer, 0);
            if (sampleSize < 0) break;

            audioInfo.set(0, sampleSize, extractor.getSampleTime(), extractor.getSampleFlags());
            muxer.writeSampleData(muxerTrack, buffer, audioInfo);
            extractor.advance();
        }
    }

    private static Uri saveToGallery(Context context, File tempFile, String displayName) throws Exception {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Video.Media.DISPLAY_NAME, displayName);
        values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/AnimeHDCleaner");

        ContentResolver resolver = context.getContentResolver();
        Uri outputUri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
        if (outputUri == null) {
            throw new RuntimeException("No se pudo crear archivo final");
        }

        try (java.io.InputStream in = new java.io.FileInputStream(tempFile);
             java.io.OutputStream out = resolver.openOutputStream(outputUri)) {
            if (out == null) throw new RuntimeException("No se pudo abrir salida");
            byte[] buf = new byte[1024 * 1024];
            int r;
            while ((r = in.read(buf)) != -1) {
                out.write(buf, 0, r);
            }
            out.flush();
        }

        try { tempFile.delete(); } catch (Exception ignored) {}
        return outputUri;
    }

    private static ColorMatrixColorFilter makeColorFilter(ExportSettings s) {
        float contrast = clamp(s.contrast / 10f, 0.05f, 2.5f);
        float saturation = clamp(s.saturation / 10f, 0f, 2.5f);
        float brightness = (s.brightness - 10) * 12.0f;
        float light = (s.luminosity - 10) * 8.0f;
        float translate = brightness + light + ((1f - contrast) * 128f);

        ColorMatrix sat = new ColorMatrix();
        sat.setSaturation(saturation);

        ColorMatrix con = new ColorMatrix(new float[]{
                contrast, 0, 0, 0, translate,
                0, contrast, 0, 0, translate,
                0, 0, contrast, 0, translate,
                0, 0, 0, 1, 0
        });

        sat.postConcat(con);
        return new ColorMatrixColorFilter(sat);
    }

    private static RectF centerCropRect(int srcW, int srcH, int dstW, int dstH) {
        float srcRatio = srcW / (float) srcH;
        float dstRatio = dstW / (float) dstH;
        float drawW;
        float drawH;

        if (srcRatio > dstRatio) {
            drawH = dstH;
            drawW = dstH * srcRatio;
        } else {
            drawW = dstW;
            drawH = dstW / srcRatio;
        }

        float left = (dstW - drawW) / 2f;
        float top = (dstH - drawH) / 2f;
        return new RectF(left, top, left + drawW, top + drawH);
    }

    private static int makeEven(int value) {
        if (value < 2) return 2;
        return value % 2 == 0 ? value : value - 1;
    }

    private static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }
}
