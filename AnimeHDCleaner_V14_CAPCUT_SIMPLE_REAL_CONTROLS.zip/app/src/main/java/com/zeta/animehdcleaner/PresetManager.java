package com.zeta.animehdcleaner;

public class PresetManager {

    public static final String[] PRESETS = {
            "Normal",
            "Anime claro",
            "Anime oscuro",
            "Color fuerte",
            "Sombras suaves",
            "Suave"
    };

    public static void apply(String name, ExportSettings s) {
        s.modeName = name;

        if ("Normal".equals(name)) {
            s.brightness = 10; s.contrast = 10; s.saturation = 10; s.luminosity = 10;
        } else if ("Anime claro".equals(name)) {
            s.brightness = 12; s.contrast = 11; s.saturation = 12; s.luminosity = 12;
        } else if ("Anime oscuro".equals(name)) {
            s.brightness = 9; s.contrast = 13; s.saturation = 11; s.luminosity = 8;
        } else if ("Color fuerte".equals(name)) {
            s.brightness = 10; s.contrast = 13; s.saturation = 16; s.luminosity = 10;
        } else if ("Sombras suaves".equals(name)) {
            s.brightness = 12; s.contrast = 9; s.saturation = 10; s.luminosity = 16;
        } else if ("Suave".equals(name)) {
            s.brightness = 10; s.contrast = 9; s.saturation = 9; s.luminosity = 11;
        }
    }
}
