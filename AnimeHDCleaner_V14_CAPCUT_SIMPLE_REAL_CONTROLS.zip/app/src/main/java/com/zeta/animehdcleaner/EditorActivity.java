package com.zeta.animehdcleaner;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.ui.PlayerView;

public class EditorActivity extends Activity {

    private static final int REQ_PICK_VIDEO = 1001;

    private Uri selectedVideo;
    private VideoPlayerManager playerManager;
    private MediaMetadataRetriever frameRetriever;
    private VideoInfo currentInfo;

    private ExportSettings settings = new ExportSettings();

    private PlayerView playerView;
    private ImageView filteredFrameView;

    private TextView qualityButton;
    private TextView playButton;
    private TextView panelTitle;
    private TextView valueText;
    private SeekBar mainSeek;
    private LinearLayout panelContent;
    private TextView fileText;

    private String currentTab = "Ajustar";
    private String selectedAdjust = "Saturacion";

    private final int bg = 0xFF090D12;
    private final int panel = 0xFF202124;
    private final int card = 0xFF151A22;
    private final int cyan = 0xFF13D7F2;
    private final int white = 0xFFFFFFFF;
    private final int muted = 0xFFB0B5BC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String uriText = getIntent().getStringExtra("video_uri");
        if (uriText != null) selectedVideo = Uri.parse(uriText);
        buildUi();
        if (selectedVideo != null) loadVideo(selectedVideo);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(8), dp(6), dp(8), dp(8));
        root.setBackgroundColor(bg);

        LinearLayout top = row();
        root.addView(top, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)));

        top.addView(topIcon("×"));
        top.addView(topIcon("?"));
        top.addView(topIcon("🔥"));

        View spacer = new View(this);
        top.addView(spacer, new LinearLayout.LayoutParams(0, 1, 1f));

        qualityButton = pill(settings.qualityName + " ▾", dp(116), dp(44));
        qualityButton.setOnClickListener(v -> chooseQuality());
        top.addView(qualityButton);

        Button exportButton = button("Exportar", cyan, 0xFF000000);
        LinearLayout.LayoutParams exp = new LinearLayout.LayoutParams(dp(118), dp(44));
        exp.leftMargin = dp(8);
        top.addView(exportButton, exp);
        exportButton.setOnClickListener(v -> openExport());

        FrameLayout preview = new FrameLayout(this);
        preview.setBackgroundColor(0xFF000000);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 2.85f);
        pp.topMargin = dp(4);
        root.addView(preview, pp);

        playerView = new PlayerView(this);
        playerView.setUseController(false);
        preview.addView(playerView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        filteredFrameView = new ImageView(this);
        filteredFrameView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        filteredFrameView.setBackgroundColor(0xFF000000);
        filteredFrameView.setVisibility(View.GONE);
        preview.addView(filteredFrameView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        playerManager = new VideoPlayerManager(this, playerView);

        LinearLayout controls = row();
        controls.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46));
        cp.topMargin = dp(4);
        root.addView(controls, cp);

        controls.addView(controlIcon("□", () -> Toast.makeText(this, "Pantalla completa después de exportar", Toast.LENGTH_SHORT).show()));
        controls.addView(controlIcon("↶", () -> { hideFilteredPreview(); if (playerManager != null) playerManager.seekBy(-5000); }));
        playButton = controlIcon("▶", () -> togglePlay());
        controls.addView(playButton);
        controls.addView(controlIcon("↷", () -> { hideFilteredPreview(); if (playerManager != null) playerManager.seekBy(5000); }));
        controls.addView(controlIcon("↺", () -> resetFilters()));

        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setPadding(dp(10), dp(8), dp(10), dp(8));
        bottom.setBackgroundColor(panel);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.55f);
        bp.topMargin = dp(6);
        root.addView(bottom, bp);

        LinearLayout tabs = row();
        bottom.addView(tabs, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38)));
        tabs.addView(tab("Predefinidos"));
        tabs.addView(tab("Filtros"));
        tabs.addView(tab("Ajustar"));
        tabs.addView(tab("Calidad"));

        panelTitle = text("", 18, true, cyan);
        panelTitle.setGravity(Gravity.CENTER);
        bottom.addView(panelTitle, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(30)));

        panelContent = new LinearLayout(this);
        panelContent.setOrientation(LinearLayout.VERTICAL);
        bottom.addView(panelContent, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout fileRow = row();
        root.addView(fileRow, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(32)));

        Button importButton = button("+ Importar", card, white);
        fileRow.addView(importButton, new LinearLayout.LayoutParams(dp(104), dp(32)));
        importButton.setOnClickListener(v -> pickVideo());

        fileText = text("Video: no cargado", 10, false, muted);
        fileText.setSingleLine(true);
        fileRow.addView(fileText, new LinearLayout.LayoutParams(0, dp(32), 1f));

        renderPanel();
        setContentView(root);
    }

    private void renderPanel() {
        panelContent.removeAllViews();

        if ("Ajustar".equals(currentTab)) {
            renderAdjustPanel();
        } else if ("Predefinidos".equals(currentTab)) {
            renderPresetPanel();
        } else if ("Filtros".equals(currentTab)) {
            renderFilterPanel();
        } else if ("Calidad".equals(currentTab)) {
            renderQualityPanel();
        }
    }

    private void renderAdjustPanel() {
        panelTitle.setText(selectedAdjust);

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        hsv.addView(row);
        panelContent.addView(hsv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(84)));

        addAdjustButton(row, "☀", "Brillo");
        addAdjustButton(row, "◐", "Contraste");
        addAdjustButton(row, "💧", "Saturacion");
        addAdjustButton(row, "☼", "Luminosidad");

        mainSeek = new SeekBar(this);
        mainSeek.setMax(20);
        mainSeek.setProgress(getAdjustValue(selectedAdjust));
        panelContent.addView(mainSeek, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));

        LinearLayout bottomRow = row();
        panelContent.addView(bottomRow, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));

        TextView reset = text("↺ Restablecer", 16, false, white);
        reset.setGravity(Gravity.CENTER_VERTICAL);
        bottomRow.addView(reset, new LinearLayout.LayoutParams(0, dp(44), 1f));
        reset.setOnClickListener(v -> resetFilters());

        valueText = text("Valor: " + getAdjustValue(selectedAdjust), 14, true, white);
        valueText.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        bottomRow.addView(valueText, new LinearLayout.LayoutParams(0, dp(44), 1f));

        mainSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                setAdjustValue(selectedAdjust, progress);
                if (valueText != null) valueText.setText("Valor: " + progress);
                if (fromUser) updateFilteredPreviewNow();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {
                pauseForPreview();
            }
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                updateFilteredPreviewNow();
            }
        });
    }

    private void renderPresetPanel() {
        panelTitle.setText("Predefinidos");
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        hsv.addView(row);
        panelContent.addView(hsv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(104)));

        for (String p : PresetManager.PRESETS) {
            TextView b = tile(p, settings.modeName.equals(p));
            b.setOnClickListener(v -> {
                PresetManager.apply(p, settings);
                updateFilteredPreviewNow();
                renderPanel();
            });
            row.addView(b);
        }

        TextView note = text("Toca un preset: se ve al instante y se guarda para exportar.", 13, false, muted);
        note.setGravity(Gravity.CENTER);
        panelContent.addView(note, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)));
    }

    private void renderFilterPanel() {
        panelTitle.setText("Filtros");
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        hsv.addView(row);
        panelContent.addView(hsv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(104)));

        addFilterTile(row, "Vivo", 10, 13, 16, 10);
        addFilterTile(row, "Frio", 9, 11, 12, 9);
        addFilterTile(row, "Claro", 13, 10, 11, 14);
        addFilterTile(row, "Oscuro", 8, 13, 11, 8);
        addFilterTile(row, "Suave", 10, 9, 9, 11);

        TextView note = text("Filtros reales: modifican brillo, contraste, saturación y luz.", 13, false, muted);
        note.setGravity(Gravity.CENTER);
        panelContent.addView(note, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)));
    }

    private void renderQualityPanel() {
        panelTitle.setText("Calidad de salida");
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        hsv.addView(row);
        panelContent.addView(hsv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(104)));

        addQualityTile(row, "Original", 0, 0, 24, 8);
        addQualityTile(row, "720P", 720, 1280, 24, 8);
        addQualityTile(row, "1080P", 1080, 1920, 24, 12);
        addQualityTile(row, "1080P 60", 1080, 1920, 60, 15);

        TextView note = text("Para ir rápido usa Original. 1080P/60 demora más.", 13, false, muted);
        note.setGravity(Gravity.CENTER);
        panelContent.addView(note, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)));
    }

    private void addAdjustButton(LinearLayout row, String icon, String name) {
        boolean active = selectedAdjust.equals(name);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(8), dp(4), dp(8), dp(4));

        TextView ic = text(icon, 28, false, active ? cyan : white);
        ic.setGravity(Gravity.CENTER);
        box.addView(ic, new LinearLayout.LayoutParams(dp(78), dp(42)));

        TextView label = text(name, 12, true, active ? cyan : white);
        label.setGravity(Gravity.CENTER);
        box.addView(label, new LinearLayout.LayoutParams(dp(92), dp(28)));

        box.setOnClickListener(v -> {
            selectedAdjust = name;
            renderPanel();
            updateFilteredPreviewNow();
        });

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(98), dp(78));
        lp.rightMargin = dp(8);
        row.addView(box, lp);
    }

    private void addFilterTile(LinearLayout row, String name, int b, int c, int s, int l) {
        TextView t = tile(name, false);
        t.setOnClickListener(v -> {
            settings.modeName = "Filtro " + name;
            settings.brightness = b;
            settings.contrast = c;
            settings.saturation = s;
            settings.luminosity = l;
            updateFilteredPreviewNow();
            renderPanel();
        });
        row.addView(t);
    }

    private void addQualityTile(LinearLayout row, String name, int w, int h, int fps, int bitrate) {
        boolean active = settings.qualityName.equals(name);
        TextView t = tile(name + "\n" + fps + " FPS\n" + bitrate + " Mbps", active);
        t.setOnClickListener(v -> {
            setQuality(name, w, h, fps, bitrate);
            qualityButton.setText(settings.qualityName + " ▾");
            renderPanel();
        });
        row.addView(t);
    }

    private TextView tile(String label, boolean active) {
        TextView t = text(label, 13, true, active ? cyan : white);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(8), dp(6), dp(8), dp(6));
        t.setBackgroundColor(active ? 0xFF26363A : card);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(132), dp(88));
        lp.rightMargin = dp(10);
        t.setLayoutParams(lp);
        return t;
    }

    private int getAdjustValue(String name) {
        if ("Brillo".equals(name)) return settings.brightness;
        if ("Contraste".equals(name)) return settings.contrast;
        if ("Saturacion".equals(name)) return settings.saturation;
        if ("Luminosidad".equals(name)) return settings.luminosity;
        return 10;
    }

    private void setAdjustValue(String name, int value) {
        if ("Brillo".equals(name)) settings.brightness = value;
        if ("Contraste".equals(name)) settings.contrast = value;
        if ("Saturacion".equals(name)) settings.saturation = value;
        if ("Luminosidad".equals(name)) settings.luminosity = value;
    }

    private void updateFilteredPreviewNow() {
        if (selectedVideo == null || frameRetriever == null || playerManager == null) return;

        try {
            long timeUs = Math.max(0, playerManager.getPosition() * 1000L);
            Bitmap frame = frameRetriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST);
            if (frame != null) {
                filteredFrameView.setImageBitmap(frame);
                filteredFrameView.setColorFilter(FilterMath.makeFilter(settings));
                filteredFrameView.setVisibility(View.VISIBLE);
            }
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo mostrar vista previa", Toast.LENGTH_SHORT).show();
        }
    }

    private void pauseForPreview() {
        if (playerManager != null) playerManager.pause();
        if (playButton != null) playButton.setText("▶");
        updateFilteredPreviewNow();
    }

    private void hideFilteredPreview() {
        filteredFrameView.setVisibility(View.GONE);
    }

    private void resetFilters() {
        settings.brightness = 10;
        settings.contrast = 10;
        settings.saturation = 10;
        settings.luminosity = 10;
        if (mainSeek != null) mainSeek.setProgress(getAdjustValue(selectedAdjust));
        updateFilteredPreviewNow();
        renderPanel();
    }

    private void togglePlay() {
        if (selectedVideo == null) {
            Toast.makeText(this, "Primero importa un video", Toast.LENGTH_SHORT).show();
            return;
        }
        hideFilteredPreview();
        playerManager.toggle();
        playButton.setText(playerManager.isPlaying() ? "⏸" : "▶");
    }

    private void chooseQuality() {
        currentTab = "Calidad";
        renderPanel();
    }

    private void setQuality(String name, int width, int height, int fps, int bitrate) {
        settings.qualityName = name;
        settings.width = width;
        settings.height = height;
        settings.fps = fps;
        settings.bitrateMbps = bitrate;
    }

    private void openExport() {
        if (selectedVideo == null) {
            Toast.makeText(this, "Primero importa un video", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(this, ExportActivity.class);
        i.putExtra("video_uri", selectedVideo.toString());
        i.putExtra("settings", settings);
        startActivity(i);
    }

    private void pickVideo() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("video/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, REQ_PICK_VIDEO);
    }

    private void loadVideo(Uri uri) {
        selectedVideo = uri;
        currentInfo = VideoInfo.read(this, uri);

        if (frameRetriever != null) {
            try { frameRetriever.release(); } catch (Exception ignored) {}
        }
        frameRetriever = new MediaMetadataRetriever();

        try {
            frameRetriever.setDataSource(this, uri);
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo leer frames del video", Toast.LENGTH_LONG).show();
        }

        playerManager.load(uri);
        playerManager.play();
        playButton.setText("⏸");
        hideFilteredPreview();

        if (fileText != null) {
            fileText.setText("Video: " + getFileName(uri) + " · " + (currentInfo == null ? "" : currentInfo.resolutionText()));
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PICK_VIDEO && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                try {
                    getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Exception ignored) {}
                loadVideo(uri);
            }
        }
    }

    private String getFileName(Uri uri) {
        String result = "video seleccionado";
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) result = cursor.getString(idx);
            }
        } catch (Exception ignored) {}
        return result;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        return r;
    }

    private TextView topIcon(String value) {
        TextView v = text(value, 28, false, white);
        v.setGravity(Gravity.CENTER);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(46), dp(46)));
        return v;
    }

    private TextView pill(String value, int width, int height) {
        TextView v = text(value, 15, true, white);
        v.setGravity(Gravity.CENTER);
        v.setBackgroundColor(card);
        v.setLayoutParams(new LinearLayout.LayoutParams(width, height));
        return v;
    }

    private TextView controlIcon(String value, Runnable action) {
        TextView v = text(value, 28, false, white);
        v.setGravity(Gravity.CENTER);
        v.setLayoutParams(new LinearLayout.LayoutParams(0, dp(44), 1f));
        v.setOnClickListener(x -> action.run());
        return v;
    }

    private TextView tab(String label) {
        boolean active = currentTab.equals(label);
        TextView t = text(label, 16, true, active ? white : muted);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, 0, 0, dp(4));
        t.setBackgroundColor(active ? 0xFF202A2D : panel);
        t.setLayoutParams(new LinearLayout.LayoutParams(0, dp(38), 1f));
        t.setOnClickListener(v -> {
            currentTab = label;
            renderPanel();
        });
        return t;
    }

    private Button button(String label, int bg, int fg) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(fg);
        b.setBackgroundColor(bg);
        b.setAllCaps(false);
        b.setTextSize(13);
        return b;
    }

    private TextView text(String value, int size, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(color);
        t.setTextSize(size);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (playerManager != null) playerManager.pause();
        if (playButton != null) playButton.setText("▶");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (frameRetriever != null) {
            try { frameRetriever.release(); } catch (Exception ignored) {}
            frameRetriever = null;
        }
        if (playerManager != null) playerManager.release();
    }
}
