package com.zeta.animehdcleaner;

import java.io.Serializable;

public class ExportSettings implements Serializable {
    public String modeName = "Normal";
    public String qualityName = "Original";

    // 0 = mantener tamaño original
    public int width = 0;
    public int height = 0;

    public int fps = 24;
    public int bitrateMbps = 8;

    // Escala real: 10 = normal. 0 baja fuerte. 20 sube fuerte.
    public int brightness = 10;
    public int contrast = 10;
    public int saturation = 10;
    public int luminosity = 10;

    // Reservados para después. No se muestran en V14.
    public int sharpen = 10;
    public int denoise = 10;

    public String resolutionText() {
        if (width <= 0 || height <= 0) return "Original";
        return width + "x" + height;
    }

    public String summary() {
        return "Modo: " + modeName + "\n"
                + "Calidad: " + qualityName + "\n"
                + "Salida: " + resolutionText() + " | " + fps + " FPS | " + bitrateMbps + " Mbps\n"
                + "Filtros reales: brillo " + brightness
                + ", contraste " + contrast
                + ", saturacion " + saturation
                + ", luz " + luminosity + "\n"
                + "Formato: MP4 H.264";
    }
}
