package com.zeta.animehdcleaner;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class ExportActivity extends Activity {

    private Uri videoUri;
    private Uri lastOutputUri;
    private ExportSettings settings;
    private ProgressBar progressBar;
    private TextView percent;
    private TextView state;
    private TextView details;
    private VideoInfo videoInfo;

    private final int bg = 0xFF090D12;
    private final int cyan = 0xFF11D2FF;
    private final int white = 0xFFFFFFFF;
    private final int panel = 0xFF12181F;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String uriText = getIntent().getStringExtra("video_uri");
        if (uriText != null) videoUri = Uri.parse(uriText);

        Object obj = getIntent().getSerializableExtra("settings");
        if (obj instanceof ExportSettings) {
            settings = (ExportSettings) obj;
        } else {
            settings = new ExportSettings();
        }

        if (videoUri != null) {
            videoInfo = VideoInfo.read(this, videoUri);
        } else {
            videoInfo = new VideoInfo();
        }

        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(28), dp(18), dp(18));
        root.setBackgroundColor(bg);

        TextView title = text("Exportacion PRO", 25, true);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.HORIZONTAL);
        tools.setPadding(0, dp(12), 0, dp(8));
        root.addView(tools);

        Button quality = button("Calidad", cyan, 0xFF000000);
        tools.addView(quality, new LinearLayout.LayoutParams(0, dp(46), 1f));
        quality.setOnClickListener(v -> chooseQuality());

        Button bitrate = button("Bitrate", panel, white);
        tools.addView(bitrate, new LinearLayout.LayoutParams(0, dp(46), 1f));
        bitrate.setOnClickListener(v -> chooseBitrate());

        Button fps = button("FPS", panel, white);
        tools.addView(fps, new LinearLayout.LayoutParams(0, dp(46), 1f));
        fps.setOnClickListener(v -> chooseFps());

        details = text(buildDetails(), 14, false);
        details.setPadding(0, dp(8), 0, dp(12));
        root.addView(details, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        root.addView(progressBar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        percent = text("0%", 22, true);
        percent.setGravity(Gravity.CENTER);
        percent.setPadding(0, dp(10), 0, dp(6));
        root.addView(percent);

        state = text("Listo para exportar", 14, false);
        state.setGravity(Gravity.CENTER);
        root.addView(state);

        Button start = button("Exportar ahora", cyan, 0xFF000000);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54));
        sp.topMargin = dp(12);
        root.addView(start, sp);
        start.setOnClickListener(v -> startExport());

        LinearLayout post = new LinearLayout(this);
        post.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46));
        pp.topMargin = dp(8);
        root.addView(post, pp);

        Button open = button("Abrir", panel, white);
        post.addView(open, new LinearLayout.LayoutParams(0, dp(46), 1f));
        open.setOnClickListener(v -> openLastVideo());

        Button share = button("Compartir", panel, white);
        post.addView(share, new LinearLayout.LayoutParams(0, dp(46), 1f));
        share.setOnClickListener(v -> shareLastVideo());

        Button history = button("Historial", panel, white);
        post.addView(history, new LinearLayout.LayoutParams(0, dp(46), 1f));
        history.setOnClickListener(v -> startActivity(new Intent(this, HistoryActivity.class)));

        Button close = button("Volver", panel, white);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        cp.topMargin = dp(8);
        root.addView(close, cp);
        close.setOnClickListener(v -> finish());

        setContentView(root);
    }

    private String buildDetails() {
        return "ORIGINAL\n"
                + "Archivo: " + videoInfo.fileName + "\n"
                + "Peso: " + videoInfo.sizeText() + "\n"
                + "Duracion: " + videoInfo.durationText() + "\n"
                + "Resolucion: " + videoInfo.resolutionText() + "\n"
                + "Bitrate original: " + videoInfo.bitrateText() + "\n\n"
                + "SALIDA\n"
                + "Plantilla/Preset: " + settings.modeName + "\n"
                + "Calidad: " + settings.qualityName + "\n"
                + "Resolucion: " + settings.resolutionText() + "\n"
                + "FPS: " + settings.fps + "\n"
                + "Bitrate: " + settings.bitrateMbps + " Mbps\n"
                + "Peso estimado: " + videoInfo.estimatedOutputSize(settings) + "\n"
                + "Formato: MP4 H.264\n"
                + "Carpeta: Movies/AnimeHDCleaner\n\n"
                + "Ajustes guardados\n"
                + "Brillo " + settings.brightness
                + " · Contraste " + settings.contrast
                + " · Saturacion " + settings.saturation
                + " · Luz " + settings.luminosity
                + " · Enfoque " + settings.sharpen
                + " · Ruido " + settings.denoise
                + "\n\nExporta el video completo con los ajustes reales seleccionados.";
    }

    private void chooseQuality() {
        String[] options = {
                "Original · mantener tamaño del video",
                "720P vertical · 720x1280 · 24 FPS · 8 Mbps",
                "1080P vertical · 1080x1920 · 24 FPS · 12 Mbps",
                "1080P 60 · 1080x1920 · 60 FPS · 15 Mbps"
        };
        new AlertDialog.Builder(this)
                .setTitle("Calidad de salida")
                .setItems(options, (d, which) -> {
                    if (which == 0) setQuality("Original", 0, 0, 24, 8);
                    if (which == 1) setQuality("720P", 720, 1280, 24, 8);
                    if (which == 2) setQuality("1080P", 1080, 1920, 24, 12);
                    if (which == 3) setQuality("1080P 60", 1080, 1920, 60, 15);
                    refreshDetails();
                })
                .show();
    }

    private void chooseBitrate() {
        String[] options = {
                "Bajo · 6 Mbps",
                "Medio · 10 Mbps",
                "Alto · 15 Mbps",
                "Maximo · 25 Mbps",
                "4K pesado · 35 Mbps"
        };
        new AlertDialog.Builder(this)
                .setTitle("Bitrate")
                .setItems(options, (d, which) -> {
                    if (which == 0) settings.bitrateMbps = 6;
                    if (which == 1) settings.bitrateMbps = 10;
                    if (which == 2) settings.bitrateMbps = 15;
                    if (which == 3) settings.bitrateMbps = 25;
                    if (which == 4) settings.bitrateMbps = 35;
                    refreshDetails();
                })
                .show();
    }

    private void chooseFps() {
        String[] options = {"24 FPS", "30 FPS", "60 FPS"};
        new AlertDialog.Builder(this)
                .setTitle("Cuadros por segundo")
                .setItems(options, (d, which) -> {
                    if (which == 0) settings.fps = 24;
                    if (which == 1) settings.fps = 30;
                    if (which == 2) settings.fps = 60;
                    refreshDetails();
                })
                .show();
    }

    private void setQuality(String name, int width, int height, int fps, int bitrate) {
        settings.qualityName = name;
        settings.width = width;
        settings.height = height;
        settings.fps = fps;
        settings.bitrateMbps = bitrate;
    }

    private void refreshDetails() {
        details.setText(buildDetails());
    }

    private void startExport() {
        if (videoUri == null) {
            Toast.makeText(this, "No hay video", Toast.LENGTH_SHORT).show();
            return;
        }

        LocalExporter.export(this, videoUri, settings, new LocalExporter.Listener() {
            @Override public void onProgress(int p, String message) {
                runOnUiThread(() -> {
                    progressBar.setProgress(p);
                    percent.setText(p + "%");
                    state.setText(message);
                });
            }

            @Override public void onFinished(boolean success, Uri outputUri, String message) {
                runOnUiThread(() -> {
                    lastOutputUri = outputUri;
                    progressBar.setProgress(100);
                    percent.setText("100%");
                    state.setText(message);
                    if (success) {
                        HistoryManager.add(ExportActivity.this, outputUri, settings, videoInfo);
                    }
                    Toast.makeText(ExportActivity.this, message, Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void openLastVideo() {
        if (lastOutputUri == null) {
            Toast.makeText(this, "Primero exporta un video", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(lastOutputUri, "video/mp4");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo abrir el video", Toast.LENGTH_SHORT).show();
        }
    }

    private void shareLastVideo() {
        if (lastOutputUri == null) {
            Toast.makeText(this, "Primero exporta un video", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("video/mp4");
            intent.putExtra(Intent.EXTRA_STREAM, lastOutputUri);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intent, "Compartir video"));
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo compartir el video", Toast.LENGTH_SHORT).show();
        }
    }

    private Button button(String label, int bg, int fg) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(fg);
        b.setBackgroundColor(bg);
        b.setAllCaps(false);
        b.setTextSize(13);
        return b;
    }

    private TextView text(String value, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(size);
        if (bold) t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        return t;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
