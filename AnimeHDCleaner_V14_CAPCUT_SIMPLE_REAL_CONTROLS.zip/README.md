# Anime HD Cleaner V14 CAPCUT SIMPLE REAL CONTROLS

Correcciones:
- Quitado el timeline/audio de abajo que no servía.
- Quitados controles falsos de enfoque/ruido del editor principal.
- Quedan solo controles reales:
  - brillo
  - contraste
  - saturación
  - luminosidad
- Los tabs ahora sí funcionan:
  - Predefinidos: aplica presets reales de color/luz.
  - Filtros: aplica filtros reales.
  - Ajustar: sliders reales.
  - Calidad: resolución, FPS y bitrate.
- Calidad por defecto: Original, para no cambiar 720x720 a 720x1280 sin querer.
- Al mover un ajuste se ve al toque en el frame.
- Al exportar se aplica al video completo con motor offline.

Limitación:
Exportar demora porque procesa el video completo frame por frame. Para ir más rápido usa calidad Original y 24 FPS.
