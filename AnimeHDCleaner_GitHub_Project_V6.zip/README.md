# Anime HD Cleaner V6

Versión estilo Quality Restoration / AI Repair.

## Cambios

- Interfaz inspirada en pantallas tipo reparación IA.
- Vista Before / After grande.
- Tarjetas:
  - Reparación IA
  - Ultra HD
  - Anime HD
  - Color IA
  - Quitar ruido
  - Sombras
- Exportación:
  - 720p
  - 1080p
  - 1080p 60 FPS
  - 2K
  - 4K
- Motor experimental con Media3 Transformer.
- Salida MP4 H.264 sin marca.

## Nota honesta

Esta V6 ya intenta exportar con motor real de Media3 Transformer y reescalar con Presentation.
Si GitHub Actions o el celular falla, manda captura exacta y se corrige.
