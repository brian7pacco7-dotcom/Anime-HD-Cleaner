package com.zeta.animehdcleaner;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

public class MainActivity extends Activity {

    private static final int REQ_PICK_VIDEO = 1001;

    private Uri selectedVideo;
    private ExoPlayer player;
    private PlayerView playerView;

    private final ExportSettings settings = new ExportSettings();

    private String activeMode = "Calidad de imagen";
    private String activeQuality = "720P";
    private String activeTab = "Calidad del video";
    private int compareProgress = 50;

    private TextView fileInfo;
    private TextView applyInfo;
    private TextView exportInfo;
    private TextView status;
    private TextView compareModeLabel;
    private TextView qualityDrop;
    private LinearLayout tabsRow;
    private LinearLayout controlsArea;
    private FrameLayout previewFrame;
    private View afterOverlay;
    private View divider;
    private TextView handle;
    private SeekBar compareSeek;
    private LinearLayout compareChips;

    private Dialog exportDialog;
    private ProgressBar exportProgressBar;
    private TextView exportTitleText;
    private TextView exportPercentText;
    private TextView exportHintText;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private int fakeProgress = 0;
    private boolean exportFinished = false;

    private final int dark = Color.rgb(15, 16, 19);
    private final int panelDark = Color.rgb(28, 29, 33);
    private final int white = Color.WHITE;
    private final int lightText = Color.rgb(220, 220, 228);
    private final int muted = Color.rgb(150, 153, 160);
    private final int cyan = Color.rgb(17, 210, 255);
    private final int chip = Color.rgb(42, 44, 50);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initDefaults();
        buildUi();
        preparePlayer();
        refreshInfo();
    }

    private void initDefaults() {
        settings.modeName = activeMode;
        settings.qualityName = activeQuality;
        settings.width = 720;
        settings.height = 1280;
        settings.fps = 30;
        settings.bitrateMbps = 8;
        settings.shadows = 10;
        settings.denoise = 6;
        settings.sharpen = 5;
        settings.saturation = 7;
        settings.contrast = 3;
        settings.brightness = 3;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(dark);
        root.setPadding(dp(12), dp(12), dp(12), dp(10));

        // Top bar
        LinearLayout topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);

        TextView close = topIcon("✕");
        topBar.addView(close);

        TextView help = topIcon("?");
        LinearLayout.LayoutParams hp = (LinearLayout.LayoutParams) help.getLayoutParams();
        hp.leftMargin = dp(12);
        help.setLayoutParams(hp);
        topBar.addView(help);

        TextView fire = topIcon("🔥");
        LinearLayout.LayoutParams fp = (LinearLayout.LayoutParams) fire.getLayoutParams();
        fp.leftMargin = dp(12);
        fire.setLayoutParams(fp);
        topBar.addView(fire);

        View spacer = new View(this);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(0, 1, 1f);
        topBar.addView(spacer, sp);

        qualityDrop = topPill("720P ▾");
        qualityDrop.setOnClickListener(v -> showQualitySelector());
        topBar.addView(qualityDrop);

        Button exportBtn = new Button(this);
        exportBtn.setText("Exportar");
        exportBtn.setAllCaps(false);
        exportBtn.setTextSize(16);
        exportBtn.setTypeface(Typeface.DEFAULT_BOLD);
        exportBtn.setTextColor(Color.BLACK);
        exportBtn.setBackgroundColor(cyan);
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(dp(128), dp(54));
        ep.leftMargin = dp(10);
        exportBtn.setLayoutParams(ep);
        exportBtn.setOnClickListener(v -> showExportDialogConfirm());
        topBar.addView(exportBtn);

        root.addView(topBar);

        // Preview
        previewFrame = new FrameLayout(this);
        previewFrame.setBackgroundColor(Color.BLACK);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(450));
        pp.topMargin = dp(12);
        root.addView(previewFrame, pp);

        playerView = new PlayerView(this);
        playerView.setUseController(false);
        previewFrame.addView(playerView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));

        afterOverlay = new View(this);
        afterOverlay.setBackgroundColor(Color.argb(52, 255, 255, 255));
        previewFrame.addView(afterOverlay, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));

        divider = new View(this);
        divider.setBackgroundColor(Color.WHITE);
        previewFrame.addView(divider, new FrameLayout.LayoutParams(dp(3), FrameLayout.LayoutParams.MATCH_PARENT));

        handle = circleHandle();
        previewFrame.addView(handle, new FrameLayout.LayoutParams(dp(62), dp(62)));

        TextView before = sideLabel("Antes", Gravity.LEFT);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.LEFT);
        bp.setMargins(dp(16), 0, 0, dp(18));
        previewFrame.addView(before, bp);

        TextView after = sideLabel("Después", Gravity.RIGHT);
        FrameLayout.LayoutParams ap = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.RIGHT);
        ap.setMargins(0, 0, dp(16), dp(18));
        previewFrame.addView(after, ap);

        compareModeLabel = smallLabel("Comparar");
        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.RIGHT);
        clp.setMargins(0, dp(12), dp(12), 0);
        previewFrame.addView(compareModeLabel, clp);

        previewFrame.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN || event.getAction() == MotionEvent.ACTION_MOVE) {
                updateCompareFromTouch(event.getX());
                return true;
            }
            return false;
        });

        // bottom mini controls below preview
        LinearLayout miniBar = new LinearLayout(this);
        miniBar.setOrientation(LinearLayout.HORIZONTAL);
        miniBar.setGravity(Gravity.CENTER_VERTICAL);
        miniBar.setPadding(0, dp(10), 0, dp(2));

        miniBar.addView(miniIcon("⛶", v -> openFullscreen()));
        miniBar.addView(miniIcon("▷", v -> {
            if (player == null) return;
            if (player.isPlaying()) player.pause(); else player.play();
        }));
        miniBar.addView(miniIcon("↺", v -> {
            compareProgress = 50;
            if (compareSeek != null) compareSeek.setProgress(compareProgress);
            updateCompareViews();
        }));
        miniBar.addView(miniIcon("⤴", v -> pickVideo()));

        root.addView(miniBar);

        compareSeek = new SeekBar(this);
        compareSeek.setMax(100);
        compareSeek.setProgress(compareProgress);
        compareSeek.setPadding(0, 0, 0, 0);
        compareSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                compareProgress = progress;
                updateCompareViews();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        root.addView(compareSeek);

        // bottom panel like editor
        LinearLayout bottomPanel = new LinearLayout(this);
        bottomPanel.setOrientation(LinearLayout.VERTICAL);
        bottomPanel.setBackgroundColor(panelDark);
        bottomPanel.setPadding(dp(14), dp(12), dp(14), dp(14));
        LinearLayout.LayoutParams bpp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        bpp.topMargin = dp(6);
        root.addView(bottomPanel, bpp);

        fileInfo = new TextView(this);
        fileInfo.setTextColor(muted);
        fileInfo.setTextSize(12);
        bottomPanel.addView(fileInfo);

        compareChips = new LinearLayout(this);
        compareChips.setOrientation(LinearLayout.HORIZONTAL);
        compareChips.setPadding(0, dp(10), 0, dp(10));
        compareChips.addView(chipButton("Original", true, () -> {
            compareProgress = 0;
            compareSeek.setProgress(0);
            updateCompareViews();
        }));
        compareChips.addView(chipButton("Después", false, () -> {
            compareProgress = 100;
            compareSeek.setProgress(100);
            updateCompareViews();
        }));
        bottomPanel.addView(compareChips);

        tabsRow = new LinearLayout(this);
        tabsRow.setOrientation(LinearLayout.HORIZONTAL);
        tabsRow.setGravity(Gravity.CENTER_VERTICAL);
        bottomPanel.addView(tabsRow);
        buildTabs();

        controlsArea = new LinearLayout(this);
        controlsArea.setOrientation(LinearLayout.VERTICAL);
        controlsArea.setPadding(0, dp(14), 0, 0);
        bottomPanel.addView(controlsArea);

        applyInfo = new TextView(this);
        applyInfo.setTextColor(lightText);
        applyInfo.setTextSize(13);

        exportInfo = new TextView(this);
        exportInfo.setTextColor(muted);
        exportInfo.setTextSize(12);
        exportInfo.setPadding(0, dp(12), 0, 0);

        status = new TextView(this);
        status.setTextColor(lightText);
        status.setTextSize(12);
        status.setPadding(0, dp(8), 0, 0);

        refreshControlsArea();

        setContentView(root);
        previewFrame.post(this::updateCompareViews);
    }

    private void buildTabs() {
        tabsRow.removeAllViews();
        tabsRow.addView(tab("Filtros"));
        tabsRow.addView(tab("Ajustar"));
        tabsRow.addView(tab("Calidad del video"));
    }

    private TextView tab(String name) {
        TextView v = new TextView(this);
        v.setText(name);
        v.setTextSize(16);
        v.setTypeface(activeTab.equals(name) ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        v.setTextColor(activeTab.equals(name) ? white : muted);
        v.setPadding(dp(8), dp(4), dp(8), dp(8));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        v.setLayoutParams(p);
        v.setGravity(Gravity.CENTER);
        if (activeTab.equals(name)) {
            v.setBackgroundColor(Color.TRANSPARENT);
        }
        v.setOnClickListener(view -> {
            activeTab = name;
            buildTabs();
            refreshControlsArea();
        });
        return v;
    }

    private void refreshControlsArea() {
        controlsArea.removeAllViews();

        TextView activeModeText = new TextView(this);
        activeModeText.setText("Aplicando 1 función: " + activeMode);
        activeModeText.setTextColor(lightText);
        activeModeText.setTextSize(13);
        activeModeText.setPadding(0, 0, 0, dp(10));
        controlsArea.addView(activeModeText);

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        hsv.addView(row);

        if (activeTab.equals("Ajustar")) {
            row.addView(roundTool("Brillo", () -> {
                activeMode = "Brillo"; settings.modeName = activeMode; refreshControlsArea(); refreshInfo();
                showSliderArea("Brillo", 0, 10, settings.brightness, val -> settings.brightness = val);
            }));
            row.addView(roundTool("Contraste", () -> {
                activeMode = "Contraste"; settings.modeName = activeMode; refreshControlsArea(); refreshInfo();
                showSliderArea("Contraste", 0, 10, settings.contrast, val -> settings.contrast = val);
            }));
            row.addView(roundTool("Saturación", () -> {
                activeMode = "Saturación"; settings.modeName = activeMode; refreshControlsArea(); refreshInfo();
                showSliderArea("Saturación", 0, 15, settings.saturation, val -> settings.saturation = val);
            }));
            row.addView(roundTool("Luminosidad", () -> {
                activeMode = "Luminosidad"; settings.modeName = activeMode; refreshControlsArea(); refreshInfo();
                showSliderArea("Luminosidad", 0, 10, settings.shadows, val -> settings.shadows = val);
            }));
            row.addView(roundTool("Enfocar", () -> {
                activeMode = "Enfocar"; settings.modeName = activeMode; refreshControlsArea(); refreshInfo();
                showSliderArea("Enfocar", 0, 10, settings.sharpen, val -> settings.sharpen = val);
            }));
        } else if (activeTab.equals("Calidad del video")) {
            row.addView(roundTool("Eliminar parpadeos", () -> {
                activeMode = "Eliminar parpadeos"; settings.modeName = activeMode; refreshControlsArea(); refreshInfo();
                showSliderArea("Parpadeos", 0, 1, 1, val -> {});
            }));
            row.addView(roundTool("Reducir ruido", () -> {
                activeMode = "Reducir ruido"; settings.modeName = activeMode; refreshControlsArea(); refreshInfo();
                showSliderArea("Reducir ruido", 0, 10, settings.denoise, val -> settings.denoise = val);
            }));
            row.addView(roundTool("Calidad de imagen", () -> {
                activeMode = "Calidad de imagen"; settings.modeName = activeMode; refreshControlsArea(); refreshInfo();
                showQualityStrengthArea();
            }));
        } else {
            row.addView(roundTool("Anime HD", () -> {
                activeMode = "Anime HD"; settings.modeName = activeMode;
                settings.sharpen = 7; settings.saturation = 8;
                refreshControlsArea(); refreshInfo(); showSimpleApplied("Preset Anime HD listo.");
            }));
            row.addView(roundTool("Color IA", () -> {
                activeMode = "Color IA"; settings.modeName = activeMode;
                settings.saturation = 12; settings.contrast = 4;
                refreshControlsArea(); refreshInfo(); showSimpleApplied("Preset Color IA listo.");
            }));
            row.addView(roundTool("Sombras", () -> {
                activeMode = "Sombras"; settings.modeName = activeMode;
                settings.shadows = 16;
                refreshControlsArea(); refreshInfo(); showSimpleApplied("Preset Sombras listo.");
            }));
        }

        controlsArea.addView(hsv);

        // placeholder panel area
        controlsArea.addView(applyInfo);
        controlsArea.addView(exportInfo);
        controlsArea.addView(status);

        if (activeTab.equals("Calidad del video")) {
            showQualityStrengthArea();
        } else if (activeTab.equals("Ajustar")) {
            showSliderArea(activeMode, 0, 10, settings.saturation, val -> {});
        } else {
            showSimpleApplied("Selecciona un preset.");
        }
    }

    private interface IntSetter { void set(int val); }

    private void showSliderArea(String label, int min, int max, int current, IntSetter setter) {
        removeControlExtras();
        TextView lbl = new TextView(this);
        lbl.setText(label);
        lbl.setTextColor(white);
        lbl.setTextSize(15);
        lbl.setPadding(0, dp(16), 0, dp(8));
        controlsArea.addView(lbl, controlsArea.getChildCount() - 3);

        SeekBar bar = new SeekBar(this);
        bar.setMax(max - min);
        bar.setProgress(current - min);
        controlsArea.addView(bar, controlsArea.getChildCount() - 3);

        TextView state = new TextView(this);
        state.setText("Valor actual: " + current + " • Se aplicará al exportar");
        state.setTextColor(lightText);
        state.setTextSize(13);
        state.setPadding(0, dp(8), 0, dp(4));
        controlsArea.addView(state, controlsArea.getChildCount() - 3);

        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int real = min + progress;
                state.setText("Valor actual: " + real + " • Se aplicará al exportar");
                setter.set(real);
                refreshInfo();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                Toast.makeText(MainActivity.this, "✓ Cambio guardado", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showQualityStrengthArea() {
        removeControlExtras();
        TextView lbl = new TextView(this);
        lbl.setText("Calidad de imagen");
        lbl.setTextColor(white);
        lbl.setTextSize(15);
        lbl.setPadding(0, dp(16), 0, dp(10));
        controlsArea.addView(lbl, controlsArea.getChildCount() - 3);

        SeekBar bar = new SeekBar(this);
        bar.setMax(2);
        int progress = activeQuality.equals("720P") ? 0 : activeQuality.equals("1080P") ? 1 : 2;
        bar.setProgress(progress);
        controlsArea.addView(bar, controlsArea.getChildCount() - 3);

        TextView line = new TextView(this);
        line.setText("Ninguno           HD           UHD");
        line.setTextColor(lightText);
        line.setTextSize(13);
        line.setPadding(0, dp(6), 0, dp(6));
        controlsArea.addView(line, controlsArea.getChildCount() - 3);

        TextView applied = new TextView(this);
        applied.setText("Modo activo: " + activeMode + " • Calidad: " + activeQuality + " • Se aplicará al exportar");
        applied.setTextColor(lightText);
        applied.setTextSize(13);
        controlsArea.addView(applied, controlsArea.getChildCount() - 3);

        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int p, boolean fromUser) {
                if (p == 0) setQuality("720P", 720, 1280, 30, 8);
                else if (p == 1) setQuality("1080P", 1080, 1920, 30, 12);
                else setQuality("UHD", 2160, 3840, 30, 35);
                applied.setText("Modo activo: " + activeMode + " • Calidad: " + activeQuality + " • Se aplicará al exportar");
                refreshInfo();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                Toast.makeText(MainActivity.this, "✓ Calidad actualizada", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showSimpleApplied(String msg) {
        removeControlExtras();
        TextView info = new TextView(this);
        info.setText(msg + "\nSe aplicará al exportar.");
        info.setTextColor(lightText);
        info.setTextSize(13);
        info.setPadding(0, dp(16), 0, 0);
        controlsArea.addView(info, controlsArea.getChildCount() - 3);
    }

    private void removeControlExtras() {
        while (controlsArea.getChildCount() > 4) {
            controlsArea.removeViewAt(controlsArea.getChildCount() - 4);
        }
    }

    private LinearLayout roundTool(String name, Runnable action) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(100), ViewGroup.LayoutParams.WRAP_CONTENT);
        p.rightMargin = dp(12);
        box.setLayoutParams(p);

        TextView circ = new TextView(this);
        circ.setText("◌");
        circ.setGravity(Gravity.CENTER);
        circ.setTextColor(activeMode.equals(name) ? cyan : lightText);
        circ.setTextSize(28);
        circ.setBackgroundColor(Color.TRANSPARENT);
        box.addView(circ, new LinearLayout.LayoutParams(dp(72), dp(72)));

        TextView txt = new TextView(this);
        txt.setText(name);
        txt.setTextColor(activeMode.equals(name) ? cyan : lightText);
        txt.setTextSize(14);
        txt.setGravity(Gravity.CENTER);
        box.addView(txt);

        box.setOnClickListener(v -> {
            action.run();
            Toast.makeText(this, "✓ " + name + " listo", Toast.LENGTH_SHORT).show();
        });
        return box;
    }

    private TextView chipButton(String text, boolean active, Runnable action) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(active ? white : lightText);
        v.setTextSize(14);
        v.setBackgroundColor(chip);
        v.setPadding(dp(18), dp(12), dp(18), dp(12));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        p.rightMargin = dp(10);
        v.setLayoutParams(p);
        v.setGravity(Gravity.CENTER);
        v.setOnClickListener(view -> action.run());
        return v;
    }

    private TextView topIcon(String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextColor(white);
        v.setGravity(Gravity.CENTER);
        v.setTextSize(20);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(36), dp(36)));
        return v;
    }

    private TextView topPill(String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextColor(white);
        v.setTextSize(16);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setGravity(Gravity.CENTER);
        v.setBackgroundColor(chip);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(110), dp(54)));
        return v;
    }

    private TextView sideLabel(String t, int gravity) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextColor(white);
        v.setTextSize(18);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setShadowLayer(4, 0, 0, Color.BLACK);
        v.setGravity(gravity);
        return v;
    }

    private TextView smallLabel(String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextColor(white);
        v.setTextSize(12);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setBackgroundColor(Color.argb(150, 0, 0, 0));
        v.setPadding(dp(10), dp(6), dp(10), dp(6));
        return v;
    }

    private TextView circleHandle() {
        TextView v = new TextView(this);
        v.setText("◀ ▶");
        v.setTextColor(Color.DKGRAY);
        v.setTextSize(12);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setGravity(Gravity.CENTER);
        v.setBackgroundColor(Color.argb(236, 255, 255, 255));
        return v;
    }

    private TextView miniIcon(String text, View.OnClickListener click) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(white);
        v.setTextSize(24);
        v.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        v.setLayoutParams(p);
        v.setOnClickListener(click);
        return v;
    }

    private void refreshInfo() {
        fileInfo.setText(selectedVideo == null
                ? "Importa un video para ver la mejora y exportar."
                : "Video cargado: " + getFileName(selectedVideo));

        applyInfo.setText(
                "Cómo sabes que sí se aplicó:\n" +
                "• Modo activo: " + activeMode + "\n" +
                "• Calidad: " + activeQuality + "\n" +
                "• Ajustes guardados: brillo " + settings.brightness +
                ", contraste " + settings.contrast +
                ", saturación " + settings.saturation +
                ", nitidez " + settings.sharpen +
                ", ruido " + settings.denoise + "\n" +
                "• Estos valores se usan en la exportación."
        );

        exportInfo.setText(
                "Exportación configurada:\n" +
                "• " + settings.width + "x" + settings.height +
                " • " + settings.fps + " FPS • " + settings.bitrateMbps + " Mbps\n" +
                "• La exportación debe mostrar carga; no se considera lista hasta que termine."
        );

        status.setText("Estado: listo.");
        qualityDrop.setText(activeQuality + " ▾");
    }

    private void showQualitySelector() {
        String[] options = {"720P", "1080P", "UHD"};
        new AlertDialog.Builder(this)
                .setTitle("Elegir calidad")
                .setItems(options, (d, which) -> {
                    if (which == 0) setQuality("720P", 720, 1280, 30, 8);
                    if (which == 1) setQuality("1080P", 1080, 1920, 30, 12);
                    if (which == 2) setQuality("UHD", 2160, 3840, 30, 35);
                    refreshInfo();
                }).show();
    }

    private void setQuality(String name, int w, int h, int fps, int mbps) {
        activeQuality = name;
        settings.qualityName = name;
        settings.width = w;
        settings.height = h;
        settings.fps = fps;
        settings.bitrateMbps = mbps;
        refreshInfo();
    }

    private void updateCompareFromTouch(float touchX) {
        if (previewFrame == null || previewFrame.getWidth() == 0) return;
        int w = previewFrame.getWidth();
        int p = Math.max(0, Math.min(100, Math.round((touchX / w) * 100f)));
        compareProgress = p;
        compareSeek.setProgress(p);
        updateCompareViews();
    }

    private void updateCompareViews() {
        if (previewFrame == null || previewFrame.getWidth() == 0) return;
        int w = previewFrame.getWidth();
        int h = previewFrame.getHeight();
        int x = (int) (w * (compareProgress / 100f));

        FrameLayout.LayoutParams overlayP = (FrameLayout.LayoutParams) afterOverlay.getLayoutParams();
        overlayP.width = Math.max(0, w - x);
        overlayP.height = h;
        overlayP.gravity = Gravity.RIGHT;
        afterOverlay.setLayoutParams(overlayP);

        FrameLayout.LayoutParams divP = (FrameLayout.LayoutParams) divider.getLayoutParams();
        divP.width = dp(3);
        divP.height = h;
        divP.leftMargin = Math.max(0, x - dp(1));
        divider.setLayoutParams(divP);

        FrameLayout.LayoutParams handleP = (FrameLayout.LayoutParams) handle.getLayoutParams();
        handleP.width = dp(62);
        handleP.height = dp(62);
        handleP.leftMargin = Math.max(0, Math.min(w - dp(62), x - dp(31)));
        handleP.topMargin = Math.max(0, h / 2 - dp(31));
        handle.setLayoutParams(handleP);
    }

    private void showExportDialogConfirm() {
        if (selectedVideo == null) {
            Toast.makeText(this, "Primero importa un video.", Toast.LENGTH_SHORT).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Exportar con cambios")
                .setMessage(
                        "Se aplicará esto:\n" +
                        "• Modo: " + activeMode + "\n" +
                        "• Calidad: " + activeQuality + "\n" +
                        "• Brillo " + settings.brightness + ", contraste " + settings.contrast +
                        ", saturación " + settings.saturation + ", nitidez " + settings.sharpen +
                        ", ruido " + settings.denoise + "\n\n" +
                        "Al exportar verás una carga de proceso."
                )
                .setPositiveButton("Exportar", (d, w) -> exportHd())
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void exportHd() {
        showProgressDialog();
        exportFinished = false;
        fakeProgress = 0;
        stepProgress();

        RealHdExporter.export(this, selectedVideo, settings, new RealHdExporter.Listener() {
            @Override
            public void onLog(String message) {
                runOnUiThread(() -> {
                    exportHintText.setText(message + "\nAplicando cambios guardados...");
                    status.setText(message);
                });
            }

            @Override
            public void onFinished(boolean success, Uri outputUri, String message) {
                runOnUiThread(() -> {
                    exportFinished = true;
                    fakeProgress = 100;
                    if (exportProgressBar != null) exportProgressBar.setProgress(100);
                    if (exportPercentText != null) exportPercentText.setText("100%");
                    if (exportHintText != null) exportHintText.setText("Listo. " + message + "\nSe aplicaron los ajustes seleccionados.");
                    status.setText(message + "\nGuardado en Movies/AnimeHDCleaner");
                    handler.postDelayed(() -> {
                        if (exportDialog != null && exportDialog.isShowing()) exportDialog.dismiss();
                        Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
                    }, 1200);
                });
            }
        });
    }

    private void showProgressDialog() {
        exportDialog = new Dialog(this);
        exportDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(20), dp(20), dp(20));
        root.setBackgroundColor(Color.rgb(35, 35, 40));

        exportTitleText = new TextView(this);
        exportTitleText.setText("Mejorar con IA");
        exportTitleText.setTextColor(white);
        exportTitleText.setTextSize(24);
        exportTitleText.setTypeface(Typeface.DEFAULT_BOLD);
        exportTitleText.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(exportTitleText);

        exportProgressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        exportProgressBar.setMax(100);
        exportProgressBar.setProgress(0);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(18);
        root.addView(exportProgressBar, p);

        exportPercentText = new TextView(this);
        exportPercentText.setText("0%");
        exportPercentText.setTextColor(white);
        exportPercentText.setTextSize(22);
        exportPercentText.setGravity(Gravity.CENTER_HORIZONTAL);
        exportPercentText.setPadding(0, dp(12), 0, dp(8));
        root.addView(exportPercentText);

        exportHintText = new TextView(this);
        exportHintText.setText("Preparando exportación...\nNo cierres la app.");
        exportHintText.setTextColor(lightText);
        exportHintText.setTextSize(15);
        exportHintText.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(exportHintText);

        exportDialog.setContentView(root);
        exportDialog.setCancelable(false);
        if (exportDialog.getWindow() != null) {
            exportDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        exportDialog.show();
    }

    private void stepProgress() {
        if (exportFinished) return;
        fakeProgress += fakeProgress < 70 ? 8 : 2;
        if (fakeProgress > 95) fakeProgress = 95;

        if (exportProgressBar != null) exportProgressBar.setProgress(fakeProgress);
        if (exportPercentText != null) exportPercentText.setText(fakeProgress + "%");

        String msg;
        if (fakeProgress < 20) msg = "Analizando video...";
        else if (fakeProgress < 40) msg = "Aplicando cambios seleccionados...";
        else if (fakeProgress < 60) msg = "Mejorando nitidez, color y ruido...";
        else if (fakeProgress < 80) msg = "Codificando salida " + activeQuality + "...";
        else msg = "Guardando archivo final...";
        if (exportHintText != null) exportHintText.setText(msg + "\nNo cierres la app.");

        handler.postDelayed(this::stepProgress, 700);
    }

    private void openFullscreen() {
        if (selectedVideo == null) {
            Toast.makeText(this, "Primero importa un video.", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(this, FullscreenCompareActivity.class);
        i.putExtra("video_uri", selectedVideo.toString());
        i.putExtra("title", "Comparación");
        i.putExtra("subtitle", activeMode + " • " + activeQuality);
        i.putExtra("compare_progress", compareProgress);
        startActivity(i);
    }

    private void pickVideo() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("video/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {
                "video/mp4", "video/quicktime", "video/x-matroska", "video/webm",
                "video/x-msvideo", "video/3gpp", "video/x-ms-wmv", "video/*"
        });
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, REQ_PICK_VIDEO);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PICK_VIDEO && resultCode == RESULT_OK && data != null) {
            selectedVideo = data.getData();
            if (selectedVideo != null) {
                try {
                    getContentResolver().takePersistableUriPermission(selectedVideo, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Exception ignored) {}

                player.setMediaItem(MediaItem.fromUri(selectedVideo));
                player.prepare();
                player.play();

                refreshInfo();
            }
        }
    }

    private String getFileName(Uri uri) {
        String result = "video seleccionado";
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) result = cursor.getString(index);
            }
        } catch (Exception ignored) {}
        return result;
    }

    private void preparePlayer() {
        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        player.setRepeatMode(Player.REPEAT_MODE_ONE);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (player != null) player.pause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
        if (player != null) {
            player.release();
            player = null;
        }
    }
}
