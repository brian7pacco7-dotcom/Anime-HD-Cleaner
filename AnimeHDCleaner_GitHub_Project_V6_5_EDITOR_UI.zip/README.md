# Anime HD Cleaner V6.5 Editor UI

## Cambios principales

- Interfaz más parecida a editor móvil:
  - barra superior con calidad y botón Exportar
  - panel inferior oscuro
  - pestañas: Filtros, Ajustar, Calidad del video
- Comparador Antes / Después sigue activo.
- Ahora puedes ver mejor si el cambio sí se aplicará:
  - modo activo
  - calidad activa
  - valores guardados
- La exportación ya muestra una carga/progreso visible:
  - Analizando video
  - Aplicando cambios
  - Codificando salida
  - Guardando archivo final

## Nota honesta

La barra de progreso de exportación es visual para que se note el proceso.
El archivo final sigue usando el exportador real del proyecto.
