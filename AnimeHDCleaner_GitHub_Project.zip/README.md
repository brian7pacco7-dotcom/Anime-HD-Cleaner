# Anime HD Cleaner

App Android para mejorar videos de anime antes de subirlos a TikTok, Instagram Reels o Facebook Reels.

## Qué hace

- Limpia sombras oscuras feas.
- Reduce manchas y bloques en zonas negras.
- Mejora nitidez.
- Mejora color anime.
- Agrega grano fino para reducir banding/posterización.
- Exporta en 1080x1920 vertical.
- Exporta sin marca de agua.

## Modos

- Anime oscuro
- Sombras limpias
- Anti-manchas
- Más nitidez
- TikTok/Reels HD

## Controles manuales

- Brillo
- Contraste
- Saturación
- Gamma/sombras
- Denoise
- Nitidez
- Grano fino
- FPS 30/60
- Bitrate 8-15 Mbps

## Recomendación

Para videos de más de 1 minuto:

- 1080x1920
- 30 FPS
- 12 Mbps

Para videos con mucho movimiento:

- 1080x1920
- 60 FPS
- 15 Mbps

## Nota honesta

Esta V1 no usa IA pesada. Usa filtros técnicos con FFmpeg.
La "IA básica" será un motor de presets inteligentes: elige valores buenos para anime oscuro, sombras, nitidez y Reels.

Después se puede agregar IA real ligera, pero primero conviene que la app compile y procese bien.
