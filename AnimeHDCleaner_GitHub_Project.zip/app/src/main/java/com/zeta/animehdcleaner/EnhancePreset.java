package com.zeta.animehdcleaner;

public enum EnhancePreset {
    ANIME_DARK("Anime oscuro"),
    CLEAN_SHADOWS("Sombras limpias"),
    ANTI_BANDING("Anti-manchas"),
    SHARP_HD("Más nitidez"),
    REELS_HD("TikTok/Reels HD");

    public final String title;

    EnhancePreset(String title) {
        this.title = title;
    }
}
