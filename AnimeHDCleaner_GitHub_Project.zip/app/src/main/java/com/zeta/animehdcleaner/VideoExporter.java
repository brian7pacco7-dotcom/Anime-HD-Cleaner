package com.zeta.animehdcleaner;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;

import com.arthenica.ffmpegkit.FFmpegKit;
import com.arthenica.ffmpegkit.FFmpegKitConfig;
import com.arthenica.ffmpegkit.ReturnCode;
import com.arthenica.ffmpegkit.Session;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class VideoExporter {

    public interface Listener {
        void onLog(String text);
        void onFinished(boolean success, Uri outputUri, String message);
    }

    public static void export(Context context, Uri inputUri, EnhanceSettings settings, Listener listener) {
        try {
            Uri outputUri = createOutputUri(context);
            if (outputUri == null) {
                listener.onFinished(false, null, "No se pudo crear archivo de salida.");
                return;
            }

            String inputSaf = FFmpegKitConfig.getSafParameterForRead(context, inputUri);
            String outputSaf = FFmpegKitConfig.getSafParameterForWrite(context, outputUri);

            String command = FilterCommandBuilder.buildCommand(inputSaf, outputSaf, settings);
            listener.onLog("Procesando con preset: " + settings.preset.title);
            listener.onLog("Salida: Movies/AnimeHDCleaner/");
            listener.onLog("FPS: " + settings.fps + " | Bitrate: " + settings.bitrateMbps + " Mbps");

            FFmpegKit.executeAsync(command, session -> {
                ReturnCode code = session.getReturnCode();
                if (ReturnCode.isSuccess(code)) {
                    listener.onFinished(true, outputUri, "Listo. Video exportado sin marca de agua.");
                } else {
                    String fail = getFailStack(session);
                    listener.onFinished(false, null, "Falló la exportación. " + fail);
                }
            }, log -> {
                if (log != null && log.getMessage() != null) {
                    String msg = log.getMessage().trim();
                    if (!msg.isEmpty()) listener.onLog(msg);
                }
            }, statistics -> {
                if (statistics != null) {
                    long timeMs = statistics.getTime();
                    if (timeMs > 0) {
                        listener.onLog("Tiempo procesado: " + (timeMs / 1000) + " s");
                    }
                }
            });

        } catch (Exception e) {
            listener.onFinished(false, null, "Error: " + e.getMessage());
        }
    }

    private static Uri createOutputUri(Context context) {
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        String fileName = "anime_hd_cleaner_" + stamp + ".mp4";

        ContentValues values = new ContentValues();
        values.put(MediaStore.Video.Media.DISPLAY_NAME, fileName);
        values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        values.put(MediaStore.Video.Media.RELATIVE_PATH,
                Environment.DIRECTORY_MOVIES + "/AnimeHDCleaner");

        ContentResolver resolver = context.getContentResolver();
        return resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
    }

    private static String getFailStack(Session session) {
        try {
            String stack = session.getFailStackTrace();
            if (stack != null && !stack.trim().isEmpty()) return stack;
        } catch (Exception ignored) {
        }
        return "Revisa si el video está dañado o si el celular no soporta ese formato.";
    }
}
