package com.zeta.animehdcleaner;

public class EnhanceSettings {
    public EnhancePreset preset = EnhancePreset.ANIME_DARK;

    public float brightness = 0.03f;
    public float contrast = 1.04f;
    public float saturation = 1.08f;
    public float gamma = 1.06f;
    public int denoise = 5;
    public int sharpen = 4;
    public int grain = 3;
    public int fps = 30;
    public int bitrateMbps = 12;

    public void applyPreset(EnhancePreset selected) {
        preset = selected;

        if (selected == EnhancePreset.ANIME_DARK) {
            brightness = 0.04f;
            contrast = 1.03f;
            saturation = 1.10f;
            gamma = 1.08f;
            denoise = 6;
            sharpen = 4;
            grain = 3;
            fps = 30;
            bitrateMbps = 12;
        } else if (selected == EnhancePreset.CLEAN_SHADOWS) {
            brightness = 0.05f;
            contrast = 0.98f;
            saturation = 1.05f;
            gamma = 1.12f;
            denoise = 7;
            sharpen = 3;
            grain = 4;
            fps = 30;
            bitrateMbps = 12;
        } else if (selected == EnhancePreset.ANTI_BANDING) {
            brightness = 0.02f;
            contrast = 0.96f;
            saturation = 1.02f;
            gamma = 1.10f;
            denoise = 8;
            sharpen = 2;
            grain = 5;
            fps = 30;
            bitrateMbps = 12;
        } else if (selected == EnhancePreset.SHARP_HD) {
            brightness = 0.02f;
            contrast = 1.06f;
            saturation = 1.12f;
            gamma = 1.03f;
            denoise = 4;
            sharpen = 7;
            grain = 2;
            fps = 30;
            bitrateMbps = 15;
        } else if (selected == EnhancePreset.REELS_HD) {
            brightness = 0.03f;
            contrast = 1.04f;
            saturation = 1.08f;
            gamma = 1.06f;
            denoise = 5;
            sharpen = 5;
            grain = 3;
            fps = 30;
            bitrateMbps = 12;
        }
    }
}
