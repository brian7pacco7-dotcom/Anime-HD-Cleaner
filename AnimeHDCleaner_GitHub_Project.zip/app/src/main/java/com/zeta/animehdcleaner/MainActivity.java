package com.zeta.animehdcleaner;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.VideoView;

import java.util.Locale;

public class MainActivity extends Activity {

    private static final int REQ_PICK_VIDEO = 1001;

    private Uri selectedVideo;
    private final EnhanceSettings settings = new EnhanceSettings();

    private TextView status;
    private VideoView preview;
    private LinearLayout controls;

    private SeekBar brightnessBar;
    private SeekBar contrastBar;
    private SeekBar saturationBar;
    private SeekBar gammaBar;
    private SeekBar denoiseBar;
    private SeekBar sharpenBar;
    private SeekBar grainBar;
    private SeekBar bitrateBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        settings.applyPreset(EnhancePreset.ANIME_DARK);
        buildUi();
        refreshBarsFromSettings();
        refreshStatus("Elige un video para empezar.");
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(26, 28, 26, 28);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("Anime HD Cleaner");
        title.setTextSize(26);
        title.setGravity(Gravity.CENTER);
        title.setTextColor(0xFF111827);
        title.setPadding(0, 0, 0, 6);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Limpia sombras, reduce manchas y exporta videos para TikTok/Reels sin marca de agua.");
        subtitle.setTextSize(14);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setTextColor(0xFF4B5563);
        subtitle.setPadding(0, 0, 0, 20);
        root.addView(subtitle);

        Button pick = bigButton("Elegir video");
        pick.setOnClickListener(v -> pickVideo());
        root.addView(pick);

        preview = new VideoView(this);
        LinearLayout.LayoutParams videoParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                980
        );
        videoParams.setMargins(0, 18, 0, 18);
        preview.setLayoutParams(videoParams);
        preview.setBackgroundColor(0xFF111827);
        root.addView(preview);

        root.addView(section("Modo rápido"));

        RadioGroup group = new RadioGroup(this);
        group.setOrientation(RadioGroup.VERTICAL);

        for (EnhancePreset preset : EnhancePreset.values()) {
            RadioButton rb = new RadioButton(this);
            rb.setText(preset.title);
            rb.setTextSize(16);
            rb.setTag(preset);
            group.addView(rb);
            if (preset == EnhancePreset.ANIME_DARK) rb.setChecked(true);
        }

        group.setOnCheckedChangeListener((g, checkedId) -> {
            RadioButton rb = findViewById(checkedId);
            if (rb != null && rb.getTag() instanceof EnhancePreset) {
                settings.applyPreset((EnhancePreset) rb.getTag());
                refreshBarsFromSettings();
                refreshStatus("Modo aplicado: " + settings.preset.title);
            }
        });

        root.addView(group);

        controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.VERTICAL);
        root.addView(controls);

        brightnessBar = addSlider("Brillo", 0, 40, 23, value -> settings.brightness = (value - 20) / 100.0f);
        contrastBar = addSlider("Contraste", 80, 130, 104, value -> settings.contrast = value / 100.0f);
        saturationBar = addSlider("Saturación", 80, 150, 108, value -> settings.saturation = value / 100.0f);
        gammaBar = addSlider("Gamma / sombras", 70, 140, 106, value -> settings.gamma = value / 100.0f);
        denoiseBar = addSlider("Denoise / anti-manchas", 0, 10, 5, value -> settings.denoise = value);
        sharpenBar = addSlider("Nitidez", 0, 10, 4, value -> settings.sharpen = value);
        grainBar = addSlider("Grano fino anti-banding", 0, 10, 3, value -> settings.grain = value);
        bitrateBar = addSlider("Bitrate Mbps", 8, 15, 12, value -> settings.bitrateMbps = value);

        LinearLayout fpsRow = new LinearLayout(this);
        fpsRow.setOrientation(LinearLayout.HORIZONTAL);
        fpsRow.setGravity(Gravity.CENTER);
        Button fps30 = smallButton("30 FPS");
        Button fps60 = smallButton("60 FPS");
        fps30.setOnClickListener(v -> {
            settings.fps = 30;
            refreshStatus("FPS: 30. Recomendado para videos de más de 1 minuto.");
        });
        fps60.setOnClickListener(v -> {
            settings.fps = 60;
            refreshStatus("FPS: 60. Úsalo solo si el video tiene mucho movimiento.");
        });
        fpsRow.addView(fps30);
        fpsRow.addView(fps60);
        root.addView(fpsRow);

        Button export = bigButton("Exportar HD sin marca");
        export.setOnClickListener(v -> exportVideo());
        root.addView(export);

        status = new TextView(this);
        status.setTextSize(13);
        status.setTextColor(0xFF111827);
        status.setPadding(0, 18, 0, 50);
        root.addView(status);

        setContentView(scroll);
    }

    private TextView section(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(18);
        view.setTextColor(0xFF111827);
        view.setPadding(0, 14, 0, 6);
        return view;
    }

    private Button bigButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(16);
        b.setAllCaps(false);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        p.setMargins(0, 8, 0, 8);
        b.setLayoutParams(p);
        return b;
    }

    private Button smallButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(14);
        b.setAllCaps(false);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        p.setMargins(6, 8, 6, 8);
        b.setLayoutParams(p);
        return b;
    }

    private interface SliderListener {
        void onChanged(int value);
    }

    private SeekBar addSlider(String name, int min, int max, int value, SliderListener listener) {
        TextView label = new TextView(this);
        label.setText(name + ": " + value);
        label.setTextSize(14);
        label.setPadding(0, 12, 0, 0);
        controls.addView(label);

        SeekBar bar = new SeekBar(this);
        bar.setMax(max - min);
        bar.setProgress(value - min);
        controls.addView(bar);

        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int real = min + progress;
                label.setText(name + ": " + real);
                listener.onChanged(real);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                refreshStatus(summary());
            }
        });

        return bar;
    }

    private void refreshBarsFromSettings() {
        setBar(brightnessBar, 0, Math.round(settings.brightness * 100) + 20);
        setBar(contrastBar, 80, Math.round(settings.contrast * 100));
        setBar(saturationBar, 80, Math.round(settings.saturation * 100));
        setBar(gammaBar, 70, Math.round(settings.gamma * 100));
        setBar(denoiseBar, 0, settings.denoise);
        setBar(sharpenBar, 0, settings.sharpen);
        setBar(grainBar, 0, settings.grain);
        setBar(bitrateBar, 8, settings.bitrateMbps);
    }

    private void setBar(SeekBar bar, int min, int realValue) {
        if (bar != null) bar.setProgress(realValue - min);
    }

    private void pickVideo() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("video/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, REQ_PICK_VIDEO);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PICK_VIDEO && resultCode == RESULT_OK && data != null) {
            selectedVideo = data.getData();
            if (selectedVideo != null) {
                try {
                    getContentResolver().takePersistableUriPermission(
                            selectedVideo,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION
                    );
                } catch (Exception ignored) {}

                preview.setVideoURI(selectedVideo);
                preview.setOnPreparedListener(mp -> {
                    mp.setLooping(true);
                    preview.start();
                });
                refreshStatus("Video cargado. Ajusta y exporta.");
            }
        }
    }

    private void exportVideo() {
        if (selectedVideo == null) {
            refreshStatus("Primero elige un video.");
            return;
        }

        refreshStatus("Procesando... No cierres la app.");
        VideoExporter.export(this, selectedVideo, settings, new VideoExporter.Listener() {
            @Override
            public void onLog(String text) {
                runOnUiThread(() -> appendStatus(text));
            }

            @Override
            public void onFinished(boolean success, Uri outputUri, String message) {
                runOnUiThread(() -> {
                    if (success && outputUri != null) {
                        refreshStatus(message + "\nGuardado en Galería > Movies > AnimeHDCleaner");
                    } else {
                        refreshStatus(message);
                    }
                });
            }
        });
    }

    private String summary() {
        return String.format(Locale.US,
                "Modo: %s\nBrillo %.2f | Contraste %.2f | Saturación %.2f | Gamma %.2f\nDenoise %d | Nitidez %d | Grano %d | %d FPS | %d Mbps",
                settings.preset.title,
                settings.brightness,
                settings.contrast,
                settings.saturation,
                settings.gamma,
                settings.denoise,
                settings.sharpen,
                settings.grain,
                settings.fps,
                settings.bitrateMbps
        );
    }

    private void refreshStatus(String text) {
        if (status != null) status.setText(text + "\n\n" + summary());
    }

    private void appendStatus(String line) {
        if (status == null) return;
        String old = status.getText().toString();
        String compact = line.length() > 160 ? line.substring(0, 160) + "..." : line;
        status.setText(compact + "\n" + old);
    }
}
