package com.zeta.animehdcleaner;

import java.util.Locale;

public class FilterCommandBuilder {

    public static String buildVideoFilters(EnhanceSettings s) {
        StringBuilder vf = new StringBuilder();

        vf.append("scale=1080:1920:force_original_aspect_ratio=decrease,");
        vf.append("pad=1080:1920:(ow-iw)/2:(oh-ih)/2,");
        vf.append("fps=").append(s.fps).append(",");

        if (s.denoise > 0) {
            int strength = Math.max(1, Math.min(10, s.denoise));
            vf.append("hqdn3d=")
                    .append(strength).append(":")
                    .append(strength).append(":")
                    .append(strength * 2).append(":")
                    .append(strength * 2).append(",");
        }

        vf.append(String.format(
                Locale.US,
                "eq=brightness=%.3f:contrast=%.3f:saturation=%.3f:gamma=%.3f,",
                s.brightness,
                s.contrast,
                s.saturation,
                s.gamma
        ));

        if (s.sharpen > 0) {
            float amount = 0.25f + (s.sharpen * 0.05f);
            vf.append(String.format(Locale.US, "unsharp=5:5:%.2f:3:3:0.00,", amount));
        }

        if (s.grain > 0) {
            int grainValue = Math.max(1, Math.min(10, s.grain));
            vf.append("noise=alls=").append(grainValue).append(":allf=t+u,");
        }

        vf.append("format=yuv420p");

        return vf.toString();
    }

    public static String buildCommand(String inputSaf, String outputSaf, EnhanceSettings s) {
        String vf = buildVideoFilters(s);
        int videoBitrate = Math.max(8, Math.min(15, s.bitrateMbps)) * 1000;

        return "-y "
                + "-i " + quote(inputSaf) + " "
                + "-vf " + quote(vf) + " "
                + "-c:v libx264 -preset veryfast -profile:v high -level 4.1 "
                + "-b:v " + videoBitrate + "k "
                + "-maxrate " + videoBitrate + "k "
                + "-bufsize " + (videoBitrate * 2) + "k "
                + "-c:a aac -b:a 192k "
                + "-movflags +faststart "
                + quote(outputSaf);
    }

    private static String quote(String value) {
        return "\"" + value.replace("\"", "\\\"") + "\"";
    }
}
