# Cómo subir esto manualmente a GitHub desde tu celular

## Opción rápida

1. Descarga el ZIP.
2. Descomprímelo en tu celular.
3. Entra a GitHub.
4. Abre tu repositorio.
5. Toca `Add file`.
6. Toca `Upload files`.
7. Sube las carpetas y archivos del proyecto.
8. Guarda con mensaje: `Anime HD Cleaner V1`.
9. Entra a `Actions`.
10. Abre `Build Anime HD Cleaner APK`.
11. Toca `Run workflow`.
12. Espera que termine.
13. En `Artifacts`, descarga `AnimeHDCleaner-debug-apk`.

## Si GitHub no deja subir carpetas desde celular

Hazlo desde Chrome en modo escritorio.

## Si falla la compilación

Mándame captura exacta del error de Actions.
Lo más probable sería la dependencia de FFmpeg; si pasa, cambio esa parte por otra alternativa.
