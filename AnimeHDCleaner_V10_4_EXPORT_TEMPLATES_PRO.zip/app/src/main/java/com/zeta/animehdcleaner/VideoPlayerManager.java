package com.zeta.animehdcleaner;

import android.content.Context;
import android.net.Uri;

import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

public class VideoPlayerManager {
    private final ExoPlayer player;

    public VideoPlayerManager(Context context, PlayerView playerView) {
        player = new ExoPlayer.Builder(context).build();
        player.setRepeatMode(Player.REPEAT_MODE_ONE);
        playerView.setPlayer(player);
    }

    public void load(Uri uri) {
        player.setMediaItem(MediaItem.fromUri(uri));
        player.prepare();
    }

    public void play() {
        player.play();
    }

    public void pause() {
        player.pause();
    }

    public boolean isPlaying() {
        return player.isPlaying();
    }

    public void toggle() {
        if (player.isPlaying()) {
            player.pause();
        } else {
            player.play();
        }
    }

    public void seekBy(long ms) {
        long pos = player.getCurrentPosition();
        long dur = player.getDuration();
        long next = pos + ms;
        if (next < 0) next = 0;
        if (dur > 0 && next > dur) next = dur;
        player.seekTo(next);
    }

    public long getDuration() {
        return player.getDuration();
    }

    public long getPosition() {
        return player.getCurrentPosition();
    }

    public void release() {
        player.release();
    }
}
