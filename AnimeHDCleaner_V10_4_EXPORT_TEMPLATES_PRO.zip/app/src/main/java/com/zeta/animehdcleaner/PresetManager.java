package com.zeta.animehdcleaner;

public class PresetManager {

    public static final String[] PRESETS = {
            "Anime HD",
            "Reparacion IA",
            "Color IA",
            "Quitar ruido",
            "Sombras limpias",
            "TikTok/Reels HD",
            "IA 4K+"
    };

    public static void apply(String name, ExportSettings settings) {
        settings.modeName = name;

        if ("Anime HD".equals(name)) {
            settings.sharpen = 7;
            settings.saturation = 9;
            settings.denoise = 7;
        } else if ("Reparacion IA".equals(name)) {
            settings.sharpen = 6;
            settings.denoise = 9;
            settings.luminosity = 12;
        } else if ("Color IA".equals(name)) {
            settings.saturation = 12;
            settings.contrast = 8;
            settings.brightness = 6;
        } else if ("Quitar ruido".equals(name)) {
            settings.denoise = 12;
            settings.sharpen = 5;
        } else if ("Sombras limpias".equals(name)) {
            settings.luminosity = 16;
            settings.denoise = 8;
        } else if ("TikTok/Reels HD".equals(name)) {
            settings.width = 1080;
            settings.height = 1920;
            settings.fps = 30;
            settings.bitrateMbps = 12;
            settings.qualityName = "1080P";
            settings.saturation = 10;
            settings.sharpen = 6;
        } else if ("IA 4K+".equals(name)) {
            settings.width = 2160;
            settings.height = 3840;
            settings.fps = 30;
            settings.bitrateMbps = 35;
            settings.qualityName = "4K";
            settings.sharpen = 8;
            settings.saturation = 10;
        }
    }
}
