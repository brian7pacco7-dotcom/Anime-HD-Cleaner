package com.zeta.animehdcleaner;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

public class TimelineView extends View {

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float progress = 0.5f;

    public TimelineView(Context context) {
        super(context);
        setMinimumHeight(dp(58));
    }

    public void setProgress(float progress) {
        this.progress = Math.max(0f, Math.min(1f, progress));
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        paint.setColor(Color.rgb(18, 24, 31));
        canvas.drawRoundRect(0, 0, w, h, dp(8), dp(8), paint);

        int left = dp(42);
        int right = w - dp(42);
        int top = dp(12);
        int blockH = Math.max(dp(18), h / 3);
        int bottom = top + blockH;
        int blocks = 10;
        int blockW = Math.max(1, (right - left) / blocks);

        for (int i = 0; i < blocks; i++) {
            paint.setColor(i % 2 == 0 ? Color.rgb(50, 65, 90) : Color.rgb(63, 55, 88));
            canvas.drawRect(left + i * blockW, top, left + (i + 1) * blockW - dp(2), bottom, paint);
        }

        int waveTop = bottom + dp(5);
        int waveBottom = Math.min(h - dp(7), waveTop + dp(14));
        paint.setColor(Color.rgb(0, 160, 170));
        for (int x = left; x < right; x += dp(4)) {
            int amp = (int)(Math.abs(Math.sin(x * 0.06)) * Math.max(2, waveBottom - waveTop));
            canvas.drawLine(x, waveBottom, x, waveBottom - amp, paint);
        }

        float lineX = left + (right - left) * progress;
        paint.setColor(Color.WHITE);
        paint.setStrokeWidth(dp(2));
        canvas.drawLine(lineX, dp(4), lineX, h - dp(4), paint);

        paint.setTextSize(dp(10));
        paint.setColor(Color.WHITE);
        canvas.drawText("00:00", dp(4), dp(16), paint);
        canvas.drawText("00:16", w - dp(40), dp(16), paint);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
