package com.zeta.animehdcleaner;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

public class CompareView extends View {

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float progress = 0.5f;

    public CompareView(Context context) {
        super(context);
    }

    public void setProgress(float value) {
        progress = Math.max(0f, Math.min(1f, value));
        invalidate();
    }

    public float getProgress() {
        return progress;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int w = getWidth();
        int h = getHeight();
        float x = w * progress;

        paint.setColor(Color.argb(92, 0, 0, 0));
        canvas.drawRect(0, 0, x, h, paint);

        paint.setColor(Color.WHITE);
        paint.setStrokeWidth(dp(3));
        canvas.drawLine(x, 0, x, h, paint);

        paint.setColor(Color.WHITE);
        canvas.drawCircle(x, h / 2f, dp(20), paint);

        paint.setColor(Color.rgb(10, 10, 10));
        paint.setTextSize(dp(16));
        paint.setTextAlign(Paint.Align.CENTER);
        canvas.drawText("< >", x, h / 2f + dp(6), paint);

        paint.setTextAlign(Paint.Align.LEFT);
        paint.setColor(Color.argb(170, 0, 0, 0));
        canvas.drawRoundRect(dp(12), h - dp(56), dp(120), h - dp(14), dp(6), dp(6), paint);
        canvas.drawRoundRect(w - dp(132), h - dp(56), w - dp(12), h - dp(14), dp(6), dp(6), paint);

        paint.setColor(Color.WHITE);
        paint.setTextSize(dp(18));
        paint.setFakeBoldText(true);
        canvas.drawText("Original", dp(24), h - dp(28), paint);
        canvas.drawText("Despues", w - dp(118), h - dp(28), paint);
        paint.setFakeBoldText(false);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN || event.getAction() == MotionEvent.ACTION_MOVE) {
            if (getWidth() > 0) {
                setProgress(event.getX() / getWidth());
            }
            return true;
        }
        return true;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
