package com.zeta.animehdcleaner;

public class TemplateManager {

    public static final String[] TEMPLATES = {
            "Reels Anime HD",
            "Anime Noche",
            "Sombras Limpias",
            "Color Viral",
            "WhatsApp HD",
            "Comparacion Antes/Despues"
    };

    public static void apply(String templateName, ExportSettings settings) {
        settings.modeName = templateName;

        if ("Reels Anime HD".equals(templateName)) {
            settings.qualityName = "1080P";
            settings.width = 1080;
            settings.height = 1920;
            settings.fps = 30;
            settings.bitrateMbps = 12;
            settings.brightness = 5;
            settings.contrast = 6;
            settings.saturation = 11;
            settings.luminosity = 10;
            settings.sharpen = 7;
            settings.denoise = 6;
        } else if ("Anime Noche".equals(templateName)) {
            settings.qualityName = "1080P";
            settings.width = 1080;
            settings.height = 1920;
            settings.fps = 30;
            settings.bitrateMbps = 13;
            settings.brightness = 6;
            settings.contrast = 7;
            settings.saturation = 9;
            settings.luminosity = 16;
            settings.sharpen = 6;
            settings.denoise = 9;
        } else if ("Sombras Limpias".equals(templateName)) {
            settings.qualityName = "1080P";
            settings.width = 1080;
            settings.height = 1920;
            settings.fps = 30;
            settings.bitrateMbps = 12;
            settings.brightness = 5;
            settings.contrast = 6;
            settings.saturation = 9;
            settings.luminosity = 18;
            settings.sharpen = 5;
            settings.denoise = 10;
        } else if ("Color Viral".equals(templateName)) {
            settings.qualityName = "1080P";
            settings.width = 1080;
            settings.height = 1920;
            settings.fps = 30;
            settings.bitrateMbps = 14;
            settings.brightness = 5;
            settings.contrast = 8;
            settings.saturation = 15;
            settings.luminosity = 12;
            settings.sharpen = 7;
            settings.denoise = 5;
        } else if ("WhatsApp HD".equals(templateName)) {
            settings.qualityName = "720P";
            settings.width = 720;
            settings.height = 1280;
            settings.fps = 30;
            settings.bitrateMbps = 7;
            settings.brightness = 4;
            settings.contrast = 5;
            settings.saturation = 9;
            settings.luminosity = 10;
            settings.sharpen = 5;
            settings.denoise = 6;
        } else if ("Comparacion Antes/Despues".equals(templateName)) {
            settings.qualityName = "1080P";
            settings.width = 1080;
            settings.height = 1920;
            settings.fps = 30;
            settings.bitrateMbps = 12;
            settings.brightness = 4;
            settings.contrast = 6;
            settings.saturation = 10;
            settings.luminosity = 10;
            settings.sharpen = 7;
            settings.denoise = 7;
        }
    }
}
