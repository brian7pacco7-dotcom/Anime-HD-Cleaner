package com.zeta.animehdcleaner;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

public class HistoryActivity extends Activity {

    private final int bg = 0xFF090D12;
    private final int panel = 0xFF12181F;
    private final int white = 0xFFFFFFFF;
    private final int muted = 0xFFB0B5BC;
    private final int cyan = 0xFF11D2FF;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        build();
    }

    private void build() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(bg);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(28), dp(16), dp(16));
        scroll.addView(root);

        TextView title = text("Historial de exportaciones", 24, true, white);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        Button clear = new Button(this);
        clear.setText("Limpiar historial");
        clear.setAllCaps(false);
        root.addView(clear, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
        clear.setOnClickListener(v -> {
            HistoryManager.clear(this);
            Toast.makeText(this, "Historial limpio", Toast.LENGTH_SHORT).show();
            build();
        });

        JSONArray array = HistoryManager.get(this);
        if (array.length() == 0) {
            TextView empty = text("Todavia no hay exportaciones guardadas.", 16, false, muted);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, dp(40), 0, 0);
            root.addView(empty);
        }

        for (int i = 0; i < array.length(); i++) {
            try {
                JSONObject item = array.getJSONObject(i);
                LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(dp(12), dp(12), dp(12), dp(12));
                card.setBackgroundColor(panel);

                String info = item.optString("date") + "\n"
                        + "Preset: " + item.optString("preset") + "\n"
                        + "Calidad: " + item.optString("quality") + " · " + item.optInt("fps") + " FPS · " + item.optInt("bitrate") + " Mbps\n"
                        + "Resolucion: " + item.optString("resolution") + "\n"
                        + "Peso original: " + item.optString("originalSize") + "\n"
                        + "Peso estimado: " + item.optString("estimatedSize");

                card.addView(text(info, 14, false, white));

                LinearLayout buttons = new LinearLayout(this);
                buttons.setOrientation(LinearLayout.HORIZONTAL);
                buttons.setPadding(0, dp(8), 0, 0);
                card.addView(buttons);

                String uriText = item.optString("uri");

                Button open = new Button(this);
                open.setText("Abrir");
                open.setAllCaps(false);
                buttons.addView(open, new LinearLayout.LayoutParams(0, dp(44), 1f));
                open.setOnClickListener(v -> openVideo(uriText));

                Button share = new Button(this);
                share.setText("Compartir");
                share.setAllCaps(false);
                buttons.addView(share, new LinearLayout.LayoutParams(0, dp(44), 1f));
                share.setOnClickListener(v -> shareVideo(uriText));

                LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                cp.topMargin = dp(10);
                root.addView(card, cp);
            } catch (Exception ignored) {
            }
        }

        Button back = new Button(this);
        back.setText("Volver");
        back.setAllCaps(false);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        bp.topMargin = dp(14);
        root.addView(back, bp);
        back.setOnClickListener(v -> finish());

        setContentView(scroll);
    }

    private void openVideo(String uriText) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(Uri.parse(uriText), "video/mp4");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo abrir el video", Toast.LENGTH_SHORT).show();
        }
    }

    private void shareVideo(String uriText) {
        try {
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("video/mp4");
            intent.putExtra(Intent.EXTRA_STREAM, Uri.parse(uriText));
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intent, "Compartir video"));
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo compartir el video", Toast.LENGTH_SHORT).show();
        }
    }

    private TextView text(String value, int size, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(color);
        t.setTextSize(size);
        if (bold) t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        return t;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
