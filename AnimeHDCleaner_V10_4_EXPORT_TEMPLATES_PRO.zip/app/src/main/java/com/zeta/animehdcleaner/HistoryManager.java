package com.zeta.animehdcleaner;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class HistoryManager {
    private static final String PREF = "export_history";
    private static final String KEY = "items";

    public static void add(Context context, Uri uri, ExportSettings settings, VideoInfo originalInfo) {
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
            JSONArray array = new JSONArray(prefs.getString(KEY, "[]"));

            JSONObject item = new JSONObject();
            item.put("date", new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US).format(new Date()));
            item.put("uri", uri == null ? "" : uri.toString());
            item.put("preset", settings.modeName);
            item.put("quality", settings.qualityName);
            item.put("fps", settings.fps);
            item.put("bitrate", settings.bitrateMbps);
            item.put("resolution", settings.width + "x" + settings.height);
            item.put("originalSize", originalInfo == null ? "No disponible" : originalInfo.sizeText());
            item.put("estimatedSize", originalInfo == null ? "No disponible" : originalInfo.estimatedOutputSize(settings));

            JSONArray next = new JSONArray();
            next.put(item);
            for (int i = 0; i < array.length() && i < 9; i++) {
                next.put(array.getJSONObject(i));
            }

            prefs.edit().putString(KEY, next.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    public static JSONArray get(Context context) {
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
            return new JSONArray(prefs.getString(KEY, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    public static void clear(Context context) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().remove(KEY).apply();
    }
}
