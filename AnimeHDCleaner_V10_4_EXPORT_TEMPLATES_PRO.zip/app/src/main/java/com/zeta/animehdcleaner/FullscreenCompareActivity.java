package com.zeta.animehdcleaner;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.media3.ui.PlayerView;

public class FullscreenCompareActivity extends Activity {

    private VideoPlayerManager playerManager;
    private CompareView compareView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String uriText = getIntent().getStringExtra("video_uri");
        String title = getIntent().getStringExtra("title");
        float progress = getIntent().getFloatExtra("compare_progress", 0.5f);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF121214);
        root.setPadding(dp(12), dp(18), dp(12), dp(18));

        TextView back = text("Volver", 18, true);
        back.setOnClickListener(v -> finish());
        root.addView(back);

        TextView titleView = text(title == null ? "Antes / Despues" : title, 24, true);
        titleView.setGravity(Gravity.CENTER);
        root.addView(titleView);

        TextView hint = text("Mueve la regla o la barra inferior", 14, false);
        hint.setTextColor(0xFFB0B5BC);
        hint.setGravity(Gravity.CENTER);
        root.addView(hint);

        FrameLayout preview = new FrameLayout(this);
        preview.setBackgroundColor(0xFF000000);
        root.addView(preview, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(600)));

        PlayerView playerView = new PlayerView(this);
        playerView.setUseController(false);
        preview.addView(playerView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        compareView = new CompareView(this);
        compareView.setProgress(progress);
        preview.addView(compareView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        SeekBar slider = new SeekBar(this);
        slider.setMax(100);
        slider.setProgress((int)(progress * 100));
        root.addView(slider);
        slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int p, boolean fromUser) {
                compareView.setProgress(p / 100f);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        setContentView(root);

        playerManager = new VideoPlayerManager(this, playerView);
        if (uriText != null) {
            playerManager.load(Uri.parse(uriText));
            playerManager.play();
        }
    }

    private TextView text(String value, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(size);
        if (bold) t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        return t;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (playerManager != null) playerManager.pause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (playerManager != null) playerManager.release();
    }
}
