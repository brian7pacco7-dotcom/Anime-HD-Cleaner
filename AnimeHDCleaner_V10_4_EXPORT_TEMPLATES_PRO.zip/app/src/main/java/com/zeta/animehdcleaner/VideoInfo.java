package com.zeta.animehdcleaner;

import android.content.Context;
import android.database.Cursor;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.provider.OpenableColumns;

public class VideoInfo {
    public long sizeBytes = -1;
    public long durationMs = -1;
    public int width = -1;
    public int height = -1;
    public int bitrate = -1;
    public String fileName = "video";

    public static VideoInfo read(Context context, Uri uri) {
        VideoInfo info = new VideoInfo();

        try (Cursor cursor = context.getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                int sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE);
                if (nameIndex >= 0) info.fileName = cursor.getString(nameIndex);
                if (sizeIndex >= 0) info.sizeBytes = cursor.getLong(sizeIndex);
            }
        } catch (Exception ignored) {
        }

        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(context, uri);

            String duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            String width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH);
            String height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT);
            String bitrate = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE);

            if (duration != null) info.durationMs = Long.parseLong(duration);
            if (width != null) info.width = Integer.parseInt(width);
            if (height != null) info.height = Integer.parseInt(height);
            if (bitrate != null) info.bitrate = Integer.parseInt(bitrate);
        } catch (Exception ignored) {
        } finally {
            try {
                retriever.release();
            } catch (Exception ignored) {
            }
        }

        return info;
    }

    public String sizeText() {
        if (sizeBytes <= 0) return "No disponible";
        double mb = sizeBytes / 1024.0 / 1024.0;
        return String.format(java.util.Locale.US, "%.1f MB", mb);
    }

    public String durationText() {
        if (durationMs <= 0) return "No disponible";
        long totalSeconds = durationMs / 1000;
        long min = totalSeconds / 60;
        long sec = totalSeconds % 60;
        return String.format(java.util.Locale.US, "%02d:%02d", min, sec);
    }

    public String resolutionText() {
        if (width <= 0 || height <= 0) return "No disponible";
        return width + "x" + height;
    }

    public String bitrateText() {
        if (bitrate <= 0) return "No disponible";
        double mbps = bitrate / 1000000.0;
        return String.format(java.util.Locale.US, "%.1f Mbps", mbps);
    }

    public String estimatedOutputSize(ExportSettings settings) {
        if (durationMs <= 0) return "No disponible";
        double seconds = durationMs / 1000.0;
        double mb = (settings.bitrateMbps * seconds) / 8.0;
        return String.format(java.util.Locale.US, "%.1f MB aprox.", mb);
    }
}
