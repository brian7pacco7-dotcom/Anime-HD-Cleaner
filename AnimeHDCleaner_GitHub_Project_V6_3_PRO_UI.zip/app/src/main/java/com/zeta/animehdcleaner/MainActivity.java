package com.zeta.animehdcleaner;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

public class MainActivity extends Activity {

    private static final int REQ_PICK_VIDEO = 1001;

    private Uri selectedVideo;
    private ExoPlayer player;
    private PlayerView playerView;

    private final ExportSettings settings = new ExportSettings();

    private String activeMode = "Reparación IA";
    private String activeQuality = "1080p";
    private int compareProgress = 50;

    private TextView titleHero;
    private TextView subtitleHero;
    private TextView fileInfo;
    private TextView applyInfo;
    private TextView qualityInfo;
    private TextView status;
    private LinearLayout modeGrid;
    private LinearLayout qualityRow;

    private FrameLayout previewFrame;
    private View afterOverlay;
    private View divider;
    private TextView handle;
    private SeekBar compareSeek;

    private final int dark = Color.rgb(28, 28, 31);
    private final int black = Color.rgb(5, 5, 8);
    private final int white = Color.WHITE;
    private final int softPanel = Color.rgb(243, 243, 248);
    private final int softCard = Color.rgb(250, 250, 252);
    private final int muted = Color.rgb(170, 170, 178);
    private final int pink = Color.rgb(242, 211, 214);
    private final int sky = Color.rgb(44, 201, 255);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initDefaults();
        buildUi();
        preparePlayer();
        refreshTexts();
    }

    private void initDefaults() {
        settings.modeName = activeMode;
        settings.qualityName = activeQuality;
        settings.width = 1080;
        settings.height = 1920;
        settings.fps = 30;
        settings.bitrateMbps = 12;
        settings.shadows = 12;
        settings.denoise = 8;
        settings.sharpen = 5;
        settings.saturation = 8;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(dark);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(18), dp(16), dp(18));
        scroll.addView(root);

        TextView back = new TextView(this);
        back.setText("‹");
        back.setTextColor(white);
        back.setTextSize(40);
        root.addView(back);

        titleHero = new TextView(this);
        titleHero.setTextColor(white);
        titleHero.setTextSize(25);
        titleHero.setTypeface(Typeface.DEFAULT_BOLD);
        titleHero.setGravity(Gravity.CENTER);
        root.addView(titleHero);

        subtitleHero = new TextView(this);
        subtitleHero.setTextColor(muted);
        subtitleHero.setTextSize(15);
        subtitleHero.setGravity(Gravity.CENTER);
        subtitleHero.setPadding(0, dp(8), 0, dp(14));
        root.addView(subtitleHero);

        previewFrame = new FrameLayout(this);
        previewFrame.setBackgroundColor(Color.BLACK);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(460));
        pp.setMargins(0, 0, 0, dp(12));
        root.addView(previewFrame, pp);

        playerView = new PlayerView(this);
        playerView.setUseController(true);
        playerView.setControllerAutoShow(true);
        previewFrame.addView(playerView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));

        afterOverlay = new View(this);
        afterOverlay.setBackgroundColor(Color.argb(44, 255, 255, 255));
        previewFrame.addView(afterOverlay, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));

        divider = new View(this);
        divider.setBackgroundColor(Color.WHITE);
        previewFrame.addView(divider, new FrameLayout.LayoutParams(dp(3),
                FrameLayout.LayoutParams.MATCH_PARENT));

        handle = bubble("◀ ▶");
        previewFrame.addView(handle, new FrameLayout.LayoutParams(dp(66), dp(66)));

        TextView before = sideLabel("Before", Gravity.LEFT);
        FrameLayout.LayoutParams beforeP = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.LEFT);
        beforeP.setMargins(dp(22), 0, 0, dp(18));
        previewFrame.addView(before, beforeP);

        TextView after = sideLabel("After", Gravity.RIGHT);
        FrameLayout.LayoutParams afterP = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.RIGHT);
        afterP.setMargins(0, 0, dp(22), dp(18));
        previewFrame.addView(after, afterP);

        compareSeek = new SeekBar(this);
        compareSeek.setMax(100);
        compareSeek.setProgress(compareProgress);
        compareSeek.setPadding(dp(8), 0, dp(8), dp(4));
        root.addView(compareSeek);
        compareSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                compareProgress = progress;
                updateCompareViews();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        TextView compareTip = new TextView(this);
        compareTip.setText("Desliza para comparar Antes / Después");
        compareTip.setTextColor(muted);
        compareTip.setTextSize(12);
        compareTip.setGravity(Gravity.CENTER);
        root.addView(compareTip);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.addView(actionButton("Importar", v -> pickVideo()));
        actions.addView(actionButton("Pantalla completa", v -> openFullscreen()));
        actions.addView(actionButton("Exportar", v -> showExportDialog()));
        root.addView(actions);

        fileInfo = new TextView(this);
        fileInfo.setTextColor(muted);
        fileInfo.setTextSize(12);
        fileInfo.setPadding(0, dp(10), 0, dp(14));
        root.addView(fileInfo);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(softPanel);
        panel.setPadding(dp(12), dp(16), dp(12), dp(18));
        root.addView(panel);

        TextView qualityTitle = panelTitle("Quality Restoration");
        panel.addView(qualityTitle);

        qualityInfo = cardText();
        panel.addView(qualityInfo);

        applyInfo = cardText();
        panel.addView(applyInfo);

        modeGrid = new LinearLayout(this);
        modeGrid.setOrientation(LinearLayout.VERTICAL);
        panel.addView(modeGrid);
        rebuildModeGrid();

        TextView exportTitle = panelTitle("Exportación");
        panel.addView(exportTitle);

        HorizontalScrollView qScroll = new HorizontalScrollView(this);
        qScroll.setHorizontalScrollBarEnabled(false);
        qualityRow = new LinearLayout(this);
        qualityRow.setOrientation(LinearLayout.HORIZONTAL);
        qScroll.addView(qualityRow);
        panel.addView(qScroll);
        rebuildQualityRow();

        TextView manualTitle = panelTitle("Ajustes manuales");
        panel.addView(manualTitle);

        addSlider(panel, "Sombras", 0, 20, settings.shadows, v -> {
            settings.shadows = v;
            refreshTexts();
        });
        addSlider(panel, "Denoise", 0, 10, settings.denoise, v -> {
            settings.denoise = v;
            refreshTexts();
        });
        addSlider(panel, "Nitidez", 0, 10, settings.sharpen, v -> {
            settings.sharpen = v;
            refreshTexts();
        });
        addSlider(panel, "Color", 0, 15, settings.saturation, v -> {
            settings.saturation = v;
            refreshTexts();
        });

        Button exportNow = new Button(this);
        exportNow.setText("Probar ahora / Exportar HD");
        exportNow.setTextSize(18);
        exportNow.setTypeface(Typeface.DEFAULT_BOLD);
        exportNow.setTextColor(Color.BLACK);
        exportNow.setAllCaps(false);
        exportNow.setBackgroundColor(pink);
        LinearLayout.LayoutParams epp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(60));
        epp.setMargins(dp(2), dp(14), dp(2), dp(8));
        exportNow.setLayoutParams(epp);
        exportNow.setOnClickListener(v -> showExportDialog());
        panel.addView(exportNow);

        status = new TextView(this);
        status.setTextColor(Color.BLACK);
        status.setTextSize(13);
        status.setPadding(dp(6), dp(8), dp(6), 0);
        panel.addView(status);

        setContentView(scroll);

        previewFrame.post(this::updateCompareViews);
    }

    private LinearLayout actionButton(String text, View.OnClickListener click) {
        LinearLayout wrapper = new LinearLayout(this);
        wrapper.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams w = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        w.setMargins(dp(4), dp(8), dp(4), dp(8));
        wrapper.setLayoutParams(w);

        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setBackgroundColor(Color.BLACK);
        b.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(52)));
        b.setOnClickListener(click);
        wrapper.addView(b);
        return wrapper;
    }

    private TextView bubble(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setGravity(Gravity.CENTER);
        v.setTextColor(Color.DKGRAY);
        v.setTextSize(13);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setBackgroundColor(Color.argb(235, 255, 255, 255));
        return v;
    }

    private TextView sideLabel(String t, int side) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextColor(Color.WHITE);
        v.setTextSize(18);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setShadowLayer(5, 0, 0, Color.BLACK);
        v.setGravity(side);
        return v;
    }

    private TextView panelTitle(String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(18);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setTextColor(Color.BLACK);
        v.setPadding(dp(2), dp(8), dp(2), dp(8));
        return v;
    }

    private TextView cardText() {
        TextView v = new TextView(this);
        v.setTextColor(Color.BLACK);
        v.setTextSize(13);
        v.setBackgroundColor(softCard);
        v.setPadding(dp(10), dp(10), dp(10), dp(10));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(dp(2), dp(4), dp(2), dp(8));
        v.setLayoutParams(p);
        return v;
    }

    private void rebuildModeGrid() {
        modeGrid.removeAllViews();

        LinearLayout r1 = new LinearLayout(this);
        r1.setOrientation(LinearLayout.HORIZONTAL);
        r1.addView(modeCard("Reparación IA", "HD AI", () -> {
            activeMode = "Reparación IA";
            settings.modeName = activeMode;
            settings.shadows = 12; settings.denoise = 8; settings.sharpen = 5; settings.saturation = 8;
            titleHero.setText("✨ Reparación IA ✨");
            subtitleHero.setText("Reduce ruido, mejora sombras, color y nitidez.");
            refreshTexts();
        }));
        r1.addView(modeCard("Ultra HD", "HD+", () -> {
            activeMode = "Ultra HD";
            settings.modeName = activeMode;
            settings.shadows = 10; settings.denoise = 6; settings.sharpen = 8; settings.saturation = 9;
            setQuality("4K", 2160, 3840, 30, 35, false);
            titleHero.setText("✨ Ultra HD ✨");
            subtitleHero.setText("Más nitidez visual y salida avanzada hasta 4K.");
            refreshTexts();
        }));
        r1.addView(modeCard("Anime HD", "ANI", () -> {
            activeMode = "Anime HD";
            settings.modeName = activeMode;
            settings.shadows = 10; settings.denoise = 8; settings.sharpen = 7; settings.saturation = 8;
            titleHero.setText("✨ Anime HD ✨");
            subtitleHero.setText("Líneas más limpias, menos manchas y mejor color para anime.");
            refreshTexts();
        }));
        modeGrid.addView(r1);

        LinearLayout r2 = new LinearLayout(this);
        r2.setOrientation(LinearLayout.HORIZONTAL);
        r2.addView(modeCard("Color IA", "CLR", () -> {
            activeMode = "Color IA";
            settings.modeName = activeMode;
            settings.saturation = 12; settings.sharpen = 4; settings.denoise = 5;
            titleHero.setText("✨ Color IA ✨");
            subtitleHero.setText("Mejora color, brillo visual y contraste.");
            refreshTexts();
        }));
        r2.addView(modeCard("Quitar ruido", "NR", () -> {
            activeMode = "Quitar ruido";
            settings.modeName = activeMode;
            settings.denoise = 10; settings.shadows = 9; settings.sharpen = 4;
            titleHero.setText("✨ Quitar ruido ✨");
            subtitleHero.setText("Reduce bloques, ruido y zonas feas del video.");
            refreshTexts();
        }));
        r2.addView(modeCard("Sombras", "SHD", () -> {
            activeMode = "Sombras";
            settings.modeName = activeMode;
            settings.shadows = 16; settings.denoise = 8; settings.sharpen = 4;
            titleHero.setText("✨ Sombras limpias ✨");
            subtitleHero.setText("Recupera detalle en zonas oscuras y negros.");
            refreshTexts();
        }));
        modeGrid.addView(r2);
    }

    private View modeCard(String name, String icon, Runnable action) {
        boolean active = activeMode.equals(name);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setBackgroundColor(active ? Color.WHITE : softCard);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(104), 1);
        p.setMargins(dp(4), dp(4), dp(4), dp(4));
        box.setLayoutParams(p);
        box.setPadding(dp(6), dp(8), dp(6), dp(8));

        TextView top = new TextView(this);
        top.setText((active ? "✓ " : "") + icon);
        top.setTextColor(Color.BLACK);
        top.setTypeface(Typeface.DEFAULT_BOLD);
        top.setTextSize(18);
        top.setGravity(Gravity.CENTER);
        box.addView(top);

        TextView txt = new TextView(this);
        txt.setText(name);
        txt.setTextColor(Color.BLACK);
        txt.setTextSize(12);
        txt.setGravity(Gravity.CENTER);
        box.addView(txt);

        box.setOnClickListener(v -> {
            action.run();
            rebuildModeGrid();
            setStatus("Modo activo: ✓ " + activeMode);
        });
        return box;
    }

    private void rebuildQualityRow() {
        qualityRow.removeAllViews();
        qualityRow.addView(qualityCard("720p", 720, 1280, 30, 8));
        qualityRow.addView(qualityCard("1080p", 1080, 1920, 30, 12));
        qualityRow.addView(qualityCard("1080p 60", 1080, 1920, 60, 15));
        qualityRow.addView(qualityCard("2K", 1440, 2560, 30, 20));
        qualityRow.addView(qualityCard("4K", 2160, 3840, 30, 35));
    }

    private View qualityCard(String name, int w, int h, int fps, int mbps) {
        boolean active = activeQuality.equals(name);
        TextView v = new TextView(this);
        v.setText((active ? "✓ " : "") + name + "\n" + fps + " FPS\n" + mbps + " Mbps");
        v.setGravity(Gravity.CENTER);
        v.setTextSize(13);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setTextColor(active ? Color.WHITE : Color.BLACK);
        v.setBackgroundColor(active ? Color.BLACK : Color.WHITE);
        v.setPadding(dp(10), dp(8), dp(10), dp(8));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(108), dp(86));
        p.setMargins(dp(4), dp(6), dp(4), dp(8));
        v.setLayoutParams(p);
        v.setOnClickListener(view -> setQuality(name, w, h, fps, mbps, true));
        return v;
    }

    private void setQuality(String name, int w, int h, int fps, int mbps, boolean toast) {
        activeQuality = name;
        settings.qualityName = name;
        settings.width = w;
        settings.height = h;
        settings.fps = fps;
        settings.bitrateMbps = mbps;
        rebuildQualityRow();
        refreshTexts();
        if (toast) Toast.makeText(this, "✓ " + name, Toast.LENGTH_SHORT).show();
    }

    private void refreshTexts() {
        fileInfo.setText(selectedVideo == null
                ? "MP4, MOV, MKV, WEBM, AVI, 3GP y video/*"
                : "Video cargado: " + getFileName(selectedVideo));

        qualityInfo.setText(
                "Vista de mejora profesional\n" +
                "• Modo activo: ✓ " + activeMode + "\n" +
                "• Calidad activa: ✓ " + activeQuality + "\n" +
                "• Salida: " + settings.width + "x" + settings.height + " · " + settings.fps + " FPS · " + settings.bitrateMbps + " Mbps\n" +
                "• Lo notarás más en nitidez, sombras y limpieza al exportar.");

        applyInfo.setText(
                "Cambios que sí se aplican\n" +
                "• Sombras: " + settings.shadows + "\n" +
                "• Denoise: " + settings.denoise + "\n" +
                "• Nitidez: " + settings.sharpen + "\n" +
                "• Color: " + settings.saturation + "\n" +
                "• Estos ajustes se guardan para la exportación HD.");

        setStatus("Listo para exportar con " + activeMode + " en " + activeQuality + ".");
    }

    private void updateCompareViews() {
        if (previewFrame == null || previewFrame.getWidth() == 0) return;

        int w = previewFrame.getWidth();
        int h = previewFrame.getHeight();
        int x = (int) (w * (compareProgress / 100f));

        FrameLayout.LayoutParams overlayP = (FrameLayout.LayoutParams) afterOverlay.getLayoutParams();
        overlayP.width = Math.max(0, w - x);
        overlayP.height = h;
        overlayP.gravity = Gravity.RIGHT;
        afterOverlay.setLayoutParams(overlayP);

        FrameLayout.LayoutParams divP = (FrameLayout.LayoutParams) divider.getLayoutParams();
        divP.width = dp(3);
        divP.height = h;
        divP.leftMargin = Math.max(0, x - dp(1));
        divider.setLayoutParams(divP);

        FrameLayout.LayoutParams handleP = (FrameLayout.LayoutParams) handle.getLayoutParams();
        handleP.width = dp(66);
        handleP.height = dp(66);
        handleP.leftMargin = Math.max(0, x - dp(33));
        handleP.topMargin = Math.max(0, h / 2 - dp(33));
        handle.setLayoutParams(handleP);
    }

    private void showExportDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Exportación HD")
                .setMessage(
                        "Activo:\n✓ " + activeMode + "\n✓ " + activeQuality +
                        "\n\nCómo sabrás que se aplica:\n" +
                        "• Los valores mostrados se guardan para exportar.\n" +
                        "• Se usará MP4 H.264.\n" +
                        "• La mejora se verá más en el archivo exportado.\n\n" +
                        "Salida:\n" + settings.width + "x" + settings.height +
                        " · " + settings.fps + " FPS · " + settings.bitrateMbps + " Mbps")
                .setPositiveButton("Exportar ahora", (d, w) -> exportHd())
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void exportHd() {
        if (selectedVideo == null) {
            setStatus("Primero importa un video.");
            return;
        }

        setStatus("Exportando... no cierres la app.");
        RealHdExporter.export(this, selectedVideo, settings, new RealHdExporter.Listener() {
            @Override
            public void onLog(String message) {
                runOnUiThread(() -> setStatus(message));
            }

            @Override
            public void onFinished(boolean success, Uri outputUri, String message) {
                runOnUiThread(() -> {
                    setStatus(message + "\nGuardado en Movies/AnimeHDCleaner");
                    Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void openFullscreen() {
        if (selectedVideo == null) {
            Toast.makeText(this, "Primero importa un video.", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(this, FullscreenCompareActivity.class);
        i.putExtra("video_uri", selectedVideo.toString());
        i.putExtra("title", titleHero.getText().toString());
        i.putExtra("subtitle", subtitleHero.getText().toString());
        startActivity(i);
    }

    private void pickVideo() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("video/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {
                "video/mp4", "video/quicktime", "video/x-matroska", "video/webm",
                "video/x-msvideo", "video/3gpp", "video/x-ms-wmv", "video/*"
        });
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, REQ_PICK_VIDEO);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PICK_VIDEO && resultCode == RESULT_OK && data != null) {
            selectedVideo = data.getData();
            if (selectedVideo != null) {
                try {
                    getContentResolver().takePersistableUriPermission(selectedVideo, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Exception ignored) {}

                player.setMediaItem(MediaItem.fromUri(selectedVideo));
                player.prepare();
                player.play();

                refreshTexts();
            }
        }
    }

    private String getFileName(Uri uri) {
        String result = "video seleccionado";
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) result = cursor.getString(index);
            }
        } catch (Exception ignored) {}
        return result;
    }

    private void preparePlayer() {
        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        player.setRepeatMode(Player.REPEAT_MODE_ONE);
    }

    private void setStatus(String text) {
        if (status != null) status.setText(text);
    }

    private interface Change { void set(int value); }

    private void addSlider(LinearLayout parent, String name, int min, int max, int value, Change change) {
        TextView label = new TextView(this);
        label.setText(name + ": " + value);
        label.setTextColor(Color.BLACK);
        label.setTextSize(13);
        label.setPadding(dp(4), dp(8), dp(4), 0);
        parent.addView(label);

        SeekBar seek = new SeekBar(this);
        seek.setMax(max - min);
        seek.setProgress(value - min);
        parent.addView(seek);

        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                int real = min + progress;
                label.setText(name + ": " + real);
                change.set(real);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                refreshTexts();
            }
        });
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (player != null) player.pause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (player != null) {
            player.release();
            player = null;
        }
    }
}
