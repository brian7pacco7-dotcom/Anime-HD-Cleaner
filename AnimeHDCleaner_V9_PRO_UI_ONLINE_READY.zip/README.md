# Anime HD Cleaner V9 PRO UI ONLINE READY

Version enfocada en interfaz profesional tipo editor.

## Tiene

- Interfaz oscura tipo editor.
- Boton Importar video.
- Reproductor con controles -5s, Play/Pausa, +5s y pantalla.
- Timeline visual simple.
- Panel Mejoras IA:
  - Anime HD
  - Reparacion IA
  - Color IA
  - Quitar ruido
  - Sombras
  - IA Online
  - IA 4K+
- Ajustes manuales compactos:
  - Brillo
  - Contraste
  - Saturacion
  - Luminosidad
  - Enfocar
  - Ruido
- Probar ahora con carga y Antes/Despues.
- Exportar sin marca de agua a Movies/AnimeHDCleaner.
- GitHub Actions incluido.

## Importante sobre IA online

La app esta preparada para internet y servidor IA.
Para IA real online debes colocar tu endpoint en:

app/src/main/java/com/zeta/animehdcleaner/OnlineAiService.java

Por defecto queda vacio para que compile sin fallas ni claves privadas.
