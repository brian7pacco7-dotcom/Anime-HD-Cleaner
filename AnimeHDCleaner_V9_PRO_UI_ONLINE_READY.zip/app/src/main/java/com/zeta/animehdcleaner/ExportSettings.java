package com.zeta.animehdcleaner;

public class ExportSettings {
    public String modeName = "Anime HD";
    public String qualityName = "1080P";
    public int width = 1080;
    public int height = 1920;
    public int fps = 30;
    public int bitrateMbps = 12;

    public int brightness = 4;
    public int contrast = 4;
    public int saturation = 9;
    public int luminosity = 10;
    public int sharpen = 7;
    public int denoise = 7;

    public boolean onlineAi = false;

    public String summary() {
        return "Funcion: " + modeName + "\n"
                + "Calidad: " + qualityName + "\n"
                + "Salida: " + width + "x" + height + " | " + fps + " FPS | " + bitrateMbps + " Mbps\n"
                + "Ajustes: brillo " + brightness
                + ", contraste " + contrast
                + ", saturacion " + saturation
                + ", luminosidad " + luminosity
                + ", enfoque " + sharpen
                + ", ruido " + denoise + "\n"
                + "IA online: " + (onlineAi ? "activada si hay servidor configurado" : "desactivada") + "\n"
                + "Formato: MP4 H.264 | sin marca de agua";
    }
}
