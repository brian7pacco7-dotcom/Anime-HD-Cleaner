package com.zeta.animehdcleaner;

public class OnlineAiService {
    // Coloca aqui tu servidor real de IA si luego contratas o creas uno.
    // Ejemplo: https://tu-servidor.com/api/enhance
    public static final String AI_ENDPOINT = "";

    public static boolean isConfigured() {
        return AI_ENDPOINT != null && AI_ENDPOINT.startsWith("http");
    }
}
