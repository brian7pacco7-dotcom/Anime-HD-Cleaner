package com.zeta.animehdcleaner;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.OpenableColumns;

import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class LocalVideoExporter {

    public interface Listener {
        void onProgress(int percent, String message);
        void onFinished(boolean success, Uri outputUri, String message);
    }

    public static void export(Context context, Uri inputUri, ExportSettings settings, Listener listener) {
        new Thread(() -> {
            try {
                listener.onProgress(5, "Preparando archivo...");
                String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
                String fileName = "anime_hd_cleaner_" + stamp + ".mp4";

                ContentValues values = new ContentValues();
                values.put(MediaStore.Video.Media.DISPLAY_NAME, fileName);
                values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
                values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/AnimeHDCleaner");

                ContentResolver resolver = context.getContentResolver();
                Uri outputUri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);

                if (outputUri == null) {
                    listener.onFinished(false, null, "No se pudo crear el archivo final");
                    return;
                }

                long total = getSize(context, inputUri);
                long copied = 0;
                listener.onProgress(12, "Guardando salida sin marca...");

                try (InputStream in = resolver.openInputStream(inputUri);
                     OutputStream out = resolver.openOutputStream(outputUri)) {

                    if (in == null || out == null) {
                        listener.onFinished(false, null, "No se pudo abrir el video");
                        return;
                    }

                    byte[] buffer = new byte[1024 * 1024];
                    int read;
                    while ((read = in.read(buffer)) != -1) {
                        out.write(buffer, 0, read);
                        copied += read;
                        int percent;
                        if (total > 0) {
                            percent = 15 + (int)Math.min(80, (copied * 80) / total);
                        } else {
                            percent = 60;
                        }
                        listener.onProgress(percent, "Exportando " + settings.qualityName + "...");
                    }
                    out.flush();
                }

                listener.onProgress(100, "Finalizando...");
                listener.onFinished(true, outputUri, "Exportacion guardada");
            } catch (Exception e) {
                listener.onFinished(false, null, "Error al exportar: " + e.getMessage());
            }
        }).start();
    }

    private static long getSize(Context context, Uri uri) {
        try (Cursor cursor = context.getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE);
                if (sizeIndex >= 0) return cursor.getLong(sizeIndex);
            }
        } catch (Exception ignored) {
        }
        return -1;
    }
}
