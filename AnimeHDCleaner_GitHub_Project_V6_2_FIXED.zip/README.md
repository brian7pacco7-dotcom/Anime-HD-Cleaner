# Anime HD Cleaner V6.2 FIXED

Corrección de la V6.1.

## Error corregido

GitHub Actions fallaba en:

`cannot find symbol: class Effects`

## Solución

Se corrigió el import de `Effects` para Media3 1.4.1:

- Antes: `androidx.media3.common.Effects`
- Ahora: `androidx.media3.transformer.Effects`

## Mantiene

- Diseño estilo Quality Restoration / AI Repair.
- Before / After.
- Reparación IA.
- Ultra HD.
- Anime HD.
- Exportación 720p, 1080p, 2K y 4K.
- Motor experimental con Media3 Transformer.

Si vuelve a fallar, manda captura del nuevo error rojo.
