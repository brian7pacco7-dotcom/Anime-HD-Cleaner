package com.zeta.animehdcleaner;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

public class MainActivity extends Activity {

    private static final int REQ_PICK_VIDEO = 1001;

    private Uri selectedVideo;
    private ExoPlayer player;
    private PlayerView playerView;

    private final ExportSettings settings = new ExportSettings();

    private String activeTab = "Calidad del video";
    private String activeMode = "Calidad de imagen";
    private String activeQuality = "720P";
    private int compareProgress = 50;

    private FrameLayout previewFrame;
    private View afterOverlay;
    private View divider;
    private TextView handle;
    private SeekBar compareSeek;

    private TextView fileInfo;
    private TextView applyBanner;
    private TextView applyInfo;
    private TextView exportInfo;
    private TextView status;
    private TextView qualityDrop;
    private LinearLayout tabsRow;
    private LinearLayout toolsRow;
    private LinearLayout controlsHost;

    private Dialog exportDialog;
    private ProgressBar exportProgress;
    private TextView exportPercent;
    private TextView exportState;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean exportDone = false;
    private int fakeProgress = 0;

    private final int dark = Color.rgb(13, 14, 18);
    private final int panel = Color.rgb(29, 31, 36);
    private final int card = Color.rgb(38, 40, 47);
    private final int white = Color.WHITE;
    private final int muted = Color.rgb(155, 160, 170);
    private final int cyan = Color.rgb(15, 210, 255);
    private final int green = Color.rgb(30, 220, 150);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initDefaults();
        buildUi();
        preparePlayer();
        refreshInfo();
    }

    private void initDefaults() {
        settings.modeName = activeMode;
        settings.qualityName = activeQuality;
        settings.width = 720;
        settings.height = 1280;
        settings.fps = 30;
        settings.bitrateMbps = 8;
        settings.brightness = 3;
        settings.contrast = 3;
        settings.saturation = 7;
        settings.shadows = 8;
        settings.denoise = 5;
        settings.sharpen = 5;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(dark);
        root.setPadding(dp(12), dp(12), dp(12), dp(10));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(top);

        top.addView(topIcon("✕"));
        TextView help = topIcon("?");
        ((LinearLayout.LayoutParams) help.getLayoutParams()).leftMargin = dp(12);
        top.addView(help);
        TextView fire = topIcon("🔥");
        ((LinearLayout.LayoutParams) fire.getLayoutParams()).leftMargin = dp(12);
        top.addView(fire);

        View spacer = new View(this);
        top.addView(spacer, new LinearLayout.LayoutParams(0, 1, 1f));

        qualityDrop = topPill(activeQuality + " ▾");
        qualityDrop.setOnClickListener(v -> showQualitySelector());
        top.addView(qualityDrop);

        Button exportTop = new Button(this);
        exportTop.setText("Exportar");
        exportTop.setAllCaps(false);
        exportTop.setTextSize(16);
        exportTop.setTypeface(Typeface.DEFAULT_BOLD);
        exportTop.setTextColor(Color.BLACK);
        exportTop.setBackgroundColor(cyan);
        LinearLayout.LayoutParams exp = new LinearLayout.LayoutParams(dp(128), dp(54));
        exp.leftMargin = dp(10);
        exportTop.setLayoutParams(exp);
        exportTop.setOnClickListener(v -> showExportConfirm());
        top.addView(exportTop);

        // BIG IMPORT BUTTON - clear and visible
        Button importBig = new Button(this);
        importBig.setText("＋ Importar video");
        importBig.setAllCaps(false);
        importBig.setTextSize(17);
        importBig.setTypeface(Typeface.DEFAULT_BOLD);
        importBig.setTextColor(Color.BLACK);
        importBig.setBackgroundColor(green);
        LinearLayout.LayoutParams ibp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54));
        ibp.topMargin = dp(10);
        root.addView(importBig, ibp);
        importBig.setOnClickListener(v -> pickVideo());

        previewFrame = new FrameLayout(this);
        previewFrame.setBackgroundColor(Color.BLACK);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(430));
        pp.topMargin = dp(10);
        root.addView(previewFrame, pp);

        playerView = new PlayerView(this);
        playerView.setUseController(false);
        previewFrame.addView(playerView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        afterOverlay = new View(this);
        afterOverlay.setBackgroundColor(Color.argb(46, 255, 255, 255));
        previewFrame.addView(afterOverlay, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        divider = new View(this);
        divider.setBackgroundColor(Color.WHITE);
        previewFrame.addView(divider, new FrameLayout.LayoutParams(dp(3), ViewGroup.LayoutParams.MATCH_PARENT));

        handle = new TextView(this);
        handle.setText("◀ ▶");
        handle.setTextColor(Color.DKGRAY);
        handle.setTypeface(Typeface.DEFAULT_BOLD);
        handle.setTextSize(12);
        handle.setGravity(Gravity.CENTER);
        handle.setBackgroundColor(Color.argb(240, 255, 255, 255));
        previewFrame.addView(handle, new FrameLayout.LayoutParams(dp(62), dp(62)));

        previewFrame.addView(videoLabel("Antes", Gravity.BOTTOM | Gravity.LEFT));
        previewFrame.addView(videoLabel("Después", Gravity.BOTTOM | Gravity.RIGHT));
        previewFrame.addView(videoTag("Comparar", Gravity.TOP | Gravity.RIGHT));

        applyBanner = new TextView(this);
        applyBanner.setText("Sin video cargado");
        applyBanner.setTextColor(white);
        applyBanner.setTextSize(13);
        applyBanner.setTypeface(Typeface.DEFAULT_BOLD);
        applyBanner.setBackgroundColor(Color.argb(175, 30, 30, 34));
        applyBanner.setPadding(dp(12), dp(8), dp(12), dp(8));
        FrameLayout.LayoutParams abp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.LEFT | Gravity.BOTTOM);
        abp.leftMargin = dp(12);
        abp.bottomMargin = dp(56);
        previewFrame.addView(applyBanner, abp);

        previewFrame.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN || event.getAction() == MotionEvent.ACTION_MOVE) {
                updateCompareFromTouch(event.getX());
                return true;
            }
            return false;
        });

        LinearLayout mini = new LinearLayout(this);
        mini.setOrientation(LinearLayout.HORIZONTAL);
        mini.setGravity(Gravity.CENTER_VERTICAL);
        mini.setPadding(0, dp(8), 0, 0);
        root.addView(mini);
        mini.addView(miniBtn("⛶", v -> openFullscreen()));
        mini.addView(miniBtn("▷", v -> {
            if (player == null) return;
            if (player.isPlaying()) player.pause(); else player.play();
        }));
        mini.addView(miniBtn("＋", v -> pickVideo()));
        mini.addView(miniBtn("↺", v -> {
            compareProgress = 50;
            compareSeek.setProgress(50);
            updateCompareViews();
        }));

        compareSeek = new SeekBar(this);
        compareSeek.setMax(100);
        compareSeek.setProgress(compareProgress);
        compareSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                compareProgress = progress;
                updateCompareViews();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        root.addView(compareSeek);

        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setBackgroundColor(panel);
        bottom.setPadding(dp(14), dp(10), dp(14), dp(14));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        bp.topMargin = dp(6);
        root.addView(bottom, bp);

        fileInfo = new TextView(this);
        fileInfo.setTextColor(muted);
        fileInfo.setTextSize(12);
        bottom.addView(fileInfo);

        tabsRow = new LinearLayout(this);
        tabsRow.setOrientation(LinearLayout.HORIZONTAL);
        tabsRow.setPadding(0, dp(10), 0, 0);
        bottom.addView(tabsRow);
        rebuildTabs();

        toolsRow = new LinearLayout(this);
        toolsRow.setOrientation(LinearLayout.HORIZONTAL);
        HorizontalScrollView toolsScroll = new HorizontalScrollView(this);
        toolsScroll.setHorizontalScrollBarEnabled(false);
        toolsScroll.setPadding(0, dp(12), 0, dp(8));
        toolsScroll.addView(toolsRow);
        bottom.addView(toolsScroll);

        controlsHost = new LinearLayout(this);
        controlsHost.setOrientation(LinearLayout.VERTICAL);
        bottom.addView(controlsHost);

        applyInfo = infoText();
        exportInfo = infoText();
        status = infoText();

        rebuildTools();
        rebuildControls();

        setContentView(root);
        previewFrame.post(this::updateCompareViews);
    }

    private void rebuildTabs() {
        tabsRow.removeAllViews();
        tabsRow.addView(tab("Filtros"));
        tabsRow.addView(tab("Ajustar"));
        tabsRow.addView(tab("Calidad del video"));
    }

    private TextView tab(String name) {
        TextView v = new TextView(this);
        v.setText(name);
        v.setTextColor(activeTab.equals(name) ? white : muted);
        v.setTypeface(activeTab.equals(name) ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        v.setTextSize(16);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(6), dp(4), dp(6), dp(8));
        v.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        v.setOnClickListener(view -> {
            activeTab = name;
            rebuildTabs();
            rebuildTools();
            rebuildControls();
        });
        return v;
    }

    private void rebuildTools() {
        toolsRow.removeAllViews();
        if (activeTab.equals("Ajustar")) {
            toolsRow.addView(tool("Brillo", activeMode.equals("Brillo"), () -> setMode("Brillo")));
            toolsRow.addView(tool("Contraste", activeMode.equals("Contraste"), () -> setMode("Contraste")));
            toolsRow.addView(tool("Saturación", activeMode.equals("Saturación"), () -> setMode("Saturación")));
            toolsRow.addView(tool("Luminosidad", activeMode.equals("Luminosidad"), () -> setMode("Luminosidad")));
            toolsRow.addView(tool("Enfocar", activeMode.equals("Enfocar"), () -> setMode("Enfocar")));
        } else if (activeTab.equals("Calidad del video")) {
            toolsRow.addView(tool("Eliminar parpadeos", activeMode.equals("Eliminar parpadeos"), () -> setMode("Eliminar parpadeos")));
            toolsRow.addView(tool("Reducir ruido", activeMode.equals("Reducir ruido"), () -> setMode("Reducir ruido")));
            toolsRow.addView(tool("Calidad de imagen", activeMode.equals("Calidad de imagen"), () -> setMode("Calidad de imagen")));
        } else {
            toolsRow.addView(tool("Anime HD", activeMode.equals("Anime HD"), () -> {
                settings.sharpen = 7;
                settings.saturation = 8;
                setMode("Anime HD");
            }));
            toolsRow.addView(tool("Color IA", activeMode.equals("Color IA"), () -> {
                settings.saturation = 12;
                settings.contrast = 4;
                setMode("Color IA");
            }));
            toolsRow.addView(tool("Sombras", activeMode.equals("Sombras"), () -> {
                settings.shadows = 14;
                setMode("Sombras");
            }));
        }
    }

    private void setMode(String mode) {
        activeMode = mode;
        settings.modeName = mode;
        applyBanner.setText("Aplicando 1 función");
        rebuildTools();
        rebuildControls();
        refreshInfo();
        Toast.makeText(this, "✓ " + mode + " guardado", Toast.LENGTH_SHORT).show();
    }

    private void rebuildControls() {
        controlsHost.removeAllViews();

        if (activeTab.equals("Calidad del video")) {
            controlsHost.addView(qualityStrength());
        } else if (activeTab.equals("Ajustar")) {
            if (activeMode.equals("Brillo")) controlsHost.addView(simpleSlider("Brillo", 0, 10, settings.brightness, v -> settings.brightness = v));
            else if (activeMode.equals("Contraste")) controlsHost.addView(simpleSlider("Contraste", 0, 10, settings.contrast, v -> settings.contrast = v));
            else if (activeMode.equals("Saturación")) controlsHost.addView(simpleSlider("Saturación", 0, 15, settings.saturation, v -> settings.saturation = v));
            else if (activeMode.equals("Luminosidad")) controlsHost.addView(simpleSlider("Luminosidad", 0, 20, settings.shadows, v -> settings.shadows = v));
            else controlsHost.addView(simpleSlider("Enfocar", 0, 10, settings.sharpen, v -> settings.sharpen = v));
        } else {
            TextView t = infoText();
            t.setText("✓ Preset activo: " + activeMode + "\nSe aplicará al exportar.");
            controlsHost.addView(t);
        }

        controlsHost.addView(applyInfo);
        controlsHost.addView(exportInfo);
        controlsHost.addView(status);
        refreshInfo();
    }

    private View qualityStrength() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);

        TextView title = infoText();
        title.setText("Calidad de imagen");
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextSize(16);
        box.addView(title);

        SeekBar bar = new SeekBar(this);
        bar.setMax(2);
        bar.setProgress(activeQuality.equals("UHD") ? 2 : activeQuality.equals("1080P") ? 1 : 0);
        box.addView(bar);

        TextView labels = infoText();
        labels.setText("Ninguno                 HD                 UHD");
        box.addView(labels);

        TextView saved = infoText();
        saved.setText("✓ Calidad activa: " + activeQuality + " • Se aplicará al exportar");
        box.addView(saved);

        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (progress == 0) setQuality("720P", 720, 1280, 30, 8);
                else if (progress == 1) setQuality("1080P", 1080, 1920, 30, 12);
                else setQuality("UHD", 2160, 3840, 30, 35);
                saved.setText("✓ Calidad activa: " + activeQuality + " • Se aplicará al exportar");
                refreshInfo();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                Toast.makeText(MainActivity.this, "✓ Calidad guardada", Toast.LENGTH_SHORT).show();
            }
        });

        return box;
    }

    private interface Setter { void set(int value); }

    private View simpleSlider(String name, int min, int max, int value, Setter setter) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);

        TextView title = infoText();
        title.setText(name);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextSize(16);
        box.addView(title);

        SeekBar seek = new SeekBar(this);
        seek.setMax(max - min);
        seek.setProgress(value - min);
        box.addView(seek);

        TextView state = infoText();
        state.setText("Valor actual: " + value + " • Se aplicará al exportar");
        box.addView(state);

        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int real = min + progress;
                setter.set(real);
                state.setText("Valor actual: " + real + " • Se aplicará al exportar");
                refreshInfo();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                Toast.makeText(MainActivity.this, "✓ Cambio guardado", Toast.LENGTH_SHORT).show();
            }
        });
        return box;
    }

    private void refreshInfo() {
        fileInfo.setText(selectedVideo == null ?
                "Presiona ＋ Importar video para empezar." :
                "Video cargado: " + getFileName(selectedVideo));

        if (selectedVideo == null) {
            applyBanner.setText("Sin video cargado");
        } else {
            applyBanner.setText("Aplicando 1 función");
        }

        applyInfo.setText(
                "\nCómo sabes que sí se aplicó:\n" +
                "• Función activa: " + activeMode + "\n" +
                "• Calidad activa: " + activeQuality + "\n" +
                "• Ajustes guardados: brillo " + settings.brightness +
                ", contraste " + settings.contrast +
                ", saturación " + settings.saturation +
                ", nitidez " + settings.sharpen +
                ", ruido " + settings.denoise + "\n" +
                "• Se usarán al presionar Exportar."
        );

        exportInfo.setText(
                "\nExportación real HD:\n" +
                "• " + settings.width + "x" + settings.height +
                " • " + settings.fps + " FPS • " + settings.bitrateMbps + " Mbps\n" +
                "• Motor HD real activado."
        );

        status.setText("\nEstado: listo.");
        qualityDrop.setText(activeQuality + " ▾");
    }

    private void showQualitySelector() {
        String[] options = {"720P", "1080P", "UHD"};
        new AlertDialog.Builder(this)
                .setTitle("Elegir calidad")
                .setItems(options, (d, which) -> {
                    if (which == 0) setQuality("720P", 720, 1280, 30, 8);
                    if (which == 1) setQuality("1080P", 1080, 1920, 30, 12);
                    if (which == 2) setQuality("UHD", 2160, 3840, 30, 35);
                })
                .show();
    }

    private void setQuality(String name, int w, int h, int fps, int mbps) {
        activeQuality = name;
        settings.qualityName = name;
        settings.width = w;
        settings.height = h;
        settings.fps = fps;
        settings.bitrateMbps = mbps;
        refreshInfo();
    }

    private void showExportConfirm() {
        if (selectedVideo == null) {
            Toast.makeText(this, "Primero presiona ＋ Importar video.", Toast.LENGTH_SHORT).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Exportar con motor HD real")
                .setMessage(
                        "Se aplicará:\n" +
                        "• Función: " + activeMode + "\n" +
                        "• Calidad: " + activeQuality + "\n" +
                        "• Brillo " + settings.brightness + ", contraste " + settings.contrast +
                        ", saturación " + settings.saturation + ", nitidez " + settings.sharpen +
                        ", ruido " + settings.denoise + "\n\n" +
                        "Verás una carga de exportación."
                )
                .setPositiveButton("Exportar", (d, w) -> exportHd())
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void exportHd() {
        showProgressDialog();
        fakeProgress = 0;
        exportDone = false;
        stepProgress();

        RealHdExporter.export(this, selectedVideo, settings, new RealHdExporter.Listener() {
            @Override public void onLog(String message) {
                runOnUiThread(() -> {
                    status.setText(message);
                    if (exportState != null) exportState.setText(message + "\nNo cierres la app.");
                });
            }

            @Override public void onFinished(boolean success, Uri outputUri, String message) {
                runOnUiThread(() -> {
                    exportDone = true;
                    if (exportProgress != null) exportProgress.setProgress(100);
                    if (exportPercent != null) exportPercent.setText("100%");
                    if (exportState != null) exportState.setText(message + "\nSe aplicó la exportación HD real.");
                    status.setText(message + "\nGuardado en Movies/AnimeHDCleaner");
                    handler.postDelayed(() -> {
                        if (exportDialog != null && exportDialog.isShowing()) exportDialog.dismiss();
                        Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
                    }, 1300);
                });
            }
        });
    }

    private void showProgressDialog() {
        exportDialog = new Dialog(this);
        exportDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(20), dp(20), dp(20));
        root.setBackgroundColor(card);

        TextView title = new TextView(this);
        title.setText("Mejorar con motor HD");
        title.setTextColor(white);
        title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(title);

        exportProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        exportProgress.setMax(100);
        exportProgress.setProgress(0);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        pp.topMargin = dp(18);
        root.addView(exportProgress, pp);

        exportPercent = new TextView(this);
        exportPercent.setText("0%");
        exportPercent.setTextColor(white);
        exportPercent.setTextSize(22);
        exportPercent.setGravity(Gravity.CENTER_HORIZONTAL);
        exportPercent.setPadding(0, dp(12), 0, dp(8));
        root.addView(exportPercent);

        exportState = new TextView(this);
        exportState.setText("Preparando exportación...\nNo cierres la app.");
        exportState.setTextColor(white);
        exportState.setTextSize(15);
        exportState.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(exportState);

        exportDialog.setContentView(root);
        exportDialog.setCancelable(false);
        exportDialog.show();
    }

    private void stepProgress() {
        if (exportDone) return;
        fakeProgress += fakeProgress < 70 ? 7 : 2;
        if (fakeProgress > 95) fakeProgress = 95;

        if (exportProgress != null) exportProgress.setProgress(fakeProgress);
        if (exportPercent != null) exportPercent.setText(fakeProgress + "%");

        String msg;
        if (fakeProgress < 20) msg = "Analizando video...";
        else if (fakeProgress < 40) msg = "Aplicando ajustes guardados...";
        else if (fakeProgress < 60) msg = "Procesando calidad HD...";
        else if (fakeProgress < 80) msg = "Codificando salida " + activeQuality + "...";
        else msg = "Guardando archivo final...";
        if (exportState != null) exportState.setText(msg + "\nNo cierres la app.");

        handler.postDelayed(this::stepProgress, 700);
    }

    private void pickVideo() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("video/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {
                "video/mp4", "video/quicktime", "video/x-matroska", "video/webm",
                "video/x-msvideo", "video/3gpp", "video/x-ms-wmv", "video/*"
        });
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, REQ_PICK_VIDEO);
    }

    private void openFullscreen() {
        if (selectedVideo == null) {
            Toast.makeText(this, "Primero importa un video.", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(this, FullscreenCompareActivity.class);
        i.putExtra("video_uri", selectedVideo.toString());
        i.putExtra("title", "Comparación");
        i.putExtra("subtitle", activeMode + " • " + activeQuality);
        i.putExtra("compare_progress", compareProgress);
        startActivity(i);
    }

    private void preparePlayer() {
        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        player.setRepeatMode(Player.REPEAT_MODE_ONE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PICK_VIDEO && resultCode == RESULT_OK && data != null) {
            selectedVideo = data.getData();
            if (selectedVideo != null) {
                try {
                    getContentResolver().takePersistableUriPermission(selectedVideo, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Exception ignored) {}

                player.setMediaItem(MediaItem.fromUri(selectedVideo));
                player.prepare();
                player.play();

                refreshInfo();
            }
        }
    }

    private String getFileName(Uri uri) {
        String result = "video seleccionado";
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) result = cursor.getString(index);
            }
        } catch (Exception ignored) {}
        return result;
    }

    private void updateCompareFromTouch(float x) {
        if (previewFrame == null || previewFrame.getWidth() == 0) return;
        int w = previewFrame.getWidth();
        int p = Math.max(0, Math.min(100, Math.round((x / w) * 100f)));
        compareProgress = p;
        compareSeek.setProgress(p);
        updateCompareViews();
    }

    private void updateCompareViews() {
        if (previewFrame == null || previewFrame.getWidth() == 0) return;
        int w = previewFrame.getWidth();
        int h = previewFrame.getHeight();
        int x = (int)(w * (compareProgress / 100f));

        FrameLayout.LayoutParams overlay = (FrameLayout.LayoutParams) afterOverlay.getLayoutParams();
        overlay.width = Math.max(0, w - x);
        overlay.height = h;
        overlay.gravity = Gravity.RIGHT;
        afterOverlay.setLayoutParams(overlay);

        FrameLayout.LayoutParams line = (FrameLayout.LayoutParams) divider.getLayoutParams();
        line.width = dp(3);
        line.height = h;
        line.leftMargin = Math.max(0, x - dp(1));
        divider.setLayoutParams(line);

        FrameLayout.LayoutParams hp = (FrameLayout.LayoutParams) handle.getLayoutParams();
        hp.width = dp(62);
        hp.height = dp(62);
        hp.leftMargin = Math.max(0, Math.min(w - dp(62), x - dp(31)));
        hp.topMargin = Math.max(0, h / 2 - dp(31));
        handle.setLayoutParams(hp);
    }

    private TextView topIcon(String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextColor(white);
        v.setGravity(Gravity.CENTER);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setTextSize(20);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(36), dp(36)));
        return v;
    }

    private TextView topPill(String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextColor(white);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setTextSize(16);
        v.setGravity(Gravity.CENTER);
        v.setBackgroundColor(card);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(110), dp(54)));
        return v;
    }

    private TextView miniBtn(String text, View.OnClickListener click) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(white);
        v.setTextSize(24);
        v.setGravity(Gravity.CENTER);
        v.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        v.setOnClickListener(click);
        return v;
    }

    private TextView videoLabel(String text, int gravity) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(white);
        v.setTextSize(18);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setShadowLayer(4, 0, 0, Color.BLACK);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, gravity);
        lp.leftMargin = dp(16);
        lp.rightMargin = dp(16);
        lp.bottomMargin = dp(16);
        v.setLayoutParams(lp);
        return v;
    }

    private TextView videoTag(String text, int gravity) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(white);
        v.setTextSize(12);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setBackgroundColor(Color.argb(150, 0, 0, 0));
        v.setPadding(dp(10), dp(6), dp(10), dp(6));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, gravity);
        lp.rightMargin = dp(12);
        lp.topMargin = dp(12);
        v.setLayoutParams(lp);
        return v;
    }

    private TextView tool(String name, boolean active, Runnable action) {
        TextView v = new TextView(this);
        v.setText((active ? "✓\n" : "○\n") + name);
        v.setTextColor(active ? cyan : white);
        v.setTextSize(13);
        v.setGravity(Gravity.CENTER);
        v.setTypeface(active ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        v.setBackgroundColor(card);
        v.setPadding(dp(8), dp(10), dp(8), dp(10));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(110), dp(88));
        p.rightMargin = dp(10);
        v.setLayoutParams(p);
        v.setOnClickListener(view -> action.run());
        return v;
    }

    private TextView infoText() {
        TextView v = new TextView(this);
        v.setTextColor(white);
        v.setTextSize(13);
        return v;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (player != null) player.pause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
        if (player != null) {
            player.release();
            player = null;
        }
    }
}
