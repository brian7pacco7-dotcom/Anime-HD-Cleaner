# Anime HD Cleaner V6.8 REAL HD PRO

Versión profesional con motor HD real activado.

## Importante

Se descartó la versión sin motor.
Esta versión mantiene Media3 Transformer para exportación real HD.

## Mejoras

- Botón grande y claro: + Importar video.
- Motor HD real activado.
- Panel inferior tipo editor.
- Comparador Antes / Después con regla movible.
- Herramientas con check y estado activo.
- Exportación con barra de progreso.
- Mensaje claro de qué se aplicará al exportar.

## Notas

Si al instalar vuelve a quedarse trabado, reinicia el celular e instala con suficiente batería.
Si GitHub Actions falla, manda captura del error rojo.
